// Supabase Edge Function: AI proxy. The LLM key lives ONLY here (supabase secrets), never in the app.
// Deploy: supabase functions deploy ai
// Secrets: supabase secrets set ANTHROPIC_API_KEY=... AI_MODEL=<model id you have access to>
// Needs the caller's JWT (verify_jwt = true, default). Not load-tested; add per-user rate limiting before launch.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

const SAFETY = `You are the assistant inside YOUR COACH, an Arabic-first fitness app. Reply in the user's language (Egyptian Arabic if they write Arabic).
Rules: you give general fitness/nutrition education only. Never diagnose injuries or conditions, never prescribe treatment or medication; for pain, injury or medical conditions tell the user to see a qualified professional.
Never recommend calorie deficits, weight-loss targets or restrictive diets to anyone under 18 (profile.minor=true) - recommend balanced eating and professional guidance.
You cannot change the user's programs or nutrition targets; you may only suggest and the user decides in the app.
Never invent facts about the user's data. If the DATA block lacks what is needed, say so plainly.`;

const SYS: Record<string, string> = {
  train: `${SAFETY}\nRole: training assistant (exercises, programming principles, volume, progression, RPE/RIR, alternatives). Be concise.`,
  nutri: `${SAFETY}\nRole: nutrition assistant (calories, macros, substitutions, meal ideas). Give estimates as estimates.`,
  data: `${SAFETY}\nRole: answer questions ONLY from the DATA JSON provided (user's own logs). Quote numbers from it; do not guess missing records.`,
  meal: `${SAFETY}
Role: meal analyzer. Return ONLY JSON, no markdown, with this shape:
{"items":[{"name_ar":str,"name_en":str,"grams":number,"assumed":bool,"kcal":number,"protein":number,"carbs":number,"fat":number}],
 "uncertainty":"short honest note in the user's language about what is estimated",
 "questions":[str]}
Use typical cooked-weight values (Egyptian foods where relevant). Set assumed=true when you guessed the quantity. Put clarifying questions in "questions" when quantities are unclear. These are estimates, never exact.`,
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization") ?? "";
    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: u } = await sb.auth.getUser();
    if (!u?.user) return json({ error: "unauthorized" }, 401);

    const body = await req.json();
    const mode = String(body.mode ?? "");
    if (!(mode in SYS)) return json({ error: "bad mode" }, 400);
    const text = String(body.text ?? "").slice(0, 2000);
    if (!text.trim()) return json({ error: "empty" }, 400);
    const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
    const data = mode === "data" ? JSON.stringify(body.data ?? {}).slice(0, 60000) : "";
    const profile = JSON.stringify({ minor: body.minor === true });

    const messages = [
      ...history.filter((m: any) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string").map((m: any) => ({ role: m.role, content: String(m.content).slice(0, 2000) })),
      { role: "user", content: `${mode === "data" ? `DATA:\n${data}\n\n` : ""}PROFILE: ${profile}\n\n${text}` },
    ];

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: Deno.env.get("AI_MODEL"), max_tokens: 1200, system: SYS[mode], messages }),
    });
    if (!r.ok) return json({ error: "llm_failed", status: r.status }, 502);
    const out = await r.json();
    const reply: string = (out.content ?? []).map((c: any) => c.text ?? "").join("");

    if (mode === "meal") {
      try {
        const parsed = JSON.parse(reply.replace(/```json|```/g, "").trim());
        return json({ meal: parsed });
      } catch { return json({ error: "unparseable" }, 502); }
    }
    return json({ reply });
  } catch (e) {
    return json({ error: "server_error" }, 500);
  }
});
