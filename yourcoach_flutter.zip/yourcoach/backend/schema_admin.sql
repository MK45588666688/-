-- Run AFTER schema.sql. Admin bootstrap, storage buckets, audit log policies.

-- 1) Make yourself the first super admin (sign up in the app/admin first, then run with YOUR user id):
--    insert into user_roles (user_id, role) values ('<YOUR-AUTH-USER-UUID>', 'super_admin');

-- 2) Public bucket for official content media (exercise videos/images, article images). Only content admins can write.
insert into storage.buckets (id, name, public) values ('content-media', 'content-media', true) on conflict (id) do nothing;
create policy content_media_read   on storage.objects for select using (bucket_id = 'content-media');
create policy content_media_insert on storage.objects for insert with check (bucket_id = 'content-media' and has_role('content_admin'));
create policy content_media_update on storage.objects for update using (bucket_id = 'content-media' and has_role('content_admin'));
create policy content_media_delete on storage.objects for delete using (bucket_id = 'content-media' and has_role('content_admin'));

-- 3) PRIVATE bucket for progress photos: each user only touches files under their own uid/ folder. Use signed URLs only.
insert into storage.buckets (id, name, public) values ('progress-photos', 'progress-photos', false) on conflict (id) do nothing;
create policy photos_own_all on storage.objects for all
  using (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- 4) Audit log: admins can append, only super_admin can read.
alter table audit_log enable row level security;
create policy audit_insert on audit_log for insert with check (has_role('content_admin') and actor = auth.uid());
create policy audit_read   on audit_log for select using (has_role('super_admin'));

-- 5) Role management is super_admin only (the admin UI never assigns roles; do it here).
create policy roles_admin_write on user_roles for all using (has_role('super_admin')) with check (has_role('super_admin'));
