-- YOUR COACH — Supabase/Postgres schema (Phase 1 core + hooks for later phases)
-- Not yet executed against a live database. Run in Supabase SQL editor.
create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

create type app_role as enum ('user','support','content_admin','super_admin');
create type content_status as enum ('draft','published','archived');
create type meal_type as enum ('breakfast','lunch','dinner','snack');
create type data_source as enum ('verified','user','ai_estimate','label_scan','barcode');

-- ===== Users =====
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  display_name text, birth_date date, sex text check (sex in ('male','female')),
  height_cm numeric, experience text check (experience in ('beginner','intermediate','advanced')),
  interests text[] default '{}', train_days_per_week int, equipment text[] default '{}',
  activity_level text, language text default 'ar', units text default 'metric',
  is_minor boolean generated always as (birth_date is not null and birth_date > (current_date - interval '18 years')) stored,
  dashboard_widgets jsonb default '[]', created_at timestamptz default now()
);
create table user_roles (user_id uuid references auth.users on delete cascade, role app_role not null, primary key(user_id, role));
create function has_role(r app_role) returns boolean language sql stable security definer as
$$ select exists(select 1 from user_roles where user_id = auth.uid() and role in (r,'super_admin')) $$;

-- ===== Exercises & official programs (admin-owned) =====
create table exercises (
  id uuid primary key default gen_random_uuid(), key text unique not null,
  name_ar text not null, name_en text not null, muscle text not null, secondary_muscles text[] default '{}',
  equipment text, category text, movement_pattern text, difficulty text,
  instructions_ar text, instructions_en text, common_mistakes_ar text,
  video_url text, image_url text, status content_status default 'draft'
);
create table exercise_alternatives (exercise_id uuid references exercises on delete cascade, alt_id uuid references exercises on delete cascade, primary key(exercise_id, alt_id));
create table programs (
  id uuid primary key default gen_random_uuid(), slug text unique, owner_id uuid references auth.users, -- null = official
  title_ar text not null, title_en text, description_ar text, level text, goal text, days_per_week int,
  split_type text, cycle jsonb default '[]',          -- supports non-7-day cycles incl. REST
  status content_status default 'draft', featured boolean default false, is_dev_seed boolean default false,
  created_at timestamptz default now()
);
create table program_days (id uuid primary key default gen_random_uuid(), program_id uuid not null references programs on delete cascade, position int not null, name text not null, focus text, notes text);
create table program_exercises (
  id uuid primary key default gen_random_uuid(), day_id uuid not null references program_days on delete cascade,
  exercise_id uuid not null references exercises, position int not null,
  warmup_sets int default 0, sets_min int, sets_max int, reps_min int, reps_max int,
  rir_min numeric, rir_max numeric, rpe numeric, rest_min_sec int, rest_max_sec int,
  backoff_pct numeric, superset_group int, notes text
);
create table program_cardio (id uuid primary key default gen_random_uuid(), program_id uuid references programs on delete cascade, timing text, type text, duration_min int, notes text);
create table user_active_program (user_id uuid primary key references auth.users on delete cascade, program_id uuid references programs, cycle_index int default 0, started_at date default current_date);

-- ===== Workout logging =====
create table workout_sessions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade,
  program_id uuid references programs, day_id uuid references program_days, name text,
  started_at timestamptz default now(), ended_at timestamptz, notes text
);
create table set_logs (
  id uuid primary key default gen_random_uuid(), session_id uuid not null references workout_sessions on delete cascade,
  user_id uuid not null references auth.users on delete cascade, exercise_id uuid not null references exercises,
  set_number int not null, is_warmup boolean default false, weight_kg numeric, reps int, rir numeric, rpe numeric,
  rest_sec int, notes text, logged_at timestamptz default now(), client_id uuid unique   -- idempotent offline sync
);
create table personal_records (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, exercise_id uuid references exercises, kind text, value numeric, achieved_on date, set_log_id uuid references set_logs);

-- ===== Nutrition =====
create table food_categories (id serial primary key, name_ar text, name_en text);
create table foods (
  id uuid primary key default gen_random_uuid(), owner_id uuid references auth.users, -- null = official
  name_ar text not null, name_en text, aliases text[] default '{}', category_id int references food_categories,
  kcal_100g numeric not null, protein_100g numeric not null, carbs_100g numeric not null, fat_100g numeric not null,
  serving_g numeric, serving_label text, barcode text, source data_source default 'user', status content_status default 'published'
);
create index foods_search on foods using gin ((coalesce(name_ar,'')||' '||coalesce(name_en,'')) gin_trgm_ops);
create table nutrition_entries (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade,
  eaten_on date not null, meal meal_type not null, food_id uuid references foods, label text, grams numeric,
  kcal numeric, protein numeric, carbs numeric, fat numeric, source data_source default 'user',
  confidence numeric, client_id uuid unique
);
create table recipes (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, name text, servings numeric default 1);
create table recipe_ingredients (recipe_id uuid references recipes on delete cascade, food_id uuid references foods, grams numeric not null);
create table nutrition_plans (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, name text, goal text, kcal int, protein_g int, carbs_g int, fat_g int, assumptions jsonb, is_active boolean default false);
create table water_logs (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, logged_at timestamptz default now(), ml int not null);

-- ===== Activity / progress / lifestyle =====
create table activity_records (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, day date, steps int, active_kcal numeric, avg_hr int, sleep_min int, source text, external_id text, unique(user_id, source, external_id));
create table cardio_sessions (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, type text, started_at timestamptz, duration_min numeric, distance_km numeric, speed_kmh numeric, incline numeric, avg_hr int, notes text, source text default 'manual');
create table body_measurements (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, measured_on date, weight_kg numeric, waist_cm numeric, chest_cm numeric, arm_cm numeric, thigh_cm numeric, custom jsonb default '{}');
create table progress_photos (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, taken_on date, storage_path text not null); -- private bucket, signed URLs only
create table habits (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, name text, schedule jsonb, archived boolean default false);
create table habit_logs (habit_id uuid references habits on delete cascade, user_id uuid references auth.users on delete cascade, day date, done boolean default true, primary key(habit_id, day));
create table calendar_events (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, title text, starts_at timestamptz, ends_at timestamptz, kind text);
create table goals (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, title text, target numeric, unit text, current numeric default 0, due date);

-- ===== Content / AI / system =====
create table articles (id uuid primary key default gen_random_uuid(), category text, title_ar text, title_en text, body_ar text, body_en text, cover_url text, status content_status default 'draft', published_at timestamptz);
create table ai_conversations (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, kind text, messages jsonb default '[]', created_at timestamptz default now());
create table user_preferences (user_id uuid primary key references auth.users on delete cascade, notifications jsonb default '{}', privacy jsonb default '{"photos_private":true}', health_permissions jsonb default '{}');
create table notifications (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, title text, body text, scheduled_at timestamptz, sent boolean default false);
create table audit_log (id bigserial primary key, actor uuid, action text, entity text, entity_id text, at timestamptz default now());

-- ===== Row Level Security =====
do $$ declare t text; begin
 foreach t in array array['workout_sessions','set_logs','personal_records','nutrition_entries','recipes','nutrition_plans','water_logs','activity_records','cardio_sessions','body_measurements','progress_photos','habits','habit_logs','calendar_events','goals','ai_conversations','notifications','user_active_program'] loop
  execute format('alter table %I enable row level security', t);
  execute format('create policy own_all on %I for all using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
 end loop; end $$;
alter table profiles enable row level security;
create policy own_profile on profiles for all using (id = auth.uid()) with check (id = auth.uid());
alter table user_preferences enable row level security;
create policy own_prefs on user_preferences for all using (user_id = auth.uid()) with check (user_id = auth.uid());
alter table recipe_ingredients enable row level security;
create policy own_ri on recipe_ingredients for all using (exists(select 1 from recipes r where r.id=recipe_id and r.user_id=auth.uid()));

-- Official content: everyone reads published; admins write. Users own their custom rows.
alter table exercises enable row level security;
create policy ex_read on exercises for select using (status='published' or has_role('content_admin'));
create policy ex_write on exercises for all using (has_role('content_admin')) with check (has_role('content_admin'));
alter table programs enable row level security;
create policy pr_read on programs for select using ((owner_id is null and status='published') or owner_id=auth.uid() or has_role('content_admin'));
create policy pr_user_write on programs for all using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy pr_admin_write on programs for all using (has_role('content_admin')) with check (has_role('content_admin'));
alter table program_days enable row level security;
create policy pd_all on program_days for all using (exists(select 1 from programs p where p.id=program_id and (p.owner_id=auth.uid() or has_role('content_admin') or (p.owner_id is null and p.status='published'))))
  with check (exists(select 1 from programs p where p.id=program_id and (p.owner_id=auth.uid() or has_role('content_admin'))));
alter table program_exercises enable row level security;
create policy pe_all on program_exercises for all using (exists(select 1 from program_days d join programs p on p.id=d.program_id where d.id=day_id and (p.owner_id=auth.uid() or has_role('content_admin') or (p.owner_id is null and p.status='published'))))
  with check (exists(select 1 from program_days d join programs p on p.id=d.program_id where d.id=day_id and (p.owner_id=auth.uid() or has_role('content_admin'))));
alter table foods enable row level security;
create policy fd_read on foods for select using ((owner_id is null and status='published') or owner_id=auth.uid() or has_role('content_admin'));
create policy fd_user on foods for all using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy fd_admin on foods for all using (has_role('content_admin')) with check (has_role('content_admin'));
alter table articles enable row level security;
create policy ar_read on articles for select using (status='published' or has_role('content_admin'));
create policy ar_write on articles for all using (has_role('content_admin')) with check (has_role('content_admin'));
alter table user_roles enable row level security;
create policy roles_self on user_roles for select using (user_id=auth.uid() or has_role('super_admin'));

-- ===== Stage 4: cloud backup / cross-device sync (snapshot model) =====
-- Whole user data as one JSON document. Row-level sync of the relational tables above comes later.
create table if not exists user_snapshots (
  user_id uuid primary key references auth.users on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table user_snapshots enable row level security;
create policy own_snapshot on user_snapshots for all using (user_id = auth.uid()) with check (user_id = auth.uid());
