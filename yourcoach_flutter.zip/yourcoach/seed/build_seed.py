import json
EX = {
 'chest_press':('Chest Press Machine','ضغط صدر (ماشين)','chest','machine'),
 'incline_chest_press':('Incline Chest Press Machine','ضغط صدر مائل (ماشين)','chest','machine'),
 'pec_deck':('Pec Deck / Chest Fly Machine','بيك ديك / فلاي صدر','chest','machine'),
 'chest_fly_machine':('Chest Fly Machine','فلاي صدر (ماشين)','chest','machine'),
 'db_low_incline_press':('DB Low Incline Chest Press','ضغط صدر مائل خفيف بالدمبل','chest','dumbbell'),
 'db_flat_press':('DB Flat Press','ضغط صدر مستوي بالدمبل','chest','dumbbell'),
 'lat_pulldown':('Lat Pulldown Machine','سحب أمامي (ماشين)','back','machine'),
 'wide_lat_pulldown':('Wide Grip Lat Pulldown','سحب أمامي واسع','back','cable'),
 'seated_row':('Seated Row Machine','تجديف جالس (ماشين)','back','machine'),
 'close_seated_row':('Close Grip Seated Row','تجديف جالس قبضة ضيقة','back','cable'),
 'tbar_row':('T-Bar Row Machine','تي بار (ماشين)','back','machine'),
 'cable_lat_pullover':('Cable Lat Pullover','بولوفر كابل','back','cable'),
 'rdl':('Romanian Deadlift','رفعة ميتة رومانية','hamstrings','barbell'),
 'shoulder_press':('Shoulder Press Machine','ضغط أكتاف (ماشين)','shoulders','machine'),
 'smith_incline_shoulder_press':('Smith Incline Shoulder Press','ضغط أكتاف مائل (سميث)','shoulders','smith'),
 'lateral_raise_machine':('Lateral Raise Machine','رفرفة جانبي (ماشين)','shoulders','machine'),
 'db_lateral_raise':('DB Lateral Raise','رفرفة جانبي بالدمبل','shoulders','dumbbell'),
 'cable_lateral_raise':('Cable Lateral Raise','رفرفة جانبي كابل','shoulders','cable'),
 'cable_y_raise':('Cable Y Raise','رفرفة Y كابل','shoulders','cable'),
 'rear_delt_machine':('Rear Delt Machine','أكتاف خلفي (ماشين)','shoulders','machine'),
 'kelso_shrug':('Kelso Shrug','ترابيس كيلسو','back','dumbbell'),
 'preacher_curl_machine':('Preacher Curl Machine','بايسبس بريتشر (ماشين)','biceps','machine'),
 'db_preacher_curl':('DB Preacher Curl','بريتشر بالدمبل','biceps','dumbbell'),
 'cable_curl':('Cable Curl','بايسبس كابل','biceps','cable'),
 'cable_hammer_curl':('Cable Hammer Curl','هامر كابل','biceps','cable'),
 'db_no_cheat_curl':('DB No-Cheat Curl','بايسبس دمبل بدون غش','biceps','dumbbell'),
 'bayesian_curl':('Biceps Bayesian Curl','بايسبس بايزيان','biceps','cable'),
 'cable_reverse_curl':('Cable Reverse Curl','ريفرس كيرل كابل (ساعد)','forearms','cable'),
 'db_wrist_flexion':('DB Wrist Flexion','ثني الرسغ بالدمبل','forearms','dumbbell'),
 'triceps_pushdown':('Triceps Pushdown','تراي بوش داون','triceps','cable'),
 'rope_pushdown':('Rope Triceps Pushdown','تراي بوش داون حبل','triceps','cable'),
 'triceps_ext_machine':('Triceps Extension Machine','تراي إكستنشن (ماشين)','triceps','machine'),
 'rope_overhead_ext':('Rope Overhead Extension','تراي أوفرهيد حبل','triceps','cable'),
 'leg_press':('Leg Press Machine','ضغط أرجل (ماشين)','quadriceps','machine'),
 'hack_squat':('Hack Squat Machine','هاك سكوات (ماشين)','quadriceps','machine'),
 'leg_extension':('Leg Extension Machine','رفرفة أرجل أمامي','quadriceps','machine'),
 'seated_leg_curl':('Seated Leg Curl Machine','ثني أرجل جالس','hamstrings','machine'),
 'lying_leg_curl':('Lying Leg Curl Machine','ثني أرجل نائم','hamstrings','machine'),
 'hip_thrust_machine':('Hip Thrust Machine','هيب ثرست (ماشين)','glutes','machine'),
 'smith_hip_thrust':('Smith Hip Thrust','هيب ثرست (سميث)','glutes','smith'),
 'adductor_machine':('Adductors Machine','مقربات الفخذ (ماشين)','adductors','machine'),
 'standing_calf':('Standing Calf Raise Machine','سمانة واقف (ماشين)','calves','machine'),
 'smith_calf':('Smith Standing Calf Raise','سمانة واقف (سميث)','calves','smith'),
 'cable_crunch':('Cable Crunch','كرنش كابل','abs','cable'),
 'abdominal_crunch':('Abdominal Crunches','كرنش بطن','abs','bodyweight'),
 'cable_torso_rotation':('Cable Torso Rotation','لف الجذع كابل','abs','cable'),
}
def e(k,s,r,wu=0,rir=None,rest=None):
    return dict(exercise_key=k,sets_min=s[0],sets_max=s[-1],reps_min=r[0],reps_max=r[1],
                warmup_sets=wu,rir_min=rir[0] if rir else None,rir_max=rir[1] if rir else None,
                rest_min_sec=int(rest[0]*60) if rest else None,rest_max_sec=int(rest[1]*60) if rest else None)
A,B,C=(2,3),(3,4),(1,2)
R6,R8,R15=(6,10),(8,12),(10,15)
def day(n,f,ex): return dict(name=n,focus=f,exercises=ex)
def P(slug,ar,en,lvl,goal,dpw,split,days,cycle=None):
    return dict(slug=slug,title_ar=ar,title_en=en,level=lvl,goal=goal,days_per_week=dpw,split_type=split,
        status='draft',source='dev_seed',cycle=cycle or [d['name'] for d in days],days=days)
fb3=[day('Full Body A','full_body',[e('leg_press',A,R6),e('chest_press',A,R6),e('lat_pulldown',A,R6),e('shoulder_press',A,R6),e('seated_leg_curl',A,R8),e('preacher_curl_machine',A,R8),e('triceps_pushdown',A,R8),e('standing_calf',A,R8)]),
 day('Full Body B','full_body',[e('hack_squat',A,R6),e('incline_chest_press',A,R6),e('tbar_row',A,R8),e('shoulder_press',A,R6),e('lying_leg_curl',A,R8),e('cable_curl',A,R8),e('triceps_ext_machine',A,R8),e('cable_crunch',A,R8)]),
 day('Full Body C','full_body',[e('leg_extension',A,R8),e('tbar_row',A,R8),e('lat_pulldown',A,R6),e('lateral_raise_machine',A,R8),e('hip_thrust_machine',A,R8),e('cable_reverse_curl',A,R15),e('standing_calf',A,R8),e('cable_crunch',A,R8)])]
fb4=[day('Full Body A','full_body',[e('leg_press',A,R6),e('chest_press',A,R6),e('seated_row',A,R6),e('shoulder_press',A,R6),e('seated_leg_curl',A,R8),e('preacher_curl_machine',A,R8),e('triceps_pushdown',A,R8),e('standing_calf',A,R8)]),
 day('Full Body B','full_body',[e('hack_squat',A,R6),e('incline_chest_press',A,R6),e('lat_pulldown',A,R6),e('lateral_raise_machine',A,R8),e('lying_leg_curl',A,R8),e('cable_curl',A,R8),e('triceps_ext_machine',A,R8),e('cable_crunch',A,R8)]),
 day('Full Body C','full_body',[e('leg_extension',A,R8),e('chest_press',A,R6),e('tbar_row',A,R8),e('hip_thrust_machine',A,R8),e('cable_reverse_curl',A,R15),e('standing_calf',A,R8),e('cable_crunch',A,R8)]),
 day('Full Body D','full_body',[e('leg_press',A,R6),e('incline_chest_press',A,R6),e('seated_row',A,R6),e('shoulder_press',A,R6),e('seated_leg_curl',A,R8),e('cable_curl',A,R8),e('triceps_ext_machine',A,R8)])]
def ul(big,small,fifth):
    UA=day('Upper A','upper',[e('chest_press',big,R6),e('incline_chest_press',big,R6),e('lat_pulldown',big,R6),e('tbar_row',big,R8),e('shoulder_press',big,R6),e('lateral_raise_machine',big,R8),e('preacher_curl_machine',small,R8),e('triceps_pushdown',small,R8)])
    LA=day('Lower A','lower',[e('leg_press',B,R6),e('leg_extension',B,R8),e('seated_leg_curl',B,R8),e('standing_calf',B,R8),e('cable_crunch',A,R8)])
    UB=day('Upper B','upper',[e('chest_press',big,R6),e('lat_pulldown',big,R6),e('tbar_row',big,R8),e('lateral_raise_machine',big,R8),e('preacher_curl_machine',small,R8),e('triceps_pushdown',small,R8)]) if fifth else \
       day('Upper B','upper',[e('chest_press',big,R6),e('incline_chest_press',big,R6),e('lat_pulldown',big,R6),e('tbar_row',big,R8),e('lateral_raise_machine',big,R8),e('cable_curl',small,R8),e('cable_reverse_curl',small,R15)])
    LB=day('Lower B','lower',[e('hack_squat',B,R6),e('leg_extension',B,R8),e('lying_leg_curl',B,R8),e('hip_thrust_machine',A if fifth else B,R8),e('standing_calf',B,R8),e('cable_crunch',A,R8)])
    ds=[UA,LA,UB,LB]
    if fifth: ds.append(day('Upper C','upper',[e('pec_deck',big,R8),e('tbar_row',big,R8),e('lat_pulldown',big,R6),e('rear_delt_machine',big,R8),e('preacher_curl_machine',C,R8),e('triceps_pushdown',C,R8),e('cable_reverse_curl',C,R15)]))
    return ds
ppl=[day('Push','push',[e('chest_press',B,R6),e('incline_chest_press',B,R6),e('shoulder_press',B,R6),e('lateral_raise_machine',B,R8),e('triceps_pushdown',A,R8)]),
 day('Pull','pull',[e('lat_pulldown',B,R6),e('seated_row',B,R6),e('tbar_row',B,R8),e('cable_curl',A,R8),e('cable_reverse_curl',A,R15)]),
 day('Legs','legs',[e('leg_press',B,R6),e('leg_extension',B,R8),e('seated_leg_curl',B,R8),e('standing_calf',B,R8),e('cable_crunch',A,R8)]),
 day('Upper','upper',[e('incline_chest_press',B,R6),e('tbar_row',B,R8),e('lateral_raise_machine',B,R8),e('preacher_curl_machine',A,R8),e('triceps_ext_machine',A,R8)]),
 day('Lower','lower',[e('hack_squat',B,R6),e('leg_extension',B,R8),e('lying_leg_curl',B,R8),e('hip_thrust_machine',B,R8),e('standing_calf',B,R8),e('cable_crunch',A,R8)])]
rir=(0,1)
sh=lambda k,wu,ws,r,rest,rr=rir: e(k,(ws,ws),r,wu,rr,rest)
shadad=[day('Day 1','upper_pull',[sh('cable_y_raise',1,2,R8,(1,2)),sh('wide_lat_pulldown',1,3,R6,(2,3)),sh('kelso_shrug',1,2,R8,(2,3)),sh('tbar_row',0,1,R6,(2,3)),sh('cable_lat_pullover',1,3,R6,(2,3)),sh('db_lateral_raise',1,2,(8,10),(2,3)),sh('cable_reverse_curl',1,1,R8,(1.5,2),(1,2)),sh('abdominal_crunch',1,2,R8,(1.5,2))]),
 day('Day 2','chest_arms',[sh('db_low_incline_press',2,3,R6,(2,3)),sh('chest_fly_machine',0,2,R8,(2,3)),sh('db_no_cheat_curl',1,2,R8,(2,3)),sh('rope_pushdown',1,3,R8,(2,3)),sh('bayesian_curl',1,2,R8,(2,3)),sh('rope_overhead_ext',1,2,(8,10),(1.5,2)),sh('cable_hammer_curl',0,1,(8,10),(1.5,2))]),
 day('Day 3','legs',[sh('seated_leg_curl',2,2,(10,12),(2,3)),sh('leg_press',2,2,R8,(2,3)),sh('smith_hip_thrust',1,1,R8,(2,3)),sh('adductor_machine',1,2,R8,(2,3)),sh('smith_calf',1,3,R8,(2,3)),sh('cable_lateral_raise',1,2,R6,(1.5,2)),sh('cable_torso_rotation',1,2,R8,(1.5,2)),sh('abdominal_crunch',0,3,R8,(1.5,2))]),
 day('Day 4','upper',[sh('tbar_row',1,2,R6,(2,3)),sh('db_flat_press',1,2,R6,(2,3)),sh('wide_lat_pulldown',1,1,R8,(2,3)),sh('smith_incline_shoulder_press',0,1,R6,(2,3)),sh('close_seated_row',0,2,R8,(2,3)),sh('lateral_raise_machine',1,3,(10,12),(1.5,2)),sh('db_preacher_curl',1,2,R8,(1.5,2)),sh('rope_pushdown',1,2,R8,(1.5,2))]),
 day('Day 5','legs',[sh('rdl',2,3,R8,(2,3)),sh('hack_squat',1,2,R6,(2,3)),sh('leg_extension',0,3,R8,(2,3)),sh('lying_leg_curl',0,2,R6,(2,3)),sh('adductor_machine',1,2,R8,(2,3)),sh('db_wrist_flexion',1,2,(10,12),(2,3)),sh('smith_calf',1,3,R8,(1.5,2))])]
progs=[P('dev-fullbody-3','فل بودي 3 أيام','Full Body 3-Day','beginner','general',3,'full_body',fb3),
 P('dev-fullbody-4','فل بودي 4 أيام','Full Body 4-Day','intermediate','general',4,'full_body',fb4),
 P('dev-upperlower-4','علوي/سفلي 4 أيام','Upper/Lower 4-Day','intermediate','hypertrophy',4,'upper_lower',ul(B,A,False)),
 P('dev-upperlower-5','علوي/سفلي 5 أيام','Upper/Lower 5-Day','intermediate','hypertrophy',5,'upper_lower',ul(A,C,True)),
 P('dev-ppl-5','بوش بول ليجز 5 أيام','Push/Pull/Legs 5-Day','intermediate','hypertrophy',5,'ppl',ppl),
 P('dev-split-5','سبليت 5 أيام (دورة 7 أيام)','5-Day Split with RIR','advanced','hypertrophy',5,'custom',shadad,
   cycle=['Day 1','Day 2','Day 3','REST','Day 4','Day 5','REST'])]
progs[-1]['cardio']=[dict(timing='post_workout',type='treadmill',duration_min=20,notes='speed 4, incline 10')]
used={x['exercise_key'] for p in progs for d in p['days'] for x in d['exercises']}
assert used<=set(EX),used-set(EX)
exs=[dict(key=k,name_en=v[0],name_ar=v[1],muscle=v[2],equipment=v[3],video_url=None,status='draft') for k,v in EX.items()]
json.dump(dict(_note='DEV SEED ONLY - delete before production',exercises=exs,programs=progs),open('dev_programs.seed.json','w'),ensure_ascii=False,indent=1)
print(len(exs),'exercises',len(progs),'programs',sum(len(p['days']) for p in progs),'days')
