# YOUR COACH — Architecture (v0.1)

## Stack
- **Mobile:** Flutter (Android+iOS), Riverpod, go_router, Drift (SQLite) for offline, `intl` + RTL-first.
- **Backend:** Supabase (Postgres + Auth + Storage + Edge Functions + RLS).
- **Admin:** Next.js web app on the same Supabase (role-gated via `user_roles`).
- **AI:** Supabase Edge Function proxies the LLM API — keys never ship in the app.
- **Health:** `health` Flutter package → Health Connect (Android) / HealthKit (iOS).

## Key decisions
1. **Offline-first:** every log row has a client-generated `client_id` (UUID); sync is an idempotent upsert, last-write-wins per row.
2. **Official vs user content:** `owner_id IS NULL` = official (admin-only write, published-only read). Users' custom programs/foods use the same tables → one UI for both.
3. **Flexible cycles:** `programs.cycle` is an ordered list (e.g. Day1, Day2, Day3, REST, Day4, Day5, REST) — not tied to a 7-day week.
4. **Set model:** warm-up vs working sets, rep range, RIR range, rest range, back-off %, superset group.
5. **Data honesty:** `source` on food rows (`verified`/`user`/`ai_estimate`) → UI badges; AI results require user confirmation before saving.
6. **Safety:** `profiles.is_minor` blocks deficit/fat-loss plan generation; AI never mutates plans without confirmation.
7. **Privacy:** progress photos in a private bucket, signed URLs only; export + delete-account endpoints.

## Navigation (5 tabs)
Home · Training (programs, builder, library, history, PRs) · Nutrition (log, foods, recipes, plan, water) · Progress (measurements, cardio/activity, calendar, goals) · Profile (habits, settings, backup, AI entry).

## Phases (per your prompt)
- **P0 (this delivery):** schema, RLS, seed data, architecture.
- **P1:** auth, onboarding, RTL design system, dashboard, workout tracker/builder, food log, progress.
- **P2:** cardio, health sync, habits, calendar, recipes, barcode, videos.
- **P3:** AI edge functions. **P4:** admin dashboard. **P5:** QA/hardening.

## Needs from you (external credentials)
Supabase project (URL + anon key), LLM API key (server-side only), Apple/Google developer accounts for HealthKit/Health Connect release.

## Dev seed
`seed/dev_programs.seed.json` = 6 test programs, `is_dev_seed=true`, status `draft`, no trainer names/branding/videos. Delete with `delete from programs where is_dev_seed;` before launch.
