import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'cloud.dart';

/// AI calls with a personal key typed by the user (kept in the device keystore only; never in backups/exports/APK).
/// Two providers, detected from the key prefix:
///  - Google Gemini (key starts with "AIza") -> has a FREE tier via Google AI Studio.
///  - Anthropic Claude (key starts with "sk-ant-") -> paid API.
/// Fallback: the `ai` Edge Function when cloud is configured and the user is signed in.
class AiClient {
  static const _st = FlutterSecureStorage();
  static String? _key;
  static String model = 'gemini-2.5-flash';
  static const geminiDefault = 'gemini-2.5-flash';
  static const claudeDefault = 'claude-haiku-5-5';

  static Future<void> init() async {
    try {
      _key = await _st.read(key: 'ai_key');
      model = (await _st.read(key: 'ai_model')) ?? model;
    } catch (_) {}
  }

  static bool get hasKey => _key != null && _key!.isNotEmpty;
  static bool get available => hasKey || (Cloud.enabled && Cloud.user != null);
  static bool _isGemini(String? k) => k != null && k.startsWith('AIza');
  static String get provider => _isGemini(_key) ? 'gemini' : 'anthropic';
  static String _fit(String m, bool gemini) {
    if (gemini) return m.startsWith('gemini') ? m : geminiDefault;
    return m.startsWith('claude') ? m : claudeDefault;
  }
  /// Model actually used for the current key.
  static String get effectiveModel => hasKey ? _fit(model, _isGemini(_key)) : model;

  static Future<void> saveKey(String k, String m) async {
    _key = k.trim();
    model = _fit(m.trim().isEmpty ? model : m.trim(), _isGemini(_key));
    await _st.write(key: 'ai_key', value: _key);
    await _st.write(key: 'ai_model', value: model);
  }
  static Future<void> setModel(String m) async {
    if (m.trim().isEmpty) return;
    model = _fit(m.trim(), _isGemini(_key));
    await _st.write(key: 'ai_model', value: model);
  }
  static Future<void> clearKey() async {
    _key = null;
    await _st.delete(key: 'ai_key');
  }

  static const _safety = '''You are the assistant inside YOUR COACH, an Arabic-first fitness app. Reply in the user's language (Egyptian Arabic if they write Arabic).
Rules: general fitness/nutrition education only. Never diagnose injuries or conditions, never prescribe treatment or medication; for pain, injury or medical conditions tell the user to see a qualified professional.
Never recommend calorie deficits, weight-loss targets or restrictive diets to anyone under 18 (PROFILE minor=true); recommend balanced eating and professional guidance.
You cannot change the user's programs or nutrition targets; only suggest, the user decides in the app.
Never invent facts about the user's data. If the DATA block lacks what is needed, say so plainly.''';

  static const _sys = <String, String>{
    'train': 'Role: training assistant (exercises, programming principles, volume, progression, RPE/RIR, alternatives). Be concise.',
    'nutri': 'Role: nutrition assistant (calories, macros, substitutions, meal ideas). Give estimates as estimates.',
    'data': 'Role: answer questions ONLY from the DATA JSON provided (the user\'s own logs). Quote numbers from it; do not guess missing records.',
    'meal': '''Role: meal analyzer. Return ONLY JSON, no markdown, shape:
{"items":[{"name_ar":str,"name_en":str,"grams":number,"assumed":bool,"kcal":number,"protein":number,"carbs":number,"fat":number}],
 "uncertainty":"short honest note in the user's language about what is estimated","questions":[str]}
Use typical cooked-weight values (Egyptian foods where relevant). assumed=true when you guessed the quantity. Put clarifying questions in "questions" when quantities are unclear. Estimates, never exact.''',
  };

  /// Keeps only alternating user/assistant turns (a failed request can leave two user turns in a row).
  static List<Map<String, String>> _clean(List? raw) {
    final out = <Map<String, String>>[];
    for (final m in (raw ?? []).take(8)) {
      final role = '${m['role']}';
      if (role != 'user' && role != 'assistant') continue;
      final c = '${m['content']}';
      if (out.isEmpty && role == 'assistant') continue;
      if (out.isNotEmpty && out.last['role'] == role) {
        out.last = {'role': role, 'content': c};
      } else {
        out.add({'role': role, 'content': c});
      }
    }
    return out;
  }

  static Future<Map<String, dynamic>> call(Map<String, dynamic> body) async {
    if (!hasKey) return Cloud.ai(body);
    final mode = '${body['mode']}';
    if (!_sys.containsKey(mode)) throw ArgumentError('bad mode');
    final text = '${body['text']}'.trim();
    if (text.isEmpty) throw ArgumentError('empty');
    final hist = _clean(body['history'] as List?);
    final data = mode == 'data' ? 'DATA:\n${jsonEncode(body['data'] ?? {})}\n\n' : '';
    final userText = '${data}PROFILE: {"minor": ${body['minor'] == true}}\n\n$text';
    final system = '$_safety\n${_sys[mode]}';
    final reply = _isGemini(_key) ? await _gemini(system, hist, userText, mode) : await _claude(system, hist, userText);
    if (mode == 'meal') {
      try {
        return {'meal': jsonDecode(reply.replaceAll(RegExp(r'```json|```'), '').trim())};
      } catch (_) {
        throw StateError('الرد مش بصيغة مفهومة، جرّب تاني');
      }
    }
    return {'reply': reply};
  }

  static Never _fail(http.Response r) {
    final raw = utf8.decode(r.bodyBytes);
    var msg = '';
    try {
      msg = '${((jsonDecode(raw) as Map)['error'] as Map)['message']}';
    } catch (_) {}
    throw StateError('HTTP ${r.statusCode}${msg.isEmpty ? '' : ': ${msg.length > 140 ? msg.substring(0, 140) : msg}'}');
  }

  static Future<String> _claude(String system, List<Map<String, String>> hist, String userText) async {
    final r = await http.post(Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: {'content-type': 'application/json', 'x-api-key': _key!, 'anthropic-version': '2023-06-01'},
      body: jsonEncode({'model': effectiveModel, 'max_tokens': 1200, 'system': system, 'messages': [...hist, {'role': 'user', 'content': userText}]}),
    ).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) _fail(r);
    final out = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    return [for (final c in (out['content'] as List)) '${c['text'] ?? ''}'].join();
  }

  static Future<String> _gemini(String system, List<Map<String, String>> hist, String userText, String mode) async {
    final m = effectiveModel;
    final contents = [
      for (final h in hist) {'role': h['role'] == 'assistant' ? 'model' : 'user', 'parts': [{'text': h['content']}]},
      {'role': 'user', 'parts': [{'text': userText}]},
    ];
    final gen = <String, dynamic>{'maxOutputTokens': 2048};
    if (mode == 'meal') gen['responseMimeType'] = 'application/json';
    if (m.contains('flash')) gen['thinkingConfig'] = {'thinkingBudget': 0};
    final r = await http.post(Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent'),
      headers: {'content-type': 'application/json', 'x-goog-api-key': _key!},
      body: jsonEncode({'systemInstruction': {'parts': [{'text': system}]}, 'contents': contents, 'generationConfig': gen}),
    ).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) _fail(r);
    final out = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    final cands = out['candidates'] as List?;
    if (cands == null || cands.isEmpty) throw StateError('الرد اتحجب أو جه فاضي، جرّب صياغة تانية');
    final parts = ((cands.first as Map)['content'] as Map?)?['parts'] as List?;
    final text = [for (final p in (parts ?? [])) '${(p as Map)['text'] ?? ''}'].join();
    if (text.trim().isEmpty) throw StateError('الرد جه فاضي، جرّب تاني');
    return text;
  }
}
