import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'cloud.dart';

/// AI calls. Two paths:
///  1) Personal key (Anthropic API key typed by the user in the app, kept in the device keystore via flutter_secure_storage,
///     NEVER written to the JSON data file, export, or cloud backup, and never bundled in the APK).
///  2) Fallback: the `ai` Edge Function when cloud is configured and the user is signed in.
class AiClient {
  static const _st = FlutterSecureStorage();
  static String? _key;
  static String model = 'claude-haiku-5-5';

  static Future<void> init() async {
    try { _key = await _st.read(key: 'ai_key'); model = (await _st.read(key: 'ai_model')) ?? model; } catch (_) {}
  }
  static bool get hasKey => _key != null && _key!.isNotEmpty;
  static bool get available => hasKey || (Cloud.enabled && Cloud.user != null);
  static Future<void> saveKey(String k, String m) async {
    _key = k.trim(); if (m.trim().isNotEmpty) model = m.trim();
    await _st.write(key: 'ai_key', value: _key); await _st.write(key: 'ai_model', value: model);
  }
  static Future<void> setModel(String m) async { if (m.trim().isEmpty) return; model = m.trim(); await _st.write(key: 'ai_model', value: model); }
  static Future<void> clearKey() async { _key = null; await _st.delete(key: 'ai_key'); }

  static const _safety = '''You are the assistant inside YOUR COACH, an Arabic-first fitness app. Reply in the user's language (Egyptian Arabic if they write Arabic).
Rules: general fitness/nutrition education only. Never diagnose injuries or conditions, never prescribe treatment or medication; for pain, injury or medical conditions tell the user to see a qualified professional.
Never recommend calorie deficits, weight-loss targets or restrictive diets to anyone under 18 (PROFILE minor=true); recommend balanced eating and professional guidance.
You cannot change the user's programs or nutrition targets; only suggest, the user decides in the app.
Never invent facts about the user's data. If the DATA block lacks what is needed, say so plainly.''';

  static const _sys = <String, String>{
    'train': 'Role: training assistant (exercises, programming principles, volume, progression, RPE/RIR, alternatives). Be concise.',
    'nutri': 'Role: nutrition assistant (calories, macros, substitutions, meal ideas). Give estimates as estimates.',
    'data': 'Role: answer questions ONLY from the DATA JSON provided (the user\'s own logs). Quote numbers from it; do not guess missing records.',
    'meal': '''Role: meal analyzer. Return ONLY JSON, no markdown, shape:
{"items":[{"name_ar":str,"name_en":str,"grams":number,"assumed":bool,"kcal":number,"protein":number,"carbs":number,"fat":number}],
 "uncertainty":"short honest note in the user's language about what is estimated","questions":[str]}
Use typical cooked-weight values (Egyptian foods where relevant). assumed=true when you guessed the quantity. Put clarifying questions in "questions" when quantities are unclear. Estimates, never exact.''',
  };

  static Future<Map<String, dynamic>> call(Map<String, dynamic> body) async {
    if (!hasKey) return Cloud.ai(body);
    final mode = '${body['mode']}';
    if (!_sys.containsKey(mode)) throw ArgumentError('bad mode');
    final text = '${body['text']}'.trim();
    if (text.isEmpty) throw ArgumentError('empty');
    final hist = [for (final m in ((body['history'] as List?) ?? []).take(8)) if (m['role'] == 'user' || m['role'] == 'assistant') {'role': m['role'], 'content': '${m['content']}'}];
    final data = mode == 'data' ? 'DATA:\n${jsonEncode(body['data'] ?? {})}\n\n' : '';
    final msgs = [...hist, {'role': 'user', 'content': '${data}PROFILE: {"minor": ${body['minor'] == true}}\n\n$text'}];
    final r = await http.post(Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: {'content-type': 'application/json', 'x-api-key': _key!, 'anthropic-version': '2023-06-01'},
      body: jsonEncode({'model': model, 'max_tokens': 1200, 'system': '$_safety\n${_sys[mode]}', 'messages': msgs}),
    ).timeout(const Duration(seconds: 60));
    final respBody = utf8.decode(r.bodyBytes);
    if (r.statusCode != 200) {
      var msg = '';
      try { msg = '${((jsonDecode(respBody) as Map)['error'] as Map)['message']}'; } catch (_) {}
      throw StateError('HTTP ${r.statusCode}${msg.isEmpty ? '' : ': ${msg.length > 140 ? msg.substring(0, 140) : msg}'}');
    }
    final out = jsonDecode(respBody) as Map<String, dynamic>;
    final reply = [for (final c in (out['content'] as List)) '${c['text'] ?? ''}'].join();
    if (mode == 'meal') {
      try { return {'meal': jsonDecode(reply.replaceAll(RegExp(r'```json|```'), '').trim())}; } catch (_) { throw StateError('الرد مش بصيغة مفهومة، جرّب تاني'); }
    }
    return {'reply': reply};
  }
}
