import 'package:health/health.dart';
import 'store.dart';

/// Reads today's step total from Health Connect (Android) / HealthKit (iOS) after explicit permission.
/// Uses the platform's aggregated total (getTotalStepsInInterval) so multiple sources are de-duplicated by the OS, not summed by us.
/// UNTESTED on a device: needs Health Connect / HealthKit setup (see README) and the `health` package API may differ by version.
class HealthSync {
  static final _h = Health();
  static Future<bool> syncSteps(Store s) async {
    try {
      await _h.configure();
      final ok = await _h.requestAuthorization([HealthDataType.STEPS], permissions: [HealthDataAccess.READ]);
      if (!ok) return false;
      final now = DateTime.now();
      final n = await _h.getTotalStepsInInterval(DateTime(now.year, now.month, now.day), now);
      if (n == null) return false;
      await s.setSteps(Store.dayKey(now), n);
      return true;
    } catch (_) { return false; }
  }
}
