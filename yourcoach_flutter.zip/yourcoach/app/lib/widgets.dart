import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'store.dart';
import 'theme.dart';

/// Wraps numbers/units so they keep left-to-right order inside Arabic text (e.g. "92 / 160").
String ltr(String x) => '\u2066$x\u2069';

class Tag extends StatelessWidget {
  final String text;
  final bool hot;
  const Tag(this.text, {super.key, this.hot = false});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(color: hot ? accentSoft : surface3, borderRadius: BorderRadius.circular(99)),
        child: Text(text, style: TextStyle(fontSize: 11.5, color: hot ? accent : muted, fontWeight: FontWeight.w600)),
      );
}

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.fromSTEB(4, 22, 4, 6),
        child: Text(text, style: const TextStyle(color: muted, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: .3)),
      );
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;
  final VoidCallback? onTap;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.margin = const EdgeInsets.symmetric(vertical: 6), this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        margin: margin,
        decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: line)),
        child: Material(
          color: Colors.transparent, borderRadius: BorderRadius.circular(22), clipBehavior: Clip.antiAlias,
          child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
        ),
      );
}

class IconBox extends StatelessWidget {
  final IconData icon;
  final double size;
  const IconBox(this.icon, {super.key, this.size = 40});
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(color: surface2, borderRadius: BorderRadius.circular(size * .32)),
        child: Icon(icon, color: accent, size: size * .5),
      );
}

class CalorieRing extends StatelessWidget {
  final double value, target, size;
  final String big, small;
  const CalorieRing({super.key, required this.value, required this.target, required this.big, required this.small, this.size = 120});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: size, height: size,
        child: Stack(alignment: Alignment.center, children: [
          CustomPaint(size: Size(size, size), painter: _RingPainter(target > 0 ? (value / target).clamp(0.0, 1.0).toDouble() : 0.0)),
          Column(mainAxisSize: MainAxisSize.min, children: [
            Text(big, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, height: 1.1)),
            Text(small, style: const TextStyle(fontSize: 11, color: muted)),
          ]),
        ]),
      );
}

class _RingPainter extends CustomPainter {
  final double pct;
  _RingPainter(this.pct);
  @override
  void paint(Canvas canvas, Size size) {
    final r = (size.width - 14) / 2;
    final ctr = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(ctr, r, Paint()..color = surface3..style = PaintingStyle.stroke..strokeWidth = 10);
    if (pct > 0) {
      final p = Paint()..color = accent..style = PaintingStyle.stroke..strokeWidth = 10..strokeCap = StrokeCap.round;
      canvas.drawArc(Rect.fromCircle(center: ctr, radius: r), -math.pi / 2, 2 * math.pi * pct, false, p);
    }
  }
  @override
  bool shouldRepaint(_RingPainter old) => old.pct != pct;
}

class MacroBar extends StatelessWidget {
  final String label, unit;
  final double value;
  final num? target;
  final Color color;
  const MacroBar(this.label, this.value, this.target, this.color, {super.key, this.unit = 'g'});
  @override
  Widget build(BuildContext context) {
    final frac = (target != null && target! > 0) ? (value / target!).clamp(0.0, 1.0).toDouble() : 0.0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(children: [
        Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 13.5))),
          Text(ltr(target == null ? '${value.round()} $unit' : '${value.round()} / $target $unit'), style: const TextStyle(color: muted, fontSize: 12.5)),
        ]),
        const SizedBox(height: 6),
        ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: frac, minHeight: 7, color: color, backgroundColor: surface3)),
      ]),
    );
  }
}

class WeekStrip extends StatelessWidget {
  final Set<String> doneDays;
  final bool ar;
  const WeekStrip(this.doneDays, {super.key, required this.ar});
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day - ((now.weekday + 1) % 7));
    final names = ar ? ['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج'] : ['S', 'S', 'M', 'T', 'W', 'T', 'F'];
    final today = Store.dayKey(now);
    return Row(children: [
      for (var i = 0; i < 7; i++)
        Expanded(child: Builder(builder: (_) {
          final k = Store.dayKey(DateTime(start.year, start.month, start.day + i));
          final done = doneDays.contains(k);
          return Column(children: [
            Text(names[i], style: TextStyle(fontSize: 12, color: k == today ? txt : muted)),
            const SizedBox(height: 6),
            Container(
              width: 30, height: 30,
              decoration: BoxDecoration(shape: BoxShape.circle, color: done ? accent : Colors.transparent,
                border: Border.all(color: k == today && !done ? txt : (done ? accent : line), width: 1.5)),
              child: done ? const Icon(Icons.check, size: 17, color: Color(0xFF0B0B0C)) : null,
            ),
          ]);
        })),
    ]);
  }
}

/// Modern top bar for sub-pages: round back button + big title (replaces the default AppBar look).
class ModernBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget> actions;
  const ModernBar(this.title, {super.key, this.actions = const []});
  @override
  Size get preferredSize => const Size.fromHeight(68);
  @override
  Widget build(BuildContext context) => SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
          child: Row(children: [
            IconButton(
              style: IconButton.styleFrom(backgroundColor: surface, side: const BorderSide(color: line)),
              icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.maybePop(context)),
            const SizedBox(width: 12),
            Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
            ...actions,
          ]),
        ),
      );
}

/// Big highlighted card (today's workout): soft accent gradient + accent border.
class HeroCard extends StatelessWidget {
  final Widget child;
  const HeroCard({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(begin: AlignmentDirectional.topStart, end: AlignmentDirectional.bottomEnd, colors: [Color(0x33C8F542), surface]),
          border: Border.all(color: accent.withOpacity(.28)),
        ),
        child: child,
      );
}
