import 'dart:math';

/// Pure nutrition maths (Mifflin-St Jeor). Estimates only.
const activityFactors = {'sedentary': 1.2, 'light': 1.375, 'moderate': 1.55, 'high': 1.725};

double bmr({required String sex, required double kg, required double cm, required int age}) =>
    10 * kg + 6.25 * cm - 5 * age + (sex == 'male' ? 5 : -161);

class Target {
  final int kcal, p, c, f;
  const Target(this.kcal, this.p, this.c, this.f);
}

/// deltaKcal: negative = deficit, positive = surplus. Floor protects against unsafe targets.
Target buildTarget({required double tdee, required int deltaKcal, required double kg,
    required double proteinPerKg, required double fatPct, required String sex}) {
  final floor = sex == 'male' ? 1500 : 1200;
  final kcal = max(floor, (tdee + deltaKcal).round());
  final p = (kg * proteinPerKg).round();
  final f = (kcal * fatPct / 9).round();
  final c = max(0, ((kcal - p * 4 - f * 9) / 4).round());
  return Target(kcal, p, c, f);
}
