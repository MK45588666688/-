import 'package:flutter/material.dart';

const bg = Color(0xFF09090B), surface = Color(0xFF131316), surface2 = Color(0xFF1B1B1F), surface3 = Color(0xFF242429),
    line = Color(0xFF26262C), accent = Color(0xFFFF6A2B), muted = Color(0xFF8D8D97), txt = Color(0xFFF4F4F5),
    accentSoft = Color(0x29FF6A2B), cP = Color(0xFF6EA8FF), cC = Color(0xFFF5B84B), cF = Color(0xFFE87FA6);

ThemeData darkTheme() {
  const scheme = ColorScheme.dark(primary: accent, onPrimary: Color(0xFF0B0B0C), secondary: accent, surface: surface, onSurface: txt, outline: line);
  final r16 = RoundedRectangleBorder(borderRadius: BorderRadius.circular(16));
  return ThemeData(
    brightness: Brightness.dark, useMaterial3: true, scaffoldBackgroundColor: bg, colorScheme: scheme,
    cardTheme: CardThemeData(color: surface, elevation: 0, margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: line))),
    appBarTheme: const AppBarTheme(backgroundColor: bg, surfaceTintColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0, centerTitle: false,
      titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: txt)),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: surface, surfaceTintColor: Colors.transparent, height: 70, indicatorColor: accentSoft,
      labelTextStyle: WidgetStateProperty.resolveWith((st) => TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: st.contains(WidgetState.selected) ? accent : muted)),
      iconTheme: WidgetStateProperty.resolveWith((st) => IconThemeData(color: st.contains(WidgetState.selected) ? accent : muted))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: surface2, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: accent, width: 1.2)),
      hintStyle: const TextStyle(color: muted)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: accent, foregroundColor: const Color(0xFF0B0B0C),
      minimumSize: const Size.fromHeight(54), shape: r16, textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(foregroundColor: txt, minimumSize: const Size.fromHeight(54),
      side: const BorderSide(color: line), shape: r16, textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: accent, textStyle: const TextStyle(fontWeight: FontWeight.w700))),
    chipTheme: ChipThemeData(backgroundColor: surface2, selectedColor: accentSoft, side: const BorderSide(color: line), shape: const StadiumBorder(),
      labelStyle: const TextStyle(color: txt, fontSize: 13.5), checkmarkColor: accent, showCheckmark: false),
    bottomSheetTheme: const BottomSheetThemeData(backgroundColor: surface, surfaceTintColor: Colors.transparent, showDragHandle: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28)))),
    dialogTheme: DialogThemeData(backgroundColor: surface, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
    dividerTheme: const DividerThemeData(color: line, space: 1, thickness: 1),
    segmentedButtonTheme: SegmentedButtonThemeData(style: ButtonStyle(
      backgroundColor: WidgetStateProperty.resolveWith((st) => st.contains(WidgetState.selected) ? accentSoft : surface2),
      foregroundColor: WidgetStateProperty.resolveWith((st) => st.contains(WidgetState.selected) ? accent : muted),
      side: const WidgetStatePropertyAll(BorderSide(color: line)))),
    floatingActionButtonTheme: FloatingActionButtonThemeData(backgroundColor: accent, foregroundColor: const Color(0xFF0B0B0C),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), extendedTextStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
    snackBarTheme: SnackBarThemeData(backgroundColor: surface3, contentTextStyle: const TextStyle(color: txt), behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
  );
}
