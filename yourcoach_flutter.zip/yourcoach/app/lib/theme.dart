import 'package:flutter/material.dart';
const bg = Color(0xFF0B0B0C), surface = Color(0xFF161618), surface2 = Color(0xFF202023),
  line = Color(0xFF2A2A2E), accent = Color(0xFFFF5A1F), muted = Color(0xFF9A9AA2);
ThemeData darkTheme() => ThemeData(
  brightness: Brightness.dark, scaffoldBackgroundColor: bg, useMaterial3: true,
  colorScheme: const ColorScheme.dark(primary: accent, surface: surface),
  cardTheme: CardThemeData(color: surface, elevation: 0, margin: const EdgeInsets.symmetric(vertical: 6),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: line))),
  appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0, centerTitle: false),
  navigationBarTheme: NavigationBarThemeData(backgroundColor: surface, indicatorColor: accent.withOpacity(.18)),
  inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: surface2,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
  filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
    minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
);
