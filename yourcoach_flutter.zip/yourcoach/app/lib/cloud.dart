import 'package:supabase_flutter/supabase_flutter.dart';

const _url = String.fromEnvironment('SUPABASE_URL');
const _key = String.fromEnvironment('SUPABASE_ANON_KEY');

/// Optional cloud layer. Without --dart-define values the app is fully local.
/// Run: flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
class Cloud {
  static bool get enabled => _url.isNotEmpty && _key.isNotEmpty;
  static Future<void> init() async {
    if (enabled) await Supabase.initialize(url: _url, anonKey: _key);
  }
  static SupabaseClient get _c => Supabase.instance.client;
  static User? get user => enabled ? _c.auth.currentUser : null;

  static Future<void> signIn(String e, String p) => _c.auth.signInWithPassword(email: e, password: p);
  static Future<void> signUp(String e, String p) => _c.auth.signUp(email: e, password: p);
  static Future<void> signOut() => _c.auth.signOut();

  /// Snapshot backup: whole user data as one JSON row (RLS: own row only).
  static Future<void> push(Map<String, dynamic> data) async {
    final u = user;
    if (u == null) return;
    await _c.from('user_snapshots').upsert({'user_id': u.id, 'data': data, 'updated_at': DateTime.now().toUtc().toIso8601String()});
  }

  static Future<Map<String, dynamic>?> pull() async {
    final u = user;
    if (u == null) return null;
    final r = await _c.from('user_snapshots').select('data').eq('user_id', u.id).maybeSingle();
    return r == null ? null : Map<String, dynamic>.from(r['data'] as Map);
  }

  /// Calls the `ai` Edge Function (needs sign-in). Throws if cloud is off or the call fails.
  static Future<Map<String, dynamic>> ai(Map<String, dynamic> body) async {
    if (user == null) throw StateError('signed_out');
    final r = await _c.functions.invoke('ai', body: body);
    return Map<String, dynamic>.from(r.data as Map);
  }

  /// Official content managed from the admin dashboard (published only; readable without sign-in by RLS).
  /// Converted to the same shapes the app already uses for its local seed.
  static Future<Map<String, dynamic>> fetchContent() async {
    final progs = await _c.from('programs').select('*, program_days(*, program_exercises(*, exercises(key)))').eq('status', 'published').isFilter('owner_id', null);
    final exs = await _c.from('exercises').select().eq('status', 'published');
    final foods = await _c.from('foods').select().eq('status', 'published').isFilter('owner_id', null);
    final arts = await _c.from('articles').select().eq('status', 'published');
    int? i(dynamic v) => v == null ? null : (v as num).toInt();
    return {
      'programs': [
        for (final p in progs) () {
          final days = List<Map<String, dynamic>>.from((p['program_days'] as List).map((d) => Map<String, dynamic>.from(d as Map)))
            ..sort((a, b) => (a['position'] as int).compareTo(b['position'] as int));
          final cyc = (p['cycle'] as List?)?.cast<String>() ?? [];
          return {
            'slug': p['slug'], 'title_ar': p['title_ar'], 'title_en': p['title_en'] ?? p['title_ar'], 'level': p['level'], 'goal': p['goal'],
            'days_per_week': p['days_per_week'], 'split_type': p['split_type'], 'status': 'published', 'source': 'official',
            'cycle': cyc.isNotEmpty ? cyc : [for (final d in days) d['name']],
            'days': [for (final d in days) {
              'name': d['name'], 'focus': d['focus'],
              'exercises': [for (final e in (List<Map<String, dynamic>>.from((d['program_exercises'] as List).map((x) => Map<String, dynamic>.from(x as Map)))
                  ..sort((a, b) => (a['position'] as int).compareTo(b['position'] as int)))) {
                'exercise_key': (e['exercises'] as Map)['key'], 'sets_min': i(e['sets_min']), 'sets_max': i(e['sets_max']), 'reps_min': i(e['reps_min']), 'reps_max': i(e['reps_max']),
                'warmup_sets': i(e['warmup_sets']) ?? 0, 'rir_min': e['rir_min'], 'rir_max': e['rir_max'], 'rest_min_sec': i(e['rest_min_sec']), 'rest_max_sec': i(e['rest_max_sec']),
              }],
            }],
          };
        }()
      ],
      'exercises': [for (final e in exs) {'key': e['key'], 'name_ar': e['name_ar'], 'name_en': e['name_en'], 'muscle': e['muscle'], 'equipment': e['equipment'],
        'video_url': e['video_url'], 'status': 'published', 'instructions_ar': e['instructions_ar'], 'common_mistakes_ar': e['common_mistakes_ar']}],
      'foods': [for (final f in foods) {'id': f['id'], 'ar': f['name_ar'], 'en': f['name_en'] ?? f['name_ar'], 'k': f['kcal_100g'], 'p': f['protein_100g'],
        'c': f['carbs_100g'], 'f': f['fat_100g'], 'srv': f['serving_g'] ?? 100, 'src': f['source']}],
      'articles': [for (final a in arts) {'id': a['id'], 'category': a['category'], 'title_ar': a['title_ar'], 'title_en': a['title_en'], 'body_ar': a['body_ar'], 'body_en': a['body_en']}],
    };
  }
}
