import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'plans.dart';
import 'recipes.dart';
import 'report.dart';
import 'planner.dart';
import 'barcode.dart';

const mealTypes = ['breakfast', 'lunch', 'dinner', 'snack'];

class NutritionPage extends StatelessWidget {
  final Store s;
  const NutritionPage(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final day = Store.dayKey();
        final tot = s.totals(day);
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(backgroundColor: accent, foregroundColor: Colors.black,
            onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: surface,
              builder: (_) => AddFoodSheet(s)),
            icon: const Icon(Icons.add), label: Text(s.t('add_food'))),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              Expanded(child: Text(s.t('nutrition'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
              IconButton(tooltip: s.t('plans'), icon: const Icon(Icons.track_changes), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlansPage(s)))),
              IconButton(tooltip: s.t('recipes'), icon: const Icon(Icons.menu_book), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RecipesPage(s)))),
              IconButton(tooltip: s.t('planner'), icon: const Icon(Icons.calendar_view_week), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlannerPage(s)))),
              IconButton(tooltip: s.t('barcode'), icon: const Icon(Icons.qr_code_scanner), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BarcodePage(s)))),
              IconButton(tooltip: s.t('report'), icon: const Icon(Icons.bar_chart), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportPage(s)))),
              IconButton(tooltip: s.t('copy_yday'), icon: const Icon(Icons.copy_all), onPressed: s.copyYesterday),
            ]),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${tot['k']!.round()}${s.activePlan != null ? ' / ${s.activePlan!['kcal']}' : ''} ${s.t('calories')}', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              if (s.activePlan != null) Padding(padding: const EdgeInsets.only(top: 6), child: LinearProgressIndicator(
                value: (tot['k']! / (s.activePlan!['kcal'] as num)).clamp(0.0, 1.0).toDouble(), color: accent, backgroundColor: surface2)),
              if (s.activePlan != null) Text('${s.t('protein')} ${s.activePlan!['p']}g • ${s.t('carbs')} ${s.activePlan!['c']}g • ${s.t('fat')} ${s.activePlan!['f']}g', style: const TextStyle(color: muted, fontSize: 12)),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('${s.t('protein')} ${tot['p']!.round()}g'), Text('${s.t('carbs')} ${tot['c']!.round()}g'), Text('${s.t('fat')} ${tot['f']!.round()}g')]),
              const SizedBox(height: 6),
              Text(s.t('estimate'), style: const TextStyle(color: muted, fontSize: 11)),
            ]))),
            for (final t in mealTypes) ...[
              Padding(padding: const EdgeInsets.only(top: 12, bottom: 2), child: Text(s.t(t), style: const TextStyle(color: muted))),
              for (final m in s.mealsOn(day).where((m) => m['type'] == t))
                Card(child: ListTile(
                  title: Text(s.lang == 'ar' ? m['label'] : m['label_en']),
                  subtitle: Text('${(m['g'] as num).round()} g • P${(m['p'] as num).round()} C${(m['c'] as num).round()} F${(m['f'] as num).round()}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('${(m['k'] as num).round()}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => s.removeMeal(m['id'])),
                  ]),
                )),
            ],
            const SizedBox(height: 80),
          ]),
        );
      });
}

class AddFoodSheet extends StatefulWidget {
  final Store s;
  const AddFoodSheet(this.s, {super.key});
  @override
  State<AddFoodSheet> createState() => _AddFoodState();
}

class _AddFoodState extends State<AddFoodSheet> {
  String q = '';
  Map<String, dynamic>? sel;
  final g = TextEditingController();
  String type = 'lunch';

  /// Light Arabic normalisation so أ/إ/آ→ا, ة→ه, ى→ي all match.
  String norm(String x) => x.toLowerCase().replaceAll(RegExp('[أإآ]'), 'ا').replaceAll('ة', 'ه').replaceAll('ى', 'ي');

  Future<void> addCustom() async {
    final s = widget.s;
    final n = TextEditingController(), k = TextEditingController(), p = TextEditingController(), c = TextEditingController(), f = TextEditingController();
    Widget fld(String l, TextEditingController t, {bool num = true}) => Padding(padding: const EdgeInsets.only(bottom: 8),
      child: TextField(controller: t, keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: l)));
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text('${s.t('custom_food')} (${s.t('per100')})'),
      content: SingleChildScrollView(child: Column(children: [fld(s.t('name'), n, num: false), fld(s.t('calories'), k), fld(s.t('protein'), p), fld(s.t('carbs'), c), fld(s.t('fat'), f)])),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('save')))]));
    double v(TextEditingController t) => double.tryParse(t.text.replaceAll(',', '.')) ?? 0;
    if (ok == true && n.text.trim().isNotEmpty && v(k) >= 0) {
      final food = {'id': 'u${DateTime.now().millisecondsSinceEpoch}', 'ar': n.text.trim(), 'en': n.text.trim(), 'k': v(k), 'p': v(p), 'c': v(c), 'f': v(f), 'srv': 100, 'source': 'user'};
      await s.addCustomFood(food);
      setState(() { sel = food; g.text = '100'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final res = s.allFoods.where((f) => norm('${f['ar']} ${f['en']}').contains(norm(q))).toList();
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SizedBox(height: MediaQuery.of(context).size.height * .7, child: sel == null
        ? Column(children: [
            TextField(autofocus: true, onChanged: (v) => setState(() => q = v),
              decoration: InputDecoration(hintText: s.t('search_food'), prefixIcon: const Icon(Icons.search))),
            Expanded(child: ListView(children: [
              ListTile(leading: const Icon(Icons.add_circle_outline, color: accent), title: Text(s.t('custom_food')), onTap: addCustom),
              for (final f in res) ListTile(
              title: Text(s.foodName(f)), subtitle: Text('${f['k']} kcal / 100g'),
              onTap: () => setState(() { sel = f; g.text = '${f['srv']}'; }))])),
          ])
        : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.foodName(sel!), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            TextField(controller: g, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}),
              decoration: InputDecoration(suffixText: s.t('grams'))),
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [for (final t in mealTypes) ChoiceChip(label: Text(s.t(t)), selected: type == t, onSelected: (_) => setState(() => type = t))]),
            const SizedBox(height: 12),
            Text('≈ ${((double.tryParse(g.text) ?? 0) * (sel!['k'] as num) / 100).round()} kcal  (${s.t('estimate')})', style: const TextStyle(color: muted)),
            const Spacer(),
            FilledButton(onPressed: () async {
              final grams = double.tryParse(g.text);
              if (grams == null || grams <= 0) return;
              await s.addMeal(sel!, grams, type);
              if (context.mounted) Navigator.pop(context);
            }, child: Text(s.t('add'))),
          ])),
    );
  }
}
