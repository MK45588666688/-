import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// Manual cardio log + history + 7-day chart. Wearable sync is NOT connected yet (see cardio_note).
class CardioPage extends StatelessWidget {
  final Store s;
  const CardioPage(this.s, {super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final days = [for (var i = 6; i >= 0; i--) Store.dayKey(DateTime.now().subtract(Duration(days: i)))];
        final mins = [for (final d in days) s.cardioMinsOn(d)];
        final total = mins.fold(0.0, (a, b) => a + b);
        final list = s.cardio.reversed.take(30).toList();
        return Scaffold(
          appBar: AppBar(title: Text(s.t('cardio'))),
          floatingActionButton: FloatingActionButton.extended(
            backgroundColor: accent, foregroundColor: Colors.black,
            onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: surface, builder: (_) => _AddCardio(s)),
            icon: const Icon(Icons.add), label: Text(s.t('add_cardio'))),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.t('week_total'), style: const TextStyle(color: muted)),
              Text('${total.round()} ${s.t('min')}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              SizedBox(height: 90, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (var i = 0; i < 7; i++) Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 3), child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Container(height: mins.reduce((a, b) => a > b ? a : b) == 0 ? 2 : 4 + 66 * mins[i] / mins.reduce((a, b) => a > b ? a : b),
                    decoration: BoxDecoration(color: mins[i] > 0 ? accent : surface2, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(height: 4),
                  Text(days[i].substring(8), style: const TextStyle(color: muted, fontSize: 10)),
                ]))),
              ])),
            ]))),
            Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Text(s.t('cardio_note'), style: const TextStyle(color: muted, fontSize: 11))),
            if (list.isEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(s.t('no_data'), style: const TextStyle(color: muted))),
            for (final c in list) Card(child: ListTile(
              title: Text(s.t('c_${c['type']}')),
              subtitle: Text([
                c['day'],
                if (c['km'] != null) '${c['km']} km • ${((c['km'] as num) / ((c['mins'] as num) / 60)).toStringAsFixed(1)} km/h',
                if (c['hr'] != null) '${c['hr']} bpm',
                if ((c['note'] ?? '').toString().isNotEmpty) c['note'],
              ].join(' • ')),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                Text('${(c['mins'] as num).round()} ${s.t('min')}', style: const TextStyle(fontWeight: FontWeight.w700)),
                IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => s.removeCardio(c['id'])),
              ]))),
            const SizedBox(height: 80),
          ]),
        );
      });
}

class _AddCardio extends StatefulWidget {
  final Store s;
  const _AddCardio(this.s);
  @override
  State<_AddCardio> createState() => _AddCardioState();
}

class _AddCardioState extends State<_AddCardio> {
  String type = 'walking';
  final mins = TextEditingController(), km = TextEditingController(), hr = TextEditingController(), note = TextEditingController();
  double? _d(String t) => double.tryParse(t.trim().replaceAll(',', '.'));

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(spacing: 8, runSpacing: 4, children: [
          for (final t in Store.cardioTypes) ChoiceChip(label: Text(s.t('c_$t')), selected: type == t, selectedColor: accent.withOpacity(.3), onSelected: (_) => setState(() => type = t)),
        ]),
        const SizedBox(height: 12),
        TextField(controller: mins, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: s.t('minutes'))),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: km, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: '${s.t('distance')} (${s.t('optional')})'))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: hr, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '${s.t('avg_hr')} (${s.t('optional')})'))),
        ]),
        const SizedBox(height: 8),
        TextField(controller: note, decoration: InputDecoration(labelText: s.t('notes'))),
        const SizedBox(height: 12),
        FilledButton(onPressed: () {
          final m = _d(mins.text), k = _d(km.text), h = int.tryParse(hr.text.trim());
          if (m == null || m <= 0 || m > 1440) return;
          if (k != null && (k <= 0 || k > 1000)) return;
          if (h != null && (h < 30 || h > 230)) return;
          s.addCardio(type, m, km: k, hr: h, note: note.text.trim());
          Navigator.pop(context);
        }, child: Text(s.t('save'))),
      ])),
    );
  }
}
