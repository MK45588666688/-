import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'nutrition.dart' show mealTypes;

/// Weekly meal planner (by weekday) + auto-generated shopping list. Nutrition values = food database estimates.
class PlannerPage extends StatefulWidget {
  final Store s;
  const PlannerPage(this.s, {super.key});
  @override
  State<PlannerPage> createState() => _PlannerState();
}

class _PlannerState extends State<PlannerPage> {
  int dow = DateTime.now().weekday;
  static const arDays = {6: 'سبت', 7: 'أحد', 1: 'اثنين', 2: 'ثلاثاء', 3: 'أربعاء', 4: 'خميس', 5: 'جمعة'};
  static const enDays = {6: 'Sat', 7: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri'};
  static const order = [6, 7, 1, 2, 3, 4, 5];

  Future<void> _add(BuildContext context, String type) async {
    final s = widget.s;
    final f = await showModalBottomSheet<Map<String, dynamic>>(context: context, isScrollControlled: true, backgroundColor: surface, builder: (_) => _Pick(s));
    if (f == null || !context.mounted) return;
    final c = TextEditingController(text: '${f['srv'] ?? 100}');
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(s.foodName(f)),
      content: TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(suffixText: s.t('grams'))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('add'))),
      ]));
    final g = double.tryParse(c.text.replaceAll(',', '.'));
    if (ok == true && g != null && g > 0 && g <= 5000) await s.addPlanItem(dow, type, f, g);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(listenable: s, builder: (_, __) {
      final items = s.planOn(dow);
      double k = 0;
      for (final it in items) {
        final f = s.allFoods.where((x) => x['id'] == it['food']).firstOrNull;
        if (f != null) k += f['k'] * (it['g'] as num) / 100;
      }
      return Scaffold(
        appBar: ModernBar(s.t('planner'), actions: [
          IconButton(tooltip: s.t('shopping'), icon: const Icon(Icons.shopping_cart_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShoppingPage(s)))),
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
            for (final d in order) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(
              label: Text(s.lang == 'ar' ? arDays[d]! : enDays[d]!), selected: dow == d, selectedColor: accent.withOpacity(.3),
              onSelected: (_) => setState(() => dow = d))),
          ])),
          const SizedBox(height: 8),
          Text('${k.round()} kcal • ${s.t('estimate')}', style: const TextStyle(color: muted)),
          for (final t in mealTypes) ...[
            Row(children: [
              Expanded(child: Padding(padding: const EdgeInsets.only(top: 12), child: Text(s.t(t), style: const TextStyle(color: muted)))),
              IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => _add(context, t)),
            ]),
            for (final it in items.where((x) => x['type'] == t)) Card(child: ListTile(
              title: Text(s.lang == 'ar' ? it['ar'] : it['en']), subtitle: Text('${(it['g'] as num).round()} g'),
              trailing: IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => s.removePlanItem(it['id'])))),
          ],
          const SizedBox(height: 12),
          if (items.isEmpty) Text(s.t('plan_empty'), style: const TextStyle(color: muted))
          else OutlinedButton(onPressed: () async { await s.logPlanDay(dow); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('done')))); },
            child: Text(s.t('log_day_plan'))),
        ]),
      );
    });
  }
}

class _Pick extends StatefulWidget {
  final Store s;
  const _Pick(this.s);
  @override
  State<_Pick> createState() => _PickState();
}

class _PickState extends State<_Pick> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final qq = q.trim().toLowerCase();
    final res = s.allFoods.where((f) => qq.isEmpty || '${f['ar']} ${f['en']}'.toLowerCase().contains(qq)).take(40).toList();
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
      child: SizedBox(height: 420, child: Column(children: [
        TextField(autofocus: true, decoration: InputDecoration(hintText: s.t('search_food'), prefixIcon: const Icon(Icons.search)), onChanged: (v) => setState(() => q = v)),
        Expanded(child: ListView(children: [for (final f in res) ListTile(title: Text(s.foodName(f)), subtitle: Text('${f['k']} kcal / 100 g'), onTap: () => Navigator.pop(context, f))])),
      ])),
    );
  }
}

class ShoppingPage extends StatelessWidget {
  final Store s;
  const ShoppingPage(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final tot = s.shoppingTotals();
        final rows = tot.entries.map((e) => (s.allFoods.where((f) => '${f['id']}' == e.key).firstOrNull, e.key, e.value)).toList();
        return Scaffold(
          appBar: ModernBar(s.t('shopping')),
          body: rows.isEmpty
              ? Center(child: Text(s.t('plan_empty'), style: const TextStyle(color: muted)))
              : ListView(padding: const EdgeInsets.all(16), children: [
                  for (final r in rows) Card(child: CheckboxListTile(
                    value: s.shopChecked.contains(r.$2), activeColor: accent, onChanged: (_) => s.toggleShop(r.$2),
                    title: Text(r.$1 == null ? r.$2 : s.foodName(r.$1!)),
                    subtitle: const Text(''), secondary: Text('${r.$3.round()} g', style: const TextStyle(fontWeight: FontWeight.w700)))),
                ]),
        );
      });
}
