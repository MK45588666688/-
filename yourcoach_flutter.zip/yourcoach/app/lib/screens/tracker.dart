import 'dart:async';
import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'training.dart' show rng;

/// Gym-mode workout logger: big controls, previous performance, auto rest timer.
class TrackerPage extends StatefulWidget {
  final Store s;
  final Map<String, dynamic> day;
  final String slug;
  const TrackerPage(this.s, this.day, this.slug, {super.key});
  @override
  State<TrackerPage> createState() => _TrackerState();
}

class _SetRow {
  final bool warm;
  final kg = TextEditingController();
  final reps = TextEditingController();
  bool done = false;
  _SetRow(this.warm);
}

class _TrackerState extends State<TrackerPage> {
  late final List<Map<String, dynamic>> exs;
  late final List<List<_SetRow>> rows;
  final started = DateTime.now();
  int rest = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    exs = (widget.day['exercises'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
    rows = [for (final x in exs) [
      for (var i = 0; i < ((x['warmup_sets'] ?? 0) as int); i++) _SetRow(true),
      for (var i = 0; i < (x['sets_max'] as int); i++) _SetRow(false),
    ]];
  }

  @override
  void dispose() {
    timer?.cancel();
    for (final r in rows) { for (final x in r) { x.kg.dispose(); x.reps.dispose(); } }
    super.dispose();
  }

  void startRest(int sec) {
    timer?.cancel();
    setState(() => rest = sec);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (rest <= 1) { t.cancel(); setState(() => rest = 0); } else { setState(() => rest--); }
    });
  }

  Future<void> finish() async {
    final sets = <Map<String, dynamic>>[];
    for (var i = 0; i < exs.length; i++) {
      var n = 0;
      for (final r in rows[i]) {
        n++;
        if (!r.done) continue;
        sets.add({'key': exs[i]['exercise_key'], 'n': n, 'warm': r.warm,
          'kg': double.tryParse(r.kg.text.replaceAll(',', '.')) ?? 0, 'reps': int.tryParse(r.reps.text) ?? 0});
      }
    }
    if (sets.isEmpty) { Navigator.pop(context); return; }
    await widget.s.addSession({'at': DateTime.now().toIso8601String(), 'slug': widget.slug,
      'day': widget.day['name'], 'mins': DateTime.now().difference(started).inMinutes, 'sets': sets});
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Scaffold(
      appBar: AppBar(title: Text(widget.day['name']), actions: [TextButton(onPressed: finish, child: Text(s.t('finish')))]),
      body: Column(children: [
        if (rest > 0) Container(color: accent, padding: const EdgeInsets.all(10), child: Row(children: [
          const Icon(Icons.timer, color: Colors.black), const SizedBox(width: 8),
          Text('${s.t('rest')} ${rest ~/ 60}:${(rest % 60).toString().padLeft(2, '0')}',
            style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w800, fontSize: 18)),
          const Spacer(),
          TextButton(onPressed: () { timer?.cancel(); setState(() => rest = 0); }, child: Text(s.t('skip'), style: const TextStyle(color: Colors.black))),
        ])),
        Expanded(child: ListView.builder(padding: const EdgeInsets.all(12), itemCount: exs.length, itemBuilder: (_, i) {
          final x = exs[i];
          final last = s.lastFor(x['exercise_key']);
          var w = 0, k = 0;
          return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.exName(x['exercise_key']), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text('${rng(x['sets_min'], x['sets_max'])} ${s.t('sets')} • ${rng(x['reps_min'], x['reps_max'])} ${s.t('reps')}'
              '${x['rir_max'] != null ? ' • RIR ${rng(x['rir_min'], x['rir_max'])}' : ''}', style: const TextStyle(color: muted, fontSize: 12)),
            if (last != null) Text('${s.t('last')}: $last', style: const TextStyle(color: accent, fontSize: 12)),
            const SizedBox(height: 8),
            for (final r in rows[i]) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [
              SizedBox(width: 62, child: Text(r.warm ? '${s.t('warmup')} ${++w}' : '${s.t('set')} ${++k}',
                style: TextStyle(color: r.warm ? muted : Colors.white, fontSize: 13))),
              Expanded(child: TextField(controller: r.kg, enabled: !r.done, textAlign: TextAlign.center,
                keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(hintText: s.t('kg'), isDense: true))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: r.reps, enabled: !r.done, textAlign: TextAlign.center,
                keyboardType: TextInputType.number, decoration: InputDecoration(hintText: s.t('rep'), isDense: true))),
              IconButton(iconSize: 30, icon: Icon(r.done ? Icons.check_circle : Icons.circle_outlined, color: r.done ? accent : muted),
                onPressed: () {
                  setState(() => r.done = !r.done);
                  if (r.done) startRest(r.warm ? 45 : ((x['rest_min_sec'] ?? 90) as int));
                }),
            ])),
          ])));
        })),
      ]),
    );
  }
}
