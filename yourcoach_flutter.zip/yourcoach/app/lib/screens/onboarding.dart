import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// First-run personalisation. Also reused (edit: true) from Profile.
class OnboardingPage extends StatefulWidget {
  final Store s;
  final bool edit;
  const OnboardingPage(this.s, {super.key, this.edit = false});
  @override
  State<OnboardingPage> createState() => _OnboardingState();
}

class _OnboardingState extends State<OnboardingPage> {
  int step = 0;
  final name = TextEditingController(), age = TextEditingController(), cm = TextEditingController(), kg = TextEditingController();
  String sex = 'male', experience = 'beginner', activity = 'moderate', units = 'metric';
  int days = 4;
  bool consent = false;
  final interests = <String>{}, equipment = <String>{};

  static const interestKeys = ['i_bb', 'i_pl', 'i_st', 'i_gf', 'i_ca', 'i_hl'];
  static const equipKeys = ['e_machine', 'e_dumbbell', 'e_barbell', 'e_cable', 'e_bodyweight'];

  @override
  void initState() {
    super.initState();
    final p = widget.s.profile;
    name.text = p['name'] ?? '';
    if (p['age'] != null) age.text = '${p['age']}';
    if (p['cm'] != null) cm.text = '${p['cm']}';
    if (p['kg'] != null) kg.text = '${p['kg']}';
    sex = p['sex'] ?? sex; experience = p['experience'] ?? experience; activity = p['activity'] ?? activity;
    units = p['units'] ?? units; days = p['days'] ?? days; consent = widget.edit || p['consent'] == true;
    interests.addAll(List<String>.from(p['interests'] ?? []));
    equipment.addAll(List<String>.from(p['equipment'] ?? []));
  }

  bool get minor => (int.tryParse(age.text) ?? 99) < 18;

  bool get stepOk {
    if (step == 0) {
      final a = int.tryParse(age.text), h = double.tryParse(cm.text), w = double.tryParse(kg.text.replaceAll(',', '.'));
      return name.text.trim().isNotEmpty && a != null && a >= 10 && a <= 100 && h != null && h >= 100 && h <= 230 && w != null && w >= 25 && w <= 300;
    }
    return step == 2 ? consent : true;
  }

  Future<void> finish() async {
    final s = widget.s;
    await s.saveProfile({...s.profile, 'name': name.text.trim(), 'sex': sex, 'age': int.parse(age.text), 'cm': double.parse(cm.text),
      'kg': double.parse(kg.text.replaceAll(',', '.')), 'activity': activity, 'experience': experience, 'days': days,
      'interests': interests.toList(), 'equipment': equipment.toList(), 'units': units, 'consent': true, 'onboarded': true});
    if (widget.edit && mounted) Navigator.pop(context);
  }

  Widget _fld(String l, TextEditingController c, {bool num = true}) => Padding(padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextField(controller: c, onChanged: (_) => setState(() {}),
        keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text, decoration: InputDecoration(labelText: l)));

  Widget _chips(Store s, List<String> keys, Set<String> sel) => Wrap(spacing: 8, runSpacing: 4, children: [
        for (final k in keys) FilterChip(label: Text(s.t(k)), selected: sel.contains(k), onSelected: (v) => setState(() => v ? sel.add(k) : sel.remove(k)))]);

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final titles = [s.t('ob_basic'), s.t('ob_train'), s.t('ob_final')];
    final List<Widget> body = switch (step) {
      0 => [
          _fld(s.t('name_q'), name, num: false),
          SegmentedButton<String>(segments: [ButtonSegment(value: 'male', label: Text(s.t('male'))), ButtonSegment(value: 'female', label: Text(s.t('female')))],
            selected: {sex}, onSelectionChanged: (v) => setState(() => sex = v.first)),
          _fld(s.t('age'), age), _fld(s.t('height'), cm), _fld('${s.t('weight')} (${s.t('kg')})', kg),
          if (minor) Text(s.t('minor_note'), style: const TextStyle(color: accent, fontSize: 12)),
        ],
      1 => [
          Text(s.t('experience')),
          Wrap(spacing: 8, children: [for (final e in ['beginner', 'intermediate', 'advanced']) ChoiceChip(label: Text(s.t(e)), selected: experience == e, onSelected: (_) => setState(() => experience = e))]),
          const SizedBox(height: 16), Text(s.t('interests')), _chips(s, interestKeys, interests),
          const SizedBox(height: 16), Text(s.t('days_week')),
          Wrap(spacing: 8, children: [for (final d in [2, 3, 4, 5, 6]) ChoiceChip(label: Text('$d'), selected: days == d, onSelected: (_) => setState(() => days = d))]),
          const SizedBox(height: 16), Text(s.t('equipment_q')), _chips(s, equipKeys, equipment),
          const SizedBox(height: 16), Text(s.t('activity_q')),
          Wrap(spacing: 8, children: [for (final a in ['sedentary', 'light', 'moderate', 'high']) ChoiceChip(label: Text(s.t(a)), selected: activity == a, onSelected: (_) => setState(() => activity = a))]),
        ],
      _ => [
          Text(s.t('language')),
          SegmentedButton<String>(segments: const [ButtonSegment(value: 'ar', label: Text('العربية')), ButtonSegment(value: 'en', label: Text('English'))],
            selected: {s.lang}, onSelectionChanged: (v) => s.setLang(v.first)),
          const SizedBox(height: 16), Text(s.t('units')),
          Wrap(spacing: 8, children: [for (final u in ['metric', 'imperial']) ChoiceChip(label: Text(s.t(u)), selected: units == u, onSelected: (_) => setState(() => units = u))]),
          const SizedBox(height: 16),
          CheckboxListTile(contentPadding: EdgeInsets.zero, value: consent, onChanged: (v) => setState(() => consent = v ?? false), title: Text(s.t('consent'), style: const TextStyle(fontSize: 13))),
        ],
    };
    return Scaffold(
      appBar: AppBar(title: Text(widget.edit ? s.t('edit_profile') : s.t('welcome'), style: const TextStyle(fontSize: 18))),
      body: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        LinearProgressIndicator(value: (step + 1) / 3, color: accent, backgroundColor: surface2),
        const SizedBox(height: 12),
        Text(titles[step], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Expanded(child: ListView(children: body)),
        Row(children: [
          if (step > 0) Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            onPressed: () => setState(() => step--), child: Text(s.t('back')))),
          if (step > 0) const SizedBox(width: 8),
          Expanded(child: FilledButton(onPressed: stepOk ? (step < 2 ? () => setState(() => step++) : finish) : null,
            child: Text(step < 2 ? s.t('next') : s.t('start_app')))),
        ]),
      ]))),
    );
  }
}
