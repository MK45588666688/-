import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// User-defined habits (nothing preloaded), streaks, 7-day rate, and simple sleep log.
class HabitsPage extends StatelessWidget {
  final Store s;
  const HabitsPage(this.s, {super.key});

  Future<void> _addDialog(BuildContext context, [String initial = '']) async {
    final c = TextEditingController(text: initial);
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(s.t('new_habit')),
      content: TextField(controller: c, autofocus: true, decoration: InputDecoration(labelText: s.t('habit_name'))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('save'))),
      ]));
    if (ok == true && c.text.trim().isNotEmpty) await s.addHabit(c.text.trim());
  }

  Future<String?> _pick(BuildContext context) async {
    final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 23, minute: 0));
    return t == null ? null : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _logSleep(BuildContext context) async {
    final bed = await _pick(context); if (bed == null || !context.mounted) return;
    final wake = await _pick(context); if (wake == null) return;
    await s.addSleep(bed, wake);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final today = Store.dayKey();
        final used = s.habits.map((h) => h['name']).toSet();
        final sugg = ['h_water', 'h_steps', 'h_sleep', 'h_stretch'].where((k) => !used.contains(s.t(k))).toList();
        final lastSleep = s.sleeps.isEmpty ? null : s.sleeps.last;
        return Scaffold(
          appBar: AppBar(title: Text(s.t('habits'))),
          floatingActionButton: FloatingActionButton.extended(backgroundColor: accent, foregroundColor: Colors.black,
            onPressed: () => _addDialog(context), icon: const Icon(Icons.add), label: Text(s.t('new_habit'))),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            if (s.habits.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.t('week_rate'), style: const TextStyle(color: muted)),
              const SizedBox(height: 6),
              Text('${(s.habitWeekRate() * 100).round()}%', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              LinearProgressIndicator(value: s.habitWeekRate(), color: accent, backgroundColor: surface2),
            ]))),
            if (s.habits.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(s.t('no_habits'), style: const TextStyle(color: muted))),
            for (final h in s.habits) Card(child: CheckboxListTile(
              value: s.habitDone(h['id'], today), activeColor: accent,
              onChanged: (_) => s.toggleHabit(h['id']),
              title: Text(h['name']),
              subtitle: Text('${s.streak(h['id'])} ${s.t('streak')}', style: const TextStyle(color: muted)),
              secondary: IconButton(icon: const Icon(Icons.delete_outline, size: 20), onPressed: () => showDialog(context: context, builder: (d) => AlertDialog(
                title: Text(s.t('delete')),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(d), child: Text(s.t('cancel'))),
                  TextButton(onPressed: () { s.removeHabit(h['id']); Navigator.pop(d); }, child: Text(s.t('confirm'))),
                ]))),
            )),
            if (sugg.isNotEmpty) ...[
              Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(s.t('suggest'), style: const TextStyle(color: muted))),
              Wrap(spacing: 8, runSpacing: 4, children: [for (final k in sugg) ActionChip(label: Text(s.t(k)), onPressed: () => s.addHabit(s.t(k)))]),
            ],
            Padding(padding: const EdgeInsets.only(top: 16, bottom: 4), child: Text(s.t('sleep'), style: const TextStyle(color: muted))),
            Card(child: ListTile(
              title: Text(lastSleep == null ? s.t('log_sleep') : '${(lastSleep['mins'] as int) ~/ 60}h ${(lastSleep['mins'] as int) % 60}m'),
              subtitle: lastSleep == null ? null : Text('${lastSleep['bed']} → ${lastSleep['wake']} • ${lastSleep['day']}'),
              trailing: const Icon(Icons.bedtime_outlined),
              onTap: () => _logSleep(context))),
            const SizedBox(height: 80),
          ]),
        );
      });
}
