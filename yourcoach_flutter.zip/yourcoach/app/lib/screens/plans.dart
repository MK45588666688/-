import 'package:flutter/material.dart';
import '../calc.dart';
import '../store.dart';
import '../theme.dart';

class PlansPage extends StatelessWidget {
  final Store s;
  const PlansPage(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) => Scaffold(
        appBar: AppBar(title: Text(s.t('plans'))),
        floatingActionButton: FloatingActionButton.extended(backgroundColor: accent, foregroundColor: Colors.black,
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CalcPage(s))),
          icon: const Icon(Icons.calculate), label: Text(s.t('calc'))),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          if (s.plans.isEmpty) Text(s.t('no_data'), style: const TextStyle(color: muted)),
          for (final p in s.plans) Card(child: ListTile(
            leading: Icon(p['id'] == s.activePlanId ? Icons.radio_button_checked : Icons.radio_button_off, color: accent),
            title: Text(p['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('${p['kcal']} kcal • P${p['p']} C${p['c']} F${p['f']}'),
            onTap: () => s.activatePlan(p['id']),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => s.deletePlan(p['id'])),
          )),
        ]),
      ));
}

class CalcPage extends StatefulWidget {
  final Store s;
  const CalcPage(this.s, {super.key});
  @override
  State<CalcPage> createState() => _CalcState();
}

class _CalcState extends State<CalcPage> {
  late String sex, activity;
  String goal = 'g_maintain';
  final age = TextEditingController(), cm = TextEditingController(), kg = TextEditingController(), name = TextEditingController();
  final kcal = TextEditingController(), pr = TextEditingController(), ca = TextEditingController(), fa = TextEditingController();
  double delta = 400, protPerKg = 1.8, fatPct = 25;
  double? bmrV, tdeeV;

  @override
  void initState() {
    super.initState();
    final p = widget.s.profile;
    sex = p['sex'] ?? 'male';
    activity = p['activity'] ?? 'moderate';
    if (p['age'] != null) age.text = '${p['age']}';
    if (p['cm'] != null) cm.text = '${p['cm']}';
    if (p['kg'] != null) kg.text = '${p['kg']}';
  }

  bool get minor => (int.tryParse(age.text) ?? 99) < 18;

  void compute() {
    final a = int.tryParse(age.text), h = double.tryParse(cm.text), w = double.tryParse(kg.text.replaceAll(',', '.'));
    if (a == null || h == null || w == null || a < 10 || a > 100 || h < 100 || h > 230 || w < 25 || w > 300) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تحقق من السن والطول والوزن')));
      return;
    }
    final b = bmr(sex: sex, kg: w, cm: h, age: a);
    final t = b * activityFactors[activity]!;
    var d = 0;
    if (!minor) { if (goal == 'g_lose') d = -delta.round(); if (goal == 'g_gain') d = delta.round(); }
    final tg = buildTarget(tdee: t, deltaKcal: d, kg: w, proteinPerKg: protPerKg, fatPct: fatPct, sex: sex);
    setState(() { bmrV = b; tdeeV = t; kcal.text = '${tg.kcal}'; pr.text = '${tg.p}'; ca.text = '${tg.c}'; fa.text = '${tg.f}'; });
    widget.s.saveProfile({...widget.s.profile, 'sex': sex, 'age': a, 'cm': h, 'kg': w, 'activity': activity});
  }

  Future<void> save() async {
    final k = int.tryParse(kcal.text), p = int.tryParse(pr.text), c = int.tryParse(ca.text), f = int.tryParse(fa.text);
    if (k == null || p == null || c == null || f == null || k < 800) return;
    final s = widget.s;
    await s.savePlan({'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'name': name.text.trim().isEmpty ? s.t(minor ? 'g_general' : goal) : name.text.trim(),
      'goal': goal, 'kcal': k, 'p': p, 'c': c, 'f': f,
      'assumptions': {'bmr': bmrV?.round(), 'tdee': tdeeV?.round(), 'delta': k - (tdeeV ?? k).round(), 'activity': activity}});
    if (mounted) Navigator.pop(context);
  }

  Widget num(String l, TextEditingController t) => Expanded(child: Padding(padding: const EdgeInsets.all(4),
      child: TextField(controller: t, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: InputDecoration(labelText: l))));

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final goals = minor ? ['g_maintain', 'g_general'] : ['g_maintain', 'g_lose', 'g_gain', 'g_general'];
    if (!goals.contains(goal)) goal = goals.first;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('calc'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SegmentedButton<String>(segments: [ButtonSegment(value: 'male', label: Text(s.t('male'))), ButtonSegment(value: 'female', label: Text(s.t('female')))],
          selected: {sex}, onSelectionChanged: (v) => setState(() => sex = v.first)),
        Row(children: [num(s.t('age'), age), num(s.t('height'), cm), num('${s.t('weight')} (${s.t('kg')})', kg)]),
        DropdownButtonFormField<String>(value: activity, items: [for (final a in activityFactors.keys) DropdownMenuItem(value: a, child: Text(s.t(a)))],
          onChanged: (v) => setState(() => activity = v ?? activity)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, children: [for (final g in goals) ChoiceChip(label: Text(s.t(g)), selected: goal == g, onSelected: (_) => setState(() => goal = g))]),
        if (minor) Padding(padding: const EdgeInsets.only(top: 8), child: Text(s.t('minor_note'), style: const TextStyle(color: accent, fontSize: 12))),
        if (!minor && (goal == 'g_lose' || goal == 'g_gain')) ...[
          Text('${s.t('adj')}: ${delta.round()}'),
          Slider(value: delta, min: goal == 'g_lose' ? 200 : 100, max: goal == 'g_lose' ? 700 : 500, divisions: 50, activeColor: accent, onChanged: (v) => setState(() => delta = v)),
        ],
        Text('${s.t('prot_kg')}: ${protPerKg.toStringAsFixed(1)}'),
        Slider(value: protPerKg, min: 1.2, max: 2.4, divisions: 12, activeColor: accent, onChanged: (v) => setState(() => protPerKg = v)),
        Text('${s.t('fat_pct')}: ${fatPct.round()}%'),
        Slider(value: fatPct, min: 20, max: 35, divisions: 15, activeColor: accent, onChanged: (v) => setState(() => fatPct = v)),
        FilledButton(onPressed: compute, child: Text(s.t('compute'))),
        if (bmrV != null) ...[
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${s.t('bmr')}: ${bmrV!.round()} kcal'), Text('${s.t('tdee')}: ${tdeeV!.round()} kcal'),
            const SizedBox(height: 6), Text(s.t('assump'), style: const TextStyle(color: muted, fontSize: 11)),
          ]))),
          Row(children: [num(s.t('calories'), kcal), num(s.t('protein'), pr)]),
          Row(children: [num(s.t('carbs'), ca), num(s.t('fat'), fa)]),
          TextField(controller: name, decoration: InputDecoration(labelText: s.t('plan_name'))),
          const SizedBox(height: 12),
          FilledButton(onPressed: save, child: Text(s.t('save_plan'))),
        ],
        const SizedBox(height: 30),
      ]),
    );
  }
}
