import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'cardio.dart';
import 'habits.dart';
import 'calendar.dart';

class ProgressPage extends StatefulWidget {
  final Store s;
  const ProgressPage(this.s, {super.key});
  @override
  State<ProgressPage> createState() => _ProgressState();
}

class _ProgressState extends State<ProgressPage> {
  final c = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(listenable: s, builder: (_, __) {
      final w = s.weights;
      return ListView(padding: const EdgeInsets.all(16), children: [
        Text(s.t('progress'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Row(children: [
          for (final e in [
            (Icons.directions_run, 'cardio', (Store x) => CardioPage(x)),
            (Icons.checklist, 'habits', (Store x) => HabitsPage(x)),
            (Icons.calendar_month, 'calendar', (Store x) => CalendarPage(x)),
          ]) Expanded(child: Card(child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => e.$3(s))),
            child: Padding(padding: const EdgeInsets.symmetric(vertical: 14), child: Column(children: [
              Icon(e.$1, color: accent), const SizedBox(height: 4), Text(s.t(e.$2), style: const TextStyle(fontSize: 12)),
            ]))))),
        ]),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.t('weight'), style: const TextStyle(color: muted)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(suffixText: s.t('kg')))),
            const SizedBox(width: 8),
            FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(80, 52)), onPressed: () {
              final v = double.tryParse(c.text.replaceAll(',', '.'));
              if (v != null && v > 20 && v < 400) { s.addWeight(v); c.clear(); }
            }, child: Text(s.t('save'))),
          ]),
          if (w.length > 1) SizedBox(height: 120, child: CustomPaint(size: Size.infinite, painter: _Line(w.map((e) => (e['kg'] as num).toDouble()).toList()))),
        ]))),
        ...prSection(s),
        Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(s.t('history'), style: const TextStyle(color: muted))),
        if (s.sessions.isEmpty && w.isEmpty) Text(s.t('no_data'), style: const TextStyle(color: muted)),
        for (final x in s.sessions.reversed.take(20)) Card(child: ListTile(
          title: Text(x['day']), subtitle: Text((x['at'] as String).substring(0, 10)),
          trailing: Text('${(x['sets'] as List).where((e) => e['warm'] != true).length} ${s.t('sets')} • ${x['mins']}m'))),
      ]);
    });
  }
}

class _Line extends CustomPainter {
  final List<double> v;
  _Line(this.v);
  @override
  void paint(Canvas canvas, Size size) {
    final lo = v.reduce((a, b) => a < b ? a : b), hi = v.reduce((a, b) => a > b ? a : b);
    final span = (hi - lo).abs() < .01 ? 1.0 : hi - lo;
    final p = Path();
    for (var i = 0; i < v.length; i++) {
      final x = size.width * i / (v.length - 1), y = size.height - (v[i] - lo) / span * (size.height - 16) - 8;
      i == 0 ? p.moveTo(x, y) : p.lineTo(x, y);
    }
    canvas.drawPath(p, Paint()..color = accent..style = PaintingStyle.stroke..strokeWidth = 2.5);
  }
  @override
  bool shouldRepaint(_Line o) => o.v != v;
}

List<Widget> prSection(Store s) {
  final prs = s.prs();
  if (prs.isEmpty) return [];
  final list = prs.entries.toList()..sort((a, b) => (b.value['at'] as String).compareTo(a.value['at'] as String));
  final vol = s.weekMuscleSets();
  return [
    Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(s.t('weekly_vol'), style: const TextStyle(color: muted))),
    Wrap(spacing: 8, runSpacing: 4, children: [for (final e in vol.entries) Chip(label: Text('${s.muscleName(e.key)} ${e.value}'))]),
    Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(s.t('records'), style: const TextStyle(color: muted))),
    for (final e in list.take(6)) Card(child: ListTile(
      title: Text(s.exName(e.key)), subtitle: Text((e.value['at'] as String).substring(0, 10)),
      trailing: Text('${e.value['kg']} × ${e.value['reps']}', style: const TextStyle(fontWeight: FontWeight.w700)))),
  ];
}
