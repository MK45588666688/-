import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// Unified calendar of what was LOGGED (workouts, cardio, food, habits, custom events).
/// Month / week grids + day detail. Future workout scheduling by date is not implemented (see cal_note).
class CalendarPage extends StatefulWidget {
  final Store s;
  const CalendarPage(this.s, {super.key});
  @override
  State<CalendarPage> createState() => _CalendarState();
}

class _CalendarState extends State<CalendarPage> {
  DateTime sel = DateTime.now();
  bool weekMode = false;

  DateTime _d(DateTime x) => DateTime(x.year, x.month, x.day);
  void _shift(int dir) => setState(() {
        sel = weekMode ? sel.add(Duration(days: 7 * dir)) : DateTime(sel.year, sel.month + dir, 1);
      });

  List<DateTime> _cells() {
    if (weekMode) {
      final start = _d(sel).subtract(Duration(days: (sel.weekday + 1) % 7)); // week starts Saturday
      return [for (var i = 0; i < 7; i++) start.add(Duration(days: i))];
    }
    final first = DateTime(sel.year, sel.month, 1);
    final lead = (first.weekday + 1) % 7; // Saturday-first grid
    final n = DateUtils.getDaysInMonth(sel.year, sel.month);
    return [for (var i = 0; i < lead; i++) DateTime(0), for (var i = 1; i <= n; i++) DateTime(sel.year, sel.month, i)];
  }

  Future<void> _addEvent(BuildContext context) async {
    final s = widget.s;
    final c = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(s.t('add_event')),
      content: TextField(controller: c, autofocus: true, decoration: InputDecoration(labelText: s.t('event_title'))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('save'))),
      ]));
    if (ok == true && c.text.trim().isNotEmpty) await s.addEvent(Store.dayKey(sel), c.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(listenable: s, builder: (_, __) {
      final cells = _cells();
      final selKey = Store.dayKey(sel);
      final a = s.activityOn(selKey);
      final dayEvents = s.events.where((e) => e['day'] == selKey).toList();
      final names = s.lang == 'ar'
          ? ['سبت', 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'] : ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
      return Scaffold(
        appBar: AppBar(title: Text(s.t('calendar'))),
        floatingActionButton: FloatingActionButton(backgroundColor: accent, foregroundColor: Colors.black, onPressed: () => _addEvent(context), child: const Icon(Icons.add)),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          SegmentedButton<bool>(
            segments: [ButtonSegment(value: false, label: Text(s.t('month'))), ButtonSegment(value: true, label: Text(s.t('week')))],
            selected: {weekMode}, onSelectionChanged: (v) => setState(() => weekMode = v.first)),
          Row(children: [
            IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _shift(-1)),
            Expanded(child: Text(weekMode ? '${Store.dayKey(cells.first)}  →  ${Store.dayKey(cells.last)}' : '${sel.year}-${sel.month.toString().padLeft(2, '0')}',
              textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700))),
            IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _shift(1)),
          ]),
          Row(children: [for (final n in names) Expanded(child: Center(child: Text(n, style: const TextStyle(color: muted, fontSize: 11))))]),
          const SizedBox(height: 4),
          GridView.count(crossAxisCount: 7, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: 1, children: [
            for (final d in cells) d.year == 0 ? const SizedBox() : _cell(s, d, Store.dayKey(d) == selKey),
          ]),
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(selKey, style: const TextStyle(color: muted)),
            const SizedBox(height: 8),
            if (a.values.every((v) => v == 0)) Text(s.t('no_data'), style: const TextStyle(color: muted)),
            if (a['workout']! > 0) _row(Icons.fitness_center, '${s.t('workout_done')}: ${a['workout']}'),
            if (a['cardio']! > 0) _row(Icons.directions_run, '${s.t('cardio')}: ${s.cardioMinsOn(selKey).round()} ${s.t('min')}'),
            if (a['food']! > 0) _row(Icons.restaurant, '${s.t('food_logged')}: ${s.totals(selKey)['k']!.round()} kcal'),
            if (a['habits']! > 0) _row(Icons.check_circle_outline, '${s.t('habits_done')}: ${a['habits']}/${s.habits.length}'),
            for (final e in dayEvents) Row(children: [
              Expanded(child: _row(Icons.event, e['title'])),
              IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => s.removeEvent(e['id'])),
            ]),
          ]))),
          Text(s.t('cal_note'), style: const TextStyle(color: muted, fontSize: 11)),
        ]),
      );
    });
  }

  Widget _row(IconData i, String t) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [
        Icon(i, size: 18, color: accent), const SizedBox(width: 8), Expanded(child: Text(t))]));

  Widget _cell(Store s, DateTime d, bool selected) {
    final a = s.activityOn(Store.dayKey(d));
    final dots = <Color>[
      if (a['workout']! > 0) accent, if (a['cardio']! > 0) Colors.lightBlueAccent,
      if (a['food']! > 0) Colors.greenAccent, if (a['habits']! > 0) Colors.amberAccent, if (a['events']! > 0) Colors.white,
    ];
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => setState(() => sel = d),
      child: Container(
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(color: selected ? accent.withOpacity(.2) : surface, borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? accent : line)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('${d.day}', style: TextStyle(fontWeight: selected ? FontWeight.w800 : FontWeight.w500)),
          const SizedBox(height: 3),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (final c in dots) Container(width: 5, height: 5, margin: const EdgeInsets.symmetric(horizontal: 1), decoration: BoxDecoration(color: c, shape: BoxShape.circle))]),
        ]),
      ),
    );
  }
}
