import 'package:flutter/material.dart';
import '../cloud.dart';
import '../store.dart';
import '../theme.dart';

class AccountPage extends StatefulWidget {
  final Store s;
  const AccountPage(this.s, {super.key});
  @override
  State<AccountPage> createState() => _AccountState();
}

class _AccountState extends State<AccountPage> {
  final email = TextEditingController(), pass = TextEditingController();
  bool busy = false;

  Future<void> run(Future<void> Function() f, {bool refresh = true}) async {
    setState(() => busy = true);
    String msg;
    try { await f(); msg = widget.s.t('done'); } catch (e) { msg = '${widget.s.t('failed')}: $e'; }
    if (!mounted) return;
    setState(() => busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final u = Cloud.user;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('account'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (!Cloud.enabled) Text(s.t('cloud_off'), style: const TextStyle(color: muted))
        else if (u == null) ...[
          TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText: s.t('email'))),
          const SizedBox(height: 8),
          TextField(controller: pass, obscureText: true, decoration: InputDecoration(labelText: s.t('password'))),
          const SizedBox(height: 12),
          FilledButton(onPressed: busy ? null : () => run(() async { await Cloud.signIn(email.text.trim(), pass.text); setState(() {}); }), child: Text(s.t('signin'))),
          const SizedBox(height: 8),
          OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            onPressed: busy ? null : () => run(() async { await Cloud.signUp(email.text.trim(), pass.text); setState(() {}); }), child: Text(s.t('signup'))),
        ] else ...[
          Card(child: ListTile(leading: const Icon(Icons.person), title: Text(u.email ?? ''))),
          SwitchListTile(title: Text(s.t('autosync')), value: s.profile['autosync'] == true, activeColor: accent,
            onChanged: (v) => s.saveProfile({...s.profile, 'autosync': v})),
          FilledButton(onPressed: busy ? null : () => run(() => Cloud.push(s.toJson())), child: Text(s.t('backup_now'))),
          const SizedBox(height: 8),
          OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)), onPressed: busy ? null : () async {
            final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: Text(s.t('restore')),
              content: const Text('سيتم استبدال بيانات هذا الجهاز بنسخة السحابة.\nThis replaces data on this device.'),
              actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('confirm')))]));
            if (ok == true) await run(() async { final d = await Cloud.pull(); if (d == null) throw 'no backup'; await s.restoreFrom(d); });
          }, child: Text(s.t('restore'))),
          const SizedBox(height: 8),
          TextButton(onPressed: () async { await Cloud.signOut(); if (mounted) setState(() {}); }, child: Text(s.t('signout'))),
        ],
      ]),
    );
  }
}
