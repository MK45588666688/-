import 'dart:convert';
import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'library.dart';
import 'training.dart' show rng;

/// Custom workout builder: days, rest days, exercises, sets/reps/RIR/rest, order, duplicate.
class BuilderPage extends StatefulWidget {
  final Store s;
  final Map<String, dynamic>? edit;
  const BuilderPage(this.s, {super.key, this.edit});
  @override
  State<BuilderPage> createState() => _BuilderState();
}

class _BuilderState extends State<BuilderPage> {
  final name = TextEditingController();
  late List<Map<String, dynamic>> days; // {id,name,rest,exercises}
  int _id = 0;

  Map<String, dynamic> _day(String n, {bool rest = false, List? ex}) =>
      {'id': _id++, 'name': n, 'rest': rest, 'exercises': ex ?? []};

  @override
  void initState() {
    super.initState();
    final p = widget.edit;
    if (p == null) {
      days = [_day('Day 1')];
    } else {
      name.text = widget.s.progTitle(p);
      final byName = {for (final d in (p['days'] as List)) d['name'] as String: d};
      days = [for (final n in (p['cycle'] as List).cast<String>())
        n == 'REST' ? _day('REST', rest: true) : _day(n, ex: jsonDecode(jsonEncode(byName[n]['exercises'])) as List)];
    }
  }

  Future<void> pick(Map<String, dynamic> d) async {
    final s = widget.s;
    final key = await showModalBottomSheet<String>(context: context, isScrollControlled: true, backgroundColor: surface,
      builder: (c) => SizedBox(height: MediaQuery.of(c).size.height * .8, child: ExerciseList(s, onTap: (k) => Navigator.pop(c, k))));
    if (key == null) return;
    final x = {'exercise_key': key, 'sets_min': 3, 'sets_max': 3, 'reps_min': 8, 'reps_max': 12, 'warmup_sets': 0,
      'rir_min': null, 'rir_max': null, 'rest_min_sec': 120, 'rest_max_sec': 120};
    setState(() => (d['exercises'] as List).add(x));
    await editEx(x);
  }

  Future<void> editEx(Map x) async {
    final s = widget.s;
    TextEditingController c(dynamic v) => TextEditingController(text: v == null ? '' : '$v');
    final sets = c(x['sets_max']), rmin = c(x['reps_min']), rmax = c(x['reps_max']), wu = c(x['warmup_sets']),
        rir = c(x['rir_max']), rest = c(x['rest_max_sec']);
    Widget f(String l, TextEditingController t) => Padding(padding: const EdgeInsets.only(bottom: 8),
      child: TextField(controller: t, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: l)));
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(s.exName(x['exercise_key'])),
      content: SingleChildScrollView(child: Column(children: [
        f(s.t('sets'), sets), f('${s.t('reps')} min', rmin), f('${s.t('reps')} max', rmax),
        f(s.t('warmup'), wu), f('RIR', rir), f(s.t('rest_s'), rest)])),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('save')))]));
    if (ok != true) return;
    int? i(TextEditingController t) => int.tryParse(t.text);
    final n = (i(sets) ?? 3).clamp(1, 20);
    final lo = (i(rmin) ?? 8).clamp(1, 100), hi = (i(rmax) ?? lo).clamp(lo, 100);
    setState(() {
      x['sets_min'] = n; x['sets_max'] = n; x['reps_min'] = lo; x['reps_max'] = hi;
      x['warmup_sets'] = (i(wu) ?? 0).clamp(0, 10);
      x['rir_min'] = i(rir) == null ? null : 0; x['rir_max'] = i(rir);
      x['rest_min_sec'] = i(rest); x['rest_max_sec'] = i(rest);
    });
  }

  Future<void> save() async {
    final s = widget.s;
    final real = days.where((d) => d['rest'] != true).toList();
    final names = real.map((d) => (d['name'] as String).trim()).toList();
    if (name.text.trim().isEmpty || real.isEmpty || names.any((n) => n.isEmpty || n == 'REST') || names.toSet().length != names.length) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(names.toSet().length != names.length ? s.t('name_taken') : s.t('prog_name'))));
      return;
    }
    final title = name.text.trim();
    final p = {
      'slug': widget.edit?['slug'] ?? 'custom-${DateTime.now().millisecondsSinceEpoch}',
      'title_ar': title, 'title_en': title, 'level': 'custom', 'goal': 'custom', 'split_type': 'custom',
      'days_per_week': real.length, 'status': 'user', 'source': 'user',
      'cycle': [for (final d in days) d['rest'] == true ? 'REST' : (d['name'] as String).trim()],
      'days': [for (final d in real) {'name': (d['name'] as String).trim(), 'focus': 'custom', 'exercises': d['exercises']}],
    };
    await s.saveCustom(p);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('new_program')), actions: [TextButton(onPressed: save, child: Text(s.t('save')))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: name, decoration: InputDecoration(labelText: s.t('prog_name'))),
        const SizedBox(height: 8),
        for (var di = 0; di < days.length; di++) _dayCard(di),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.add), label: Text(s.t('add_day')),
            onPressed: () => setState(() => days.add(_day('Day ${days.where((d) => d['rest'] != true).length + 1}'))))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.hotel), label: Text(s.t('add_rest')),
            onPressed: () => setState(() => days.add(_day('REST', rest: true))))),
        ]),
        const SizedBox(height: 40),
      ]),
    );
  }

  Widget _dayCard(int di) {
    final s = widget.s;
    final d = days[di];
    final ex = d['exercises'] as List;
    final isRest = d['rest'] == true;
    return Card(key: ValueKey(d['id']), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: isRest ? Text(s.t('rest_day'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))
          : TextFormField(initialValue: d['name'], onChanged: (v) => d['name'] = v, style: const TextStyle(fontWeight: FontWeight.w800))),
        IconButton(icon: const Icon(Icons.arrow_upward, size: 18), onPressed: di == 0 ? null : () => setState(() { final t = days.removeAt(di); days.insert(di - 1, t); })),
        IconButton(icon: const Icon(Icons.arrow_downward, size: 18), onPressed: di == days.length - 1 ? null : () => setState(() { final t = days.removeAt(di); days.insert(di + 1, t); })),
        if (!isRest) IconButton(tooltip: s.t('dup'), icon: const Icon(Icons.copy, size: 18), onPressed: () => setState(() =>
          days.insert(di + 1, _day('${d['name']} 2', ex: jsonDecode(jsonEncode(ex)) as List)))),
        IconButton(tooltip: s.t('delete'), icon: const Icon(Icons.delete_outline, size: 20, color: Colors.redAccent), onPressed: () => setState(() => days.removeAt(di))),
      ]),
      if (!isRest) ...[
        for (var i = 0; i < ex.length; i++) ListTile(dense: true, contentPadding: EdgeInsets.zero,
          title: Text(s.exName(ex[i]['exercise_key'])),
          subtitle: Text('${rng(ex[i]['sets_min'], ex[i]['sets_max'])}×${rng(ex[i]['reps_min'], ex[i]['reps_max'])}'
            '${ex[i]['rir_max'] != null ? ' • RIR ${ex[i]['rir_max']}' : ''}${ex[i]['rest_max_sec'] != null ? ' • ${ex[i]['rest_max_sec']}s' : ''}', style: const TextStyle(color: muted)),
          onTap: () => editEx(ex[i]),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(icon: const Icon(Icons.keyboard_arrow_up), onPressed: i == 0 ? null : () => setState(() { final t = ex.removeAt(i); ex.insert(i - 1, t); })),
            IconButton(icon: const Icon(Icons.keyboard_arrow_down), onPressed: i == ex.length - 1 ? null : () => setState(() { final t = ex.removeAt(i); ex.insert(i + 1, t); })),
            IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => ex.removeAt(i))),
          ])),
        TextButton.icon(onPressed: () => pick(d), icon: const Icon(Icons.add, color: accent), label: Text(s.t('add_ex'))),
      ],
    ])));
  }
}
