import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// Education center: shows ONLY articles published by the owner from the admin dashboard (nothing invented in-app).
class ArticlesPage extends StatelessWidget {
  final Store s;
  const ArticlesPage(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final ar = s.lang == 'ar';
        final list = s.articles;
        return Scaffold(
          appBar: AppBar(title: Text(s.t('articles')), actions: [
            IconButton(tooltip: s.t('sync_content'), icon: const Icon(Icons.refresh), onPressed: () async {
              final ok = await s.syncContent();
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t(ok ? 'done' : 'failed'))));
            }),
          ]),
          body: list.isEmpty
              ? Center(child: Text(s.t('no_data'), style: const TextStyle(color: muted)))
              : ListView(padding: const EdgeInsets.all(16), children: [
                  for (final a in list) Card(child: ListTile(
                    title: Text('${(ar ? a['title_ar'] : a['title_en']) ?? a['title_ar'] ?? a['title_en']}'), subtitle: Text('${a['category'] ?? ''}'),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
                      appBar: AppBar(title: Text('${(ar ? a['title_ar'] : a['title_en']) ?? a['title_ar']}')),
                      body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: SelectableText('${(ar ? a['body_ar'] : a['body_en']) ?? a['body_ar'] ?? a['body_en'] ?? ''}', style: const TextStyle(height: 1.6)))))))),
                ]),
        );
      });
}
