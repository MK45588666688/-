import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'nutrition.dart' show mealTypes;

class RecipesPage extends StatelessWidget {
  final Store s;
  const RecipesPage(this.s, {super.key});

  Future<void> logIt(BuildContext c, Map<String, dynamic> r) async {
    final n = TextEditingController(text: '1');
    var type = 'lunch';
    final ok = await showDialog<bool>(context: c, builder: (d) => StatefulBuilder(builder: (_, set) => AlertDialog(
      title: Text(r['name']),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: s.t('servings'))),
        const SizedBox(height: 10),
        Wrap(spacing: 6, children: [for (final t in mealTypes) ChoiceChip(label: Text(s.t(t)), selected: type == t, onSelected: (_) => set(() => type = t))]),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('add')))])));
    final x = double.tryParse(n.text.replaceAll(',', '.'));
    if (ok != true || x == null || x <= 0) return;
    final t = Store.recipeTotals(r); final sv = (r['servings'] as num).toDouble();
    final m = x / sv;
    await s.addRaw(r['name'], t['k']! * m, t['p']! * m, t['c']! * m, t['f']! * m, t['g']! * m, type);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) => Scaffold(
        appBar: AppBar(title: Text(s.t('recipes'))),
        floatingActionButton: FloatingActionButton(backgroundColor: accent, foregroundColor: Colors.black,
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RecipeEditor(s))), child: const Icon(Icons.add)),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          if (s.recipes.isEmpty) Text(s.t('no_data'), style: const TextStyle(color: muted)),
          for (final r in s.recipes) Builder(builder: (_) {
            final t = Store.recipeTotals(r); final sv = (r['servings'] as num).toDouble();
            return Card(child: ListTile(
              title: Text(r['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${s.t('per_serving')}: ${(t['k']! / sv).round()} kcal • P${(t['p']! / sv).round()} C${(t['c']! / sv).round()} F${(t['f']! / sv).round()}'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RecipeEditor(s, edit: r))),
              trailing: IconButton(icon: const Icon(Icons.add_circle, color: accent), onPressed: () => logIt(context, r)),
            ));
          }),
        ]),
      ));
}

class RecipeEditor extends StatefulWidget {
  final Store s;
  final Map<String, dynamic>? edit;
  const RecipeEditor(this.s, {super.key, this.edit});
  @override
  State<RecipeEditor> createState() => _RecipeEditorState();
}

class _RecipeEditorState extends State<RecipeEditor> {
  final name = TextEditingController(), servings = TextEditingController(text: '1');
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    final r = widget.edit;
    if (r != null) {
      name.text = r['name']; servings.text = '${r['servings']}';
      items = (r['items'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
    }
  }

  String norm(String x) => x.toLowerCase().replaceAll(RegExp('[أإآ]'), 'ا').replaceAll('ة', 'ه').replaceAll('ى', 'ي');

  Future<void> addItem() async {
    final s = widget.s;
    var q = '';
    final food = await showModalBottomSheet<Map<String, dynamic>>(context: context, isScrollControlled: true, backgroundColor: surface,
      builder: (c) => StatefulBuilder(builder: (_, set) {
        final res = s.allFoods.where((f) => norm('${f['ar']} ${f['en']}').contains(norm(q))).toList();
        return SizedBox(height: MediaQuery.of(c).size.height * .75, child: Column(children: [
          Padding(padding: const EdgeInsets.all(12), child: TextField(autofocus: true, onChanged: (v) => set(() => q = v),
            decoration: InputDecoration(hintText: s.t('search_food'), prefixIcon: const Icon(Icons.search)))),
          Expanded(child: ListView(children: [for (final f in res) ListTile(title: Text(s.foodName(f)), subtitle: Text('${f['k']} kcal / 100g'), onTap: () => Navigator.pop(c, f))])),
        ]));
      }));
    if (food == null || !mounted) return;
    final g = TextEditingController(text: '${food['srv'] ?? 100}');
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(s.foodName(food)),
      content: TextField(controller: g, keyboardType: TextInputType.number, decoration: InputDecoration(suffixText: s.t('grams'))),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('add')))]));
    final gv = double.tryParse(g.text);
    if (ok == true && gv != null && gv > 0) setState(() => items.add({'food': food, 'g': gv}));
  }

  Future<void> save() async {
    final sv = double.tryParse(servings.text.replaceAll(',', '.')) ?? 0;
    if (name.text.trim().isEmpty || items.isEmpty || sv <= 0) return;
    await widget.s.saveRecipe({'id': widget.edit?['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      'name': name.text.trim(), 'servings': sv, 'items': items});
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final r = {'items': items};
    final t = Store.recipeTotals(r);
    final sv = (double.tryParse(servings.text.replaceAll(',', '.')) ?? 1).clamp(0.25, 100).toDouble();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('recipes')), actions: [
        if (widget.edit != null) IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await s.deleteRecipe(widget.edit!['id']); if (mounted) Navigator.pop(context); }),
        TextButton(onPressed: save, child: Text(s.t('save')))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: name, decoration: InputDecoration(labelText: s.t('name'))),
        const SizedBox(height: 8),
        TextField(controller: servings, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: InputDecoration(labelText: s.t('servings'))),
        for (var i = 0; i < items.length; i++) ListTile(
          title: Text(s.foodName(items[i]['food'])), subtitle: Text('${(items[i]['g'] as num).round()} g'),
          trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => items.removeAt(i)))),
        TextButton.icon(onPressed: addItem, icon: const Icon(Icons.add, color: accent), label: Text(s.t('ingredient'))),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${s.t('total')}: ${t['k']!.round()} kcal • P${t['p']!.round()} C${t['c']!.round()} F${t['f']!.round()}'),
          const SizedBox(height: 4),
          Text('${s.t('per_serving')}: ${(t['k']! / sv).round()} kcal • P${(t['p']! / sv).round()} C${(t['c']! / sv).round()} F${(t['f']! / sv).round()}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        ]))),
      ]),
    );
  }
}
