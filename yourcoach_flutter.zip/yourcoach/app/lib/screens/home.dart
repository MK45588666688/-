import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'tracker.dart';
import 'ai.dart';

class HomePage extends StatelessWidget {
  final Store s;
  final void Function(int) goTo;
  const HomePage(this.s, {super.key, required this.goTo});
  bool hid(String k) => (s.profile['hidden'] as List?)?.contains(k) ?? false;

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final day = s.todayDay;
        final tot = s.totals(Store.dayKey());
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text(s.profile['name'] != null ? '${s.t('home')} • ${s.profile['name']}' : 'YOUR COACH', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 1)),
          const SizedBox(height: 4),
          Card(child: ListTile(leading: const Icon(Icons.auto_awesome, color: accent), title: Text(s.t('ai')),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AiPage(s))))),
          if (!hid('workout')) Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.t('today_workout'), style: const TextStyle(color: muted)),
            const SizedBox(height: 6),
            if (s.activeProgram == null) ...[
              Text(s.t('no_program')),
              const SizedBox(height: 12),
              FilledButton(onPressed: () => goTo(1), child: Text(s.t('programs'))),
            ] else if (day == null) ...[
              Text(s.t('rest_day'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              OutlinedButton(onPressed: s.advanceCycle, child: Text(s.t('skip'))),
            ] else ...[
              Text(day['name'], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              Text('${(day['exercises'] as List).length} • ${s.progTitle(s.activeProgram!)}', style: const TextStyle(color: muted)),
              const SizedBox(height: 12),
              FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => TrackerPage(s, Map<String, dynamic>.from(day), s.activeSlug!))), child: Text(s.t('start'))),
            ],
          ]))),
          if (!hid('nutrition')) Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.t('nutrition'), style: const TextStyle(color: muted)),
            const SizedBox(height: 6),
            Text('${tot['k']!.round()} ${s.t('calories')}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _m(s.t('protein'), tot['p']!), _m(s.t('carbs'), tot['c']!), _m(s.t('fat'), tot['f']!)]),
          ]))),
          if (!hid('activity')) Row(children: [
            Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.t('water'), style: const TextStyle(color: muted)),
              Text('${s.waterToday()} ml', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              TextButton(onPressed: () => s.addWater(250), child: const Text('+ 250 ml')),
            ])))),
            const SizedBox(width: 8),
            Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.t('week_workouts'), style: const TextStyle(color: muted)),
              Text('${s.weekSessions}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              Text('${s.weekSets} ${s.t('sets')}', style: const TextStyle(color: muted)),
            ])))),
          ]),
        ]);
      });

  Widget _m(String l, double v) => Column(children: [Text('${v.round()} g', style: const TextStyle(fontWeight: FontWeight.w700)), Text(l, style: const TextStyle(color: muted, fontSize: 12))]);
}
