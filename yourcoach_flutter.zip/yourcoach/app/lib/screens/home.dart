import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'tracker.dart';
import 'ai.dart';

class HomePage extends StatelessWidget {
  final Store s;
  final void Function(int) goTo;
  const HomePage(this.s, {super.key, required this.goTo});
  bool hid(String k) => (s.profile['hidden'] as List?)?.contains(k) ?? false;

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final ar = s.lang == 'ar';
        final day = s.todayDay, prog = s.activeProgram, plan = s.activePlan;
        final tot = s.totals(Store.dayKey());
        final name = '${s.profile['name'] ?? ''}';
        final hr = DateTime.now().hour;
        final greet = hr < 12 ? (ar ? 'صباح الخير' : 'Good morning') : hr < 18 ? (ar ? 'مساء الخير' : 'Good afternoon') : (ar ? 'مساء النور' : 'Good evening');
        final water = s.waterToday();
        final kg = ((s.profile['kg'] as num?) ?? 70).toDouble();
        final wt = math.max(2000, ((kg * 35) / 250).round() * 250);
        final doneDays = <String>{for (final x in s.sessions) (x['at'] as String).substring(0, 10)};
        final planK = (plan?['kcal'] as num?)?.toDouble() ?? 0.0;

        Widget hero;
        if (prog == null) {
          hero = HeroCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.t('today_workout'), style: const TextStyle(color: muted)),
            const SizedBox(height: 8),
            Text(ar ? 'ابدأ ببرنامج' : 'Start with a program', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(ar ? 'اختار برنامج جاهز أو اعمل برنامجك بنفسك' : 'Pick a ready program or build your own', style: const TextStyle(color: muted)),
            const SizedBox(height: 16),
            FilledButton(onPressed: () => goTo(1), child: Text(s.t('programs'))),
          ]));
        } else if (day == null) {
          hero = HeroCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Tag(s.progTitle(prog)), const Spacer(), const Icon(Icons.bedtime_outlined, color: muted)]),
            const SizedBox(height: 12),
            Text(s.t('rest_day'), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(ar ? 'الراحة جزء من التقدم. نام كويس واشرب مياه.' : 'Recovery is part of progress. Sleep well and hydrate.', style: const TextStyle(color: muted)),
            const SizedBox(height: 16),
            OutlinedButton(onPressed: s.advanceCycle, child: Text(s.t('skip'))),
          ]));
        } else {
          final exs = (day['exercises'] as List);
          var sets = 0;
          final mus = <String>{};
          for (final e in exs) {
            sets += ((e['sets_max'] ?? e['sets_min'] ?? 3) as num).toInt();
            final m = s.ex[e['exercise_key']]?['muscle'];
            if (m != null && mus.length < 4) mus.add('$m');
          }
          hero = HeroCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Text(s.t('today_workout'), style: const TextStyle(color: muted)), const Spacer(), Tag(s.progTitle(prog))]),
            const SizedBox(height: 10),
            Text('${day['name']}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, height: 1.1)),
            const SizedBox(height: 6),
            Text('${exs.length} ${ar ? 'تمارين' : 'exercises'}  •  $sets ${s.t('sets')}  •  ~${sets * 3} ${ar ? 'دقيقة' : 'min'}', style: const TextStyle(color: muted)),
            const SizedBox(height: 12),
            Wrap(spacing: 6, runSpacing: 6, children: [for (final m in mus) Tag(s.muscleName(m))]),
            const SizedBox(height: 18),
            FilledButton.icon(
              icon: const Icon(Icons.play_arrow_rounded), label: Text(s.t('start')),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TrackerPage(s, Map<String, dynamic>.from(day), s.activeSlug!)))),
          ]));
        }

        return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 24), children: [
          Row(children: [
            CircleAvatar(radius: 22, backgroundColor: surface2, child: Text(name.isEmpty ? '?' : name.substring(0, 1), style: const TextStyle(color: accent, fontWeight: FontWeight.w800, fontSize: 18))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(greet, style: const TextStyle(color: muted, fontSize: 12.5)),
              Text(name.isEmpty ? 'YOUR COACH' : name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            ])),
            IconButton(
              style: IconButton.styleFrom(backgroundColor: surface, side: const BorderSide(color: line)),
              icon: const Icon(Icons.auto_awesome, color: accent),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AiPage(s)))),
          ]),
          const SizedBox(height: 12),
          if (!hid('workout')) hero,
          Panel(child: Column(children: [
            Row(children: [
              Text(ar ? 'هذا الأسبوع' : 'This week', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              const Spacer(),
              Text('${s.weekSessions} ${s.t('week_workouts')}', style: const TextStyle(color: muted, fontSize: 12.5)),
            ]),
            const SizedBox(height: 14),
            WeekStrip(doneDays, ar: ar),
          ])),
          if (!hid('nutrition')) ...[
            SectionLabel(s.t('nutrition')),
            Panel(child: Column(children: [
              Row(children: [
                CalorieRing(value: tot['k']!, target: planK, big: '${tot['k']!.round()}', small: plan != null ? (ar ? 'من ${plan['kcal']}' : 'of ${plan['kcal']}') : s.t('calories')),
                const SizedBox(width: 18),
                Expanded(child: Column(children: [
                  MacroBar(s.t('protein'), tot['p']!, plan?['p'] as num?, cP, unit: ar ? 'جم' : 'g'),
                  MacroBar(s.t('carbs'), tot['c']!, plan?['c'] as num?, cC, unit: ar ? 'جم' : 'g'),
                  MacroBar(s.t('fat'), tot['f']!, plan?['f'] as num?, cF, unit: ar ? 'جم' : 'g'),
                ])),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                Text(s.t('estimate'), style: const TextStyle(color: muted, fontSize: 11.5)),
                const Spacer(),
                if (plan == null) TextButton(onPressed: () => goTo(2), child: Text(ar ? 'حدد هدفك' : 'Set your target')),
              ]),
            ])),
          ],
          if (!hid('activity')) Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Text(s.t('water'), style: const TextStyle(color: muted)), const Spacer(), const Icon(Icons.water_drop_outlined, color: cP, size: 20)]),
              const SizedBox(height: 8),
              Text(ltr('$water'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              Text(ltr('${ar ? 'مل من' : 'ml of'} $wt'), style: const TextStyle(color: muted, fontSize: 12)),
              const SizedBox(height: 10),
              ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: (water / wt).clamp(0.0, 1.0).toDouble(), minHeight: 7, color: cP, backgroundColor: surface3)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40), padding: EdgeInsets.zero), onPressed: () => s.addWater(250), child: const Text('+250'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40), padding: EdgeInsets.zero), onPressed: () => s.addWater(500), child: const Text('+500'))),
              ]),
            ]))),
            const SizedBox(width: 10),
            Expanded(child: Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Text(ar ? 'حجم التمرين' : 'Volume', style: const TextStyle(color: muted)), const Spacer(), const Icon(Icons.local_fire_department_outlined, color: accent, size: 20)]),
              const SizedBox(height: 8),
              Text('${s.weekSets}', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              Text(ar ? 'مجموعة في 7 أيام' : 'sets in 7 days', style: const TextStyle(color: muted, fontSize: 12)),
              const SizedBox(height: 30),
            ]))),
          ]),
        ]);
      });
}
