import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// Searchable exercise list with muscle filter. Used by the library and as a picker.
class ExerciseList extends StatefulWidget {
  final Store s;
  final void Function(String key) onTap;
  const ExerciseList(this.s, {super.key, required this.onTap});
  @override
  State<ExerciseList> createState() => _ExerciseListState();
}

class _ExerciseListState extends State<ExerciseList> {
  String q = '';
  String? muscle;
  String norm(String x) => x.toLowerCase().replaceAll(RegExp('[أإآ]'), 'ا').replaceAll('ة', 'ه').replaceAll('ى', 'ي');

  Future<void> addCustom() async {
    final s = widget.s;
    final n = TextEditingController();
    var m = 'chest';
    final ok = await showDialog<bool>(context: context, builder: (d) => StatefulBuilder(builder: (_, set) => AlertDialog(
      title: Text(s.t('custom_ex')),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, decoration: InputDecoration(hintText: s.t('ex_name'))),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: m, items: [for (final k in Store.muscleAr.keys) DropdownMenuItem(value: k, child: Text(s.muscleName(k)))],
          onChanged: (v) => set(() => m = v ?? m)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('save')))])));
    if (ok == true && n.text.trim().isNotEmpty) {
      final key = await s.addCustomExercise(n.text.trim(), m);
      widget.onTap(key);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final muscles = s.ex.values.map((e) => e['muscle'] as String).toSet().toList()..sort();
    final res = s.ex.values.where((e) => (muscle == null || e['muscle'] == muscle) &&
      norm('${e['name_ar']} ${e['name_en']}').contains(norm(q))).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: TextField(onChanged: (v) => setState(() => q = v),
        decoration: InputDecoration(hintText: s.t('search_food'), prefixIcon: const Icon(Icons.search)))),
      SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
        Padding(padding: const EdgeInsets.only(left: 6, right: 6), child: ChoiceChip(label: Text(s.t('all')), selected: muscle == null, onSelected: (_) => setState(() => muscle = null))),
        for (final m in muscles) Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(s.muscleName(m)), selected: muscle == m, onSelected: (_) => setState(() => muscle = m))),
      ])),
      Expanded(child: ListView(children: [
        ListTile(leading: const Icon(Icons.add_circle_outline, color: accent), title: Text(s.t('custom_ex')), onTap: addCustom),
        for (final e in res) ListTile(title: Text(s.exName(e['key'])), subtitle: Text('${s.muscleName(e['muscle'])} • ${e['equipment']}', style: const TextStyle(color: muted)),
          onTap: () => widget.onTap(e['key'])),
      ])),
    ]);
  }
}

class LibraryPage extends StatelessWidget {
  final Store s;
  const LibraryPage(this.s, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(s.t('library'))),
        body: ExerciseList(s, onTap: (k) => Navigator.push(context, MaterialPageRoute(builder: (_) => ExerciseDetail(s, k)))),
      );
}

class ExerciseDetail extends StatelessWidget {
  final Store s;
  final String k;
  const ExerciseDetail(this.s, this.k, {super.key});
  @override
  Widget build(BuildContext context) {
    final e = s.ex[k]!;
    final pr = s.prs()[k];
    final alts = s.ex.values.where((x) => x['key'] != k && x['muscle'] == e['muscle']).toList()
      ..sort((a, b) => (b['equipment'] == e['equipment'] ? 1 : 0).compareTo(a['equipment'] == e['equipment'] ? 1 : 0));
    return Scaffold(
      appBar: AppBar(title: Text(s.exName(k))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(e['name_ar'], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Text(e['name_en'], style: const TextStyle(color: muted)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [Chip(label: Text(s.muscleName(e['muscle']))), Chip(label: Text('${e['equipment']}'))]),
        Card(child: Container(height: 140, alignment: Alignment.center,
          child: e['video_url'] == null ? Text(s.t('no_video'), style: const TextStyle(color: muted)) : Text('${e['video_url']}'))),
        if (pr != null) Card(child: ListTile(title: Text(s.t('best')),
          subtitle: Text('${pr['kg']} × ${pr['reps']}'), trailing: Text('${(pr['e1rm'] as double).toStringAsFixed(1)} kg',
            style: const TextStyle(fontWeight: FontWeight.w800, color: accent)))),
        Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(s.t('alternatives'), style: const TextStyle(color: muted))),
        for (final a in alts.take(8)) ListTile(dense: true, title: Text(s.exName(a['key'])), subtitle: Text('${a['equipment']}'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExerciseDetail(s, a['key'])))),
      ]),
    );
  }
}
