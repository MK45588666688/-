import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// Personal goals (user-defined) + low-key achievements computed from real logs.
class GoalsPage extends StatelessWidget {
  final Store s;
  const GoalsPage(this.s, {super.key});

  Future<void> _edit(BuildContext context, [Map<String, dynamic>? g]) async {
    final t = TextEditingController(text: g?['title'] ?? ''), tg = TextEditingController(text: g == null ? '' : '${g['target']}'),
        u = TextEditingController(text: g?['unit'] ?? ''), cur = TextEditingController(text: g == null ? '0' : '${g['current']}');
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(s.t('new_goal')),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: t, decoration: InputDecoration(labelText: s.t('goal_title'))),
        const SizedBox(height: 8),
        TextField(controller: tg, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: s.t('goal_target'))),
        const SizedBox(height: 8),
        TextField(controller: u, decoration: InputDecoration(labelText: s.t('goal_unit'))),
        const SizedBox(height: 8),
        TextField(controller: cur, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: s.t('goal_current'))),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(d, true), child: Text(s.t('save'))),
      ]));
    final target = double.tryParse(tg.text.replaceAll(',', '.')), current = double.tryParse(cur.text.replaceAll(',', '.'));
    if (ok == true && t.text.trim().isNotEmpty && target != null && target > 0 && current != null) {
      await s.saveGoal({'id': g?['id'] ?? DateTime.now().microsecondsSinceEpoch.toString(), 'title': t.text.trim(), 'target': target, 'unit': u.text.trim(), 'current': current});
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) {
        final ach = s.achievements();
        return Scaffold(
          appBar: AppBar(title: Text(s.t('goals'))),
          floatingActionButton: FloatingActionButton.extended(backgroundColor: accent, foregroundColor: Colors.black,
            onPressed: () => _edit(context), icon: const Icon(Icons.add), label: Text(s.t('new_goal'))),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            for (final g in s.goals) Card(child: InkWell(onTap: () => _edit(context, g), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(g['title'], style: const TextStyle(fontWeight: FontWeight.w700))),
                IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => s.removeGoal(g['id'])),
              ]),
              Text('${g['current']} / ${g['target']} ${g['unit']}', style: const TextStyle(color: muted)),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: ((g['current'] as num) / (g['target'] as num)).clamp(0.0, 1.0).toDouble(), color: accent, backgroundColor: surface2),
            ])))),
            Padding(padding: const EdgeInsets.only(top: 16, bottom: 4), child: Text(s.t('achievements'), style: const TextStyle(color: muted))),
            for (final e in ach.entries) ListTile(dense: true, leading: Icon(e.value ? Icons.check_circle : Icons.radio_button_unchecked, color: e.value ? accent : muted),
              title: Text(s.t(e.key), style: TextStyle(color: e.value ? null : muted))),
            const SizedBox(height: 80),
          ]),
        );
      });
}
