import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../store.dart';
import '../theme.dart';
import 'account.dart';
import 'goals.dart';
import 'articles.dart';
import 'onboarding.dart';

class ProfilePage extends StatelessWidget {
  final Store s;
  const ProfilePage(this.s, {super.key});

  bool _hid(String k) => (s.profile['hidden'] as List?)?.contains(k) ?? false;
  Future<void> _toggle(String k, bool show) {
    final h = List<String>.from(s.profile['hidden'] ?? []);
    show ? h.remove(k) : (h.contains(k) ? null : h.add(k));
    return s.saveProfile({...s.profile, 'hidden': h});
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) => ListView(padding: const EdgeInsets.all(16), children: [
        Text(s.profile['name'] ?? s.t('profile'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Card(child: ListTile(leading: const Icon(Icons.edit), title: Text(s.t('edit_profile')),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OnboardingPage(s, edit: true))))),
        Card(child: ListTile(leading: const Icon(Icons.emoji_events_outlined), title: Text(s.t('goals')),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GoalsPage(s))))),
        Card(child: ListTile(leading: const Icon(Icons.menu_book_outlined), title: Text(s.t('articles')),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ArticlesPage(s))))),
        Card(child: ListTile(leading: const Icon(Icons.cloud_outlined), title: Text(s.t('account')),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AccountPage(s))))),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.t('language')),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'ar', label: Text('العربية')), ButtonSegment(value: 'en', label: Text('English'))],
            selected: {s.lang}, onSelectionChanged: (v) => s.setLang(v.first)),
        ]))),
        Card(child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0), child: Align(alignment: AlignmentDirectional.centerStart, child: Text(s.t('customize_home'), style: const TextStyle(color: muted)))),
          for (final k in ['workout', 'nutrition', 'activity']) SwitchListTile(title: Text(s.t('w_$k')), value: !_hid(k), activeColor: accent, onChanged: (v) => _toggle(k, v)),
        ])),
        Card(child: ListTile(leading: const Icon(Icons.copy), title: Text(s.t('export')), onTap: () async {
          await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent(' ').convert(s.toJson())));
          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('copied'))));
        })),
        Card(child: ListTile(
          leading: const Icon(Icons.delete_outline, color: Colors.redAccent), title: Text(s.t('reset')),
          onTap: () => showDialog(context: context, builder: (d) => AlertDialog(
            title: Text(s.t('reset')),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d), child: Text(s.t('cancel'))),
              TextButton(onPressed: () { s.wipe(); Navigator.pop(d); }, child: Text(s.t('confirm'))),
            ])))),
      ]));
}
