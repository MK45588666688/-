import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';

/// Weekly nutrition report: averages over *logged* days only, so missed days don't fake a low average.
class ReportPage extends StatelessWidget {
  final Store s;
  const ReportPage(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final days = [for (var i = 6; i >= 0; i--) Store.dayKey(DateTime.now().subtract(Duration(days: i)))];
    final rows = [for (final d in days) (d, s.totals(d), s.mealsOn(d).isNotEmpty, s.water[d] ?? 0)];
    final logged = rows.where((r) => r.$3).toList();
    double avg(String k) => logged.isEmpty ? 0 : logged.fold(0.0, (a, r) => a + r.$2[k]!) / logged.length;
    final target = (s.activePlan?['kcal'] as num?)?.toDouble();
    final maxK = [target ?? 0, ...rows.map((r) => r.$2['k']!), 1.0].reduce((a, b) => a > b ? a : b);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('report'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${s.t('logged_days')}: ${logged.length}/7', style: const TextStyle(color: muted)),
          const SizedBox(height: 6),
          Text('${s.t('avg_logged')}: ${avg('k').round()} kcal', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          Text('${s.t('protein')} ${avg('p').round()}g • ${s.t('carbs')} ${avg('c').round()}g • ${s.t('fat')} ${avg('f').round()}g'),
        ]))),
        for (final r in rows) Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [
          SizedBox(width: 48, child: Text(r.$1.substring(5), style: const TextStyle(color: muted, fontSize: 12))),
          Expanded(child: Stack(children: [
            Container(height: 18, decoration: BoxDecoration(color: surface2, borderRadius: BorderRadius.circular(6))),
            FractionallySizedBox(widthFactor: (r.$2['k']! / maxK).clamp(0.0, 1.0), child: Container(height: 18, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(6)))),
          ])),
          SizedBox(width: 90, child: Text('${r.$2['k']!.round()} • ${r.$4 ~/ 100 / 10}L', textAlign: TextAlign.end, style: const TextStyle(fontSize: 12))),
        ])),
        if (target != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text('${s.t('target')}: ${target.round()} kcal', style: const TextStyle(color: muted))),
      ]),
    );
  }
}
