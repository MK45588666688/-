import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_scanner/mobile_scanner.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

/// Barcode -> Open Food Facts (public crowd-sourced DB, no key). Values are NOT verified: the user reviews/edits, then saves as "my food".
class BarcodePage extends StatefulWidget {
  final Store s;
  const BarcodePage(this.s, {super.key});
  @override
  State<BarcodePage> createState() => _BarcodeState();
}

class _BarcodeState extends State<BarcodePage> {
  final code = TextEditingController(), name = TextEditingController(), k = TextEditingController(), p = TextEditingController(),
      c = TextEditingController(), f = TextEditingController();
  bool scanning = false, busy = false, found = false; String? msg;

  Future<void> _lookup(String bc) async {
    setState(() { busy = true; msg = null; found = false; scanning = false; code.text = bc; });
    try {
      final r = await http.get(Uri.parse('https://world.openfoodfacts.org/api/v2/product/$bc.json?fields=product_name,product_name_ar,nutriments')).timeout(const Duration(seconds: 12));
      final j = jsonDecode(r.body) as Map<String, dynamic>;
      if (j['status'] == 1) {
        final pr = j['product'] as Map<String, dynamic>, n = (pr['nutriments'] ?? {}) as Map<String, dynamic>;
        String v(String key) => n[key] == null ? '' : '${(n[key] as num).toStringAsFixed(1)}';
        name.text = '${pr['product_name_ar'] ?? pr['product_name'] ?? ''}';
        k.text = v('energy-kcal_100g'); p.text = v('proteins_100g'); c.text = v('carbohydrates_100g'); f.text = v('fat_100g');
        found = true;
      } else { msg = widget.s.t('not_found'); }
    } catch (_) { msg = widget.s.t('failed'); }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    double? d(TextEditingController t) => double.tryParse(t.text.replaceAll(',', '.'));
    return Scaffold(
      appBar: ModernBar(s.t('barcode')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: TextField(controller: code, keyboardType: TextInputType.number, decoration: InputDecoration(hintText: s.t('barcode_hint')))),
          IconButton(icon: const Icon(Icons.qr_code_scanner, color: accent), onPressed: () => setState(() => scanning = !scanning)),
          IconButton(icon: const Icon(Icons.search), onPressed: busy ? null : () { if (code.text.trim().isNotEmpty) _lookup(code.text.trim()); }),
        ]),
        if (scanning) SizedBox(height: 260, child: ClipRRect(borderRadius: BorderRadius.circular(16), child: MobileScanner(onDetect: (cap) {
          final v = cap.barcodes.isEmpty ? null : cap.barcodes.first.rawValue; if (v != null && !busy) _lookup(v); }))),
        if (busy) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator(color: accent)),
        if (msg != null) Padding(padding: const EdgeInsets.all(8), child: Text(msg!, style: const TextStyle(color: muted))),
        if (found) ...[
          const SizedBox(height: 8),
          Text('${s.t('estimate')} • ${s.t('per100')}', style: const TextStyle(color: accent, fontSize: 12)),
          TextField(controller: name, decoration: InputDecoration(labelText: s.t('name'))),
          const SizedBox(height: 8),
          Row(children: [for (final e in [(k, 'kcal'), (p, 'P'), (c, 'C'), (f, 'F')]) Expanded(child: Padding(padding: const EdgeInsets.all(2),
            child: TextField(controller: e.$1, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: e.$2))))]),
          const SizedBox(height: 12),
          FilledButton(onPressed: () async {
            final kk = d(k), pp = d(p), cc = d(c), ff = d(f);
            if (name.text.trim().isEmpty || kk == null || pp == null || cc == null || ff == null || kk < 0 || kk > 950) return;
            await s.addCustomFood({'id': 'bc_${code.text.trim()}', 'ar': name.text.trim(), 'en': name.text.trim(), 'k': kk, 'p': pp, 'c': cc, 'f': ff, 'srv': 100, 'src': 'barcode'});
            if (context.mounted) Navigator.pop(context);
          }, child: Text(s.t('save'))),
        ],
      ]),
    );
  }
}
