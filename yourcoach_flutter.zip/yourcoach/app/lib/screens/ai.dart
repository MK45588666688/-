import 'package:flutter/material.dart';
import '../ai_client.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

/// AI assistant: meal analyzer (editable, flagged as estimate) + chat (training / nutrition / my data).
/// Uses the personal API key saved on the device. Never changes plans by itself.
class AiPage extends StatefulWidget {
  final Store s;
  const AiPage(this.s, {super.key});
  @override
  State<AiPage> createState() => _AiPageState();
}

String _why(Object e) {
  final raw = e is StateError ? e.message : '$e';
  if (raw.contains('API key not valid') || raw.contains('API_KEY_INVALID')) return 'المفتاح غير صحيح. انسخه تاني كامل من الموقع.';
  if (raw.contains('HTTP 401')) return 'المفتاح غير صحيح (401). راجع المفتاح من أيقونة المفتاح.';
  if (raw.contains('HTTP 403')) return 'غير مسموح (403). راجع المفتاح وصلاحياته.';
  if (raw.contains('HTTP 404')) return 'اسم النموذج غير متاح لحسابك (404). غيّره من أيقونة المفتاح.';
  if (raw.contains('HTTP 429') || raw.contains('RESOURCE_EXHAUSTED')) return 'وصلت للحد المسموح حاليًا (429). استنى دقيقة وجرّب تاني.';
  if (raw.contains('credit') || raw.contains('billing')) return 'الرصيد خلص أو الحساب محتاج شحن. اشحن من console.anthropic.com. ($raw)';
  if (raw.contains('SocketException') || raw.contains('ClientException') || raw.contains('Failed host lookup')) return 'تعذر الاتصال بالإنترنت. اتأكد من النت وإن التطبيق محدّث.';
  if (raw.contains('TimeoutException')) return 'انتهى الوقت. جرّب تاني.';
  return raw.length > 220 ? raw.substring(0, 220) : raw;
}

bool _minor(Store s) => s.profile['minor'] == true || ((s.profile['age'] as num?) ?? 99) < 18;

class _AiPageState extends State<AiPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  String mode = 'meal';
  bool busy = false;
  String? err;
  final msgs = <Map<String, String>>[];
  List<Map<String, dynamic>> items = [];
  String note = '';
  List<String> qs = [];
  String type = 'lunch';

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  String _label(String m) {
    final s = widget.s;
    if (m == 'meal') return s.t('ai_meal');
    if (m == 'train') return s.t('mode_train');
    if (m == 'nutri') return s.t('mode_nutri');
    return s.t('mode_data');
  }

  List<String> _ideas() {
    final ar = widget.s.lang == 'ar';
    if (mode == 'meal') return ar ? ['200 جم رز و150 جم فراخ وسلطة', 'طبق كشري كبير', '3 بيضات مسلوقة وعيش بلدي'] : ['200 g rice, 150 g chicken, salad', 'A large koshari plate', '3 boiled eggs and baladi bread'];
    if (mode == 'train') return ar ? ['يعني إيه RIR؟', 'إزاي أزود الأوزان بأمان؟', 'بدائل لتمرين السكوات'] : ['What does RIR mean?', 'How do I add weight safely?', 'Alternatives to squats'];
    if (mode == 'nutri') return ar ? ['بدائل للرز؟', 'محتاج بروتين كام يوميًا؟'] : ['Rice alternatives?', 'How much protein per day?'];
    return ar ? ['أنهي تمرين اتحسن أكتر؟', 'عملت كام تمرين الشهر ده؟', 'متوسط البروتين بتاعي كام؟'] : ['Which lift improved most?', 'How many workouts this month?', 'My average protein?'];
  }

  Map<String, dynamic> _data() {
    final s = widget.s;
    final from = DateTime.now().subtract(const Duration(days: 90));
    final ss = s.sessions.where((x) => DateTime.parse(x['at']).isAfter(from)).toList();
    return {
      'today': Store.dayKey(), 'window_days': 90, 'workouts_logged': ss.length,
      'sessions': [for (final x in ss.take(60)) {'at': (x['at'] as String).substring(0, 10), 'day': x['day'], 'working_sets': [for (final y in (x['sets'] as List)) if (y['warm'] != true) {'ex': s.exName(y['key']), 'kg': y['kg'], 'reps': y['reps']}]}],
      'best_e1rm': {for (final e in s.prs().entries) s.exName(e.key): (e.value['e1rm'] as double).round()},
      'daily_nutrition_last_14': {for (var i = 0; i < 14; i++) Store.dayKey(DateTime.now().subtract(Duration(days: i))): s.totals(Store.dayKey(DateTime.now().subtract(Duration(days: i))))},
      'weights': s.weights.length > 30 ? s.weights.sublist(s.weights.length - 30) : s.weights,
      'cardio_last_30': s.cardio.where((x) => DateTime.parse(x['at']).isAfter(DateTime.now().subtract(const Duration(days: 30)))).toList(),
      'active_plan': s.activePlan,
    };
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  Future<void> _send() async {
    final t = input.text.trim();
    if (t.isEmpty || busy) return;
    final s = widget.s;
    FocusScope.of(context).unfocus();
    setState(() { busy = true; err = null; });
    try {
      if (mode == 'meal') {
        final r = await AiClient.call({'mode': 'meal', 'text': t, 'minor': _minor(s)});
        final m = Map<String, dynamic>.from(r['meal'] as Map);
        items = [for (final i in (m['items'] as List)) Map<String, dynamic>.from(i as Map)];
        note = '${m['uncertainty'] ?? ''}';
        qs = [for (final q in (m['questions'] as List? ?? [])) '$q'];
        input.clear();
      } else {
        msgs.add({'role': 'user', 'content': t});
        input.clear();
        setState(() {});
        final r = await AiClient.call({'mode': mode, 'text': t, 'minor': _minor(s), 'history': msgs.sublist(0, msgs.length - 1), if (mode == 'data') 'data': _data()});
        msgs.add({'role': 'assistant', 'content': '${r['reply']}'});
      }
    } catch (e) {
      err = _why(e);
    }
    if (mounted) setState(() => busy = false);
    _toEnd();
  }

  void _setGrams(int i, double g) {
    final it = items[i];
    final old = (it['grams'] as num).toDouble();
    if (old <= 0 || g <= 0) return;
    final f = g / old;
    for (final k in ['kcal', 'protein', 'carbs', 'fat']) {
      it[k] = (it[k] as num) * f;
    }
    it['grams'] = g;
    it['assumed'] = false;
  }

  Future<void> _keySheet() async {
    final s = widget.s;
    final k = TextEditingController();
    final m = TextEditingController(text: AiClient.effectiveModel);
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true,
      builder: (c) => Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, MediaQuery.of(c).viewInsets.bottom + 20),
        child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const IconBox(Icons.key_rounded),
            const SizedBox(width: 12),
            Expanded(child: Text(s.t('api_key'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: accentSoft, borderRadius: BorderRadius.circular(14)),
            child: Text(s.t('free_key_hint'), style: const TextStyle(fontSize: 12.5, height: 1.5))),
          const SizedBox(height: 14),
          TextField(controller: k, obscureText: true, autocorrect: false, enableSuggestions: false, decoration: InputDecoration(hintText: AiClient.hasKey ? '••••••••  (${s.t('saved')})' : 'AIza... / sk-ant-...')),
          const SizedBox(height: 10),
          TextField(controller: m, autocorrect: false, decoration: InputDecoration(labelText: s.t('api_model'))),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            for (final n in const ['gemini-2.5-flash', 'claude-haiku-5-5']) ActionChip(label: Text(n), onPressed: () => m.text = n),
          ]),
          const SizedBox(height: 10),
          Text(s.t('key_note'), style: const TextStyle(color: muted, fontSize: 12)),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () async {
              if (k.text.trim().isNotEmpty) {
                await AiClient.saveKey(k.text, m.text);
              } else {
                await AiClient.setModel(m.text);
              }
              if (c.mounted) Navigator.pop(c);
            },
            child: Text(s.t('save'))),
          if (AiClient.hasKey) TextButton(onPressed: () async { await AiClient.clearKey(); if (c.mounted) Navigator.pop(c); }, child: Text(s.t('clear_key'))),
        ])),
      ),
    );
    if (mounted) setState(() {});
  }

  Widget _empty() {
    final s = widget.s;
    return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const IconBox(Icons.auto_awesome, size: 64),
      const SizedBox(height: 18),
      Text(s.t('ai'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Text(s.t('ai_off'), textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.5)),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: _keySheet, icon: const Icon(Icons.key_rounded), label: Text(s.t('api_key'))),
    ])));
  }

  Widget _hintPanel() {
    final s = widget.s;
    return Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        IconBox(mode == 'meal' ? Icons.restaurant_rounded : Icons.auto_awesome),
        const SizedBox(width: 12),
        Expanded(child: Text(mode == 'meal' ? s.t('describe_meal') : s.t('ask_hint'), style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4))),
      ]),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 4, children: [for (final t in _ideas()) ActionChip(label: Text(t), onPressed: () => setState(() => input.text = t))]),
    ]));
  }

  Widget _bubble(Map<String, String> m) {
    final user = m['role'] == 'user';
    return Align(
      alignment: user ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .82),
        decoration: BoxDecoration(color: user ? accentSoft : surface2, borderRadius: BorderRadius.circular(18), border: Border.all(color: user ? accent.withOpacity(.35) : line)),
        child: SelectableText(m['content'] ?? '', style: const TextStyle(height: 1.5)),
      ),
    );
  }

  Widget _mealResult() {
    final s = widget.s;
    double kc = 0;
    for (final it in items) {
      kc += (it['kcal'] as num).toDouble();
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Tag(s.t('ai_estimate'), hot: true)]),
      if (note.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(note, style: const TextStyle(color: muted, fontSize: 12.5, height: 1.4))),
      for (final q in qs) Padding(padding: const EdgeInsets.only(top: 6), child: Text('• $q', style: const TextStyle(fontSize: 13.5))),
      const SizedBox(height: 6),
      for (var i = 0; i < items.length; i++)
        Panel(padding: const EdgeInsets.fromLTRB(14, 10, 8, 10), child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.lang == 'ar' ? '${items[i]['name_ar']}' : '${items[i]['name_en']}', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(ltr('${(items[i]['kcal'] as num).round()} kcal · P${(items[i]['protein'] as num).round()} C${(items[i]['carbs'] as num).round()} F${(items[i]['fat'] as num).round()}${items[i]['assumed'] == true ? ' · ~' : ''}'), style: const TextStyle(color: muted, fontSize: 12.5)),
          ])),
          SizedBox(width: 86, child: TextFormField(
            key: ValueKey('${items[i]['name_en']}$i${items[i]['grams']}'),
            initialValue: '${(items[i]['grams'] as num).round()}', keyboardType: TextInputType.number, textAlign: TextAlign.center,
            decoration: const InputDecoration(suffixText: 'g', isDense: true),
            onFieldSubmitted: (v) { final g = double.tryParse(v); if (g != null && g > 0 && g <= 5000) setState(() => _setGrams(i, g)); })),
          IconButton(icon: const Icon(Icons.close, size: 18, color: muted), onPressed: () => setState(() => items.removeAt(i))),
        ])),
      if (items.isNotEmpty) ...[
        Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('${s.t('estimate')}: ~${kc.round()} kcal', style: const TextStyle(color: muted, fontSize: 13))),
        Wrap(spacing: 8, runSpacing: 4, children: [
          for (final t in const ['breakfast', 'lunch', 'dinner', 'snack']) ChoiceChip(label: Text(s.t(t)), selected: type == t, onSelected: (_) => setState(() => type = t)),
        ]),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: () async {
            for (final it in items) {
              await s.addRaw(s.lang == 'ar' ? '${it['name_ar']}' : '${it['name_en']}', (it['kcal'] as num).toDouble(), (it['protein'] as num).toDouble(),
                (it['carbs'] as num).toDouble(), (it['fat'] as num).toDouble(), (it['grams'] as num).toDouble(), type, source: 'ai_estimate');
            }
            if (mounted) {
              setState(() { items = []; qs = []; note = ''; });
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('done'))));
            }
          },
          child: Text(s.t('confirm_log'))),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Scaffold(
      appBar: ModernBar(s.t('ai'), actions: [
        IconButton(
          style: IconButton.styleFrom(backgroundColor: surface, side: const BorderSide(color: line)),
          icon: const Icon(Icons.key_rounded, size: 20), onPressed: _keySheet),
      ]),
      body: !AiClient.available
          ? _empty()
          : Column(children: [
              SizedBox(height: 50, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), children: [
                for (final m in const ['meal', 'train', 'nutri', 'data'])
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: ChoiceChip(label: Text(_label(m)), selected: mode == m, onSelected: (_) => setState(() { mode = m; err = null; })),
                  ),
              ])),
              Expanded(child: ListView(controller: scroll, padding: const EdgeInsets.fromLTRB(16, 8, 16, 16), children: [
                if (mode == 'meal') ...[
                  if (items.isEmpty) _hintPanel() else _mealResult(),
                ] else ...[
                  if (msgs.isEmpty) _hintPanel(),
                  for (final m in msgs) _bubble(m),
                ],
                if (busy) const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: LinearProgressIndicator(color: accent, backgroundColor: surface3, minHeight: 4)),
                if (err != null) Panel(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.error_outline, color: Colors.redAccent),
                  const SizedBox(width: 10),
                  Expanded(child: Text(err!, style: const TextStyle(height: 1.5))),
                ])),
                Padding(padding: const EdgeInsets.only(top: 10), child: Text(s.t('ai_disclaimer'), style: const TextStyle(color: muted, fontSize: 11))),
              ])),
              Container(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                decoration: const BoxDecoration(color: surface, border: Border(top: BorderSide(color: line))),
                child: SafeArea(top: false, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Expanded(child: TextField(
                    controller: input, minLines: 1, maxLines: 4, textInputAction: TextInputAction.send, onSubmitted: (_) => _send(),
                    decoration: InputDecoration(hintText: mode == 'meal' ? s.t('describe_meal') : s.t('ask_hint')))),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: busy ? null : _send,
                    style: IconButton.styleFrom(backgroundColor: accent, foregroundColor: const Color(0xFF0B0B0C), minimumSize: const Size(52, 52)),
                    icon: const Icon(Icons.arrow_upward_rounded)),
                ])),
              ),
            ]),
    );
  }
}
