import 'package:flutter/material.dart';
import '../ai_client.dart';
import '../store.dart';
import '../theme.dart';

/// AI assistant: meal analyzer (results are editable + flagged as estimates) and chat (training / nutrition / my data).
/// Needs: cloud configured + signed in + `ai` Edge Function deployed (backend/functions/ai). Never changes plans by itself.
class AiPage extends StatefulWidget {
  final Store s;
  const AiPage(this.s, {super.key});
  @override
  State<AiPage> createState() => _AiPageState();
}

class _AiPageState extends State<AiPage> {
  Future<void> _keyDialog() async {
    final s = widget.s;
    final k = TextEditingController(), m = TextEditingController(text: AiClient.model);
    await showDialog<void>(context: context, builder: (d) => AlertDialog(
      title: Text(s.t('api_key')),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextField(controller: k, obscureText: true, autocorrect: false, enableSuggestions: false, decoration: InputDecoration(hintText: AiClient.hasKey ? '••••••••' : 'sk-ant-...')),
        const SizedBox(height: 8),
        TextField(controller: m, autocorrect: false, decoration: InputDecoration(labelText: s.t('api_model'))),
        const SizedBox(height: 8),
        Text(s.t('key_note'), style: const TextStyle(color: muted, fontSize: 11)),
      ])),
      actions: [
        if (AiClient.hasKey) TextButton(onPressed: () async { await AiClient.clearKey(); if (d.mounted) Navigator.pop(d); }, child: Text(s.t('clear_key'))),
        TextButton(onPressed: () => Navigator.pop(d), child: Text(s.t('cancel'))),
        TextButton(onPressed: () async { if (k.text.trim().isNotEmpty) await AiClient.saveKey(k.text, m.text); if (d.mounted) Navigator.pop(d); }, child: Text(s.t('save'))),
      ]));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return DefaultTabController(length: 2, child: Scaffold(
      appBar: AppBar(title: Text(s.t('ai')), actions: [IconButton(icon: const Icon(Icons.key), onPressed: _keyDialog)],
        bottom: TabBar(indicatorColor: accent, tabs: [Tab(text: s.t('ai_meal')), Tab(text: s.t('ai_chat'))])),
      body: !AiClient.available
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(s.t('ai_off'), textAlign: TextAlign.center, style: const TextStyle(color: muted))))
          : TabBarView(children: [_MealTab(s), _ChatTab(s)]),
    ));
  }
}

bool _minor(Store s) => s.profile['minor'] == true || ((s.profile['age'] as num?) ?? 99) < 18;

class _MealTab extends StatefulWidget {
  final Store s;
  const _MealTab(this.s);
  @override
  State<_MealTab> createState() => _MealTabState();
}

class _MealTabState extends State<_MealTab> {
  final c = TextEditingController();
  bool busy = false; String? err; String type = 'lunch';
  List<Map<String, dynamic>> items = []; String note = ''; List<String> qs = [];

  Future<void> _go() async {
    if (c.text.trim().isEmpty) return;
    setState(() { busy = true; err = null; });
    try {
      final r = await AiClient.call({'mode': 'meal', 'text': c.text, 'minor': _minor(widget.s)});
      final m = Map<String, dynamic>.from(r['meal'] as Map);
      setState(() {
        items = [for (final i in (m['items'] as List)) Map<String, dynamic>.from(i as Map)];
        note = '${m['uncertainty'] ?? ''}'; qs = [for (final q in (m['questions'] as List? ?? [])) '$q'];
      });
    } catch (_) { setState(() => err = widget.s.t('failed')); }
    if (mounted) setState(() => busy = false);
  }

  /// Rescale an item's macros when the user edits grams (keeps AI's per-gram ratios).
  void _setGrams(int i, double g) { final it = items[i]; final old = (it['grams'] as num).toDouble(); if (old <= 0 || g <= 0) return;
    final f = g / old; for (final k in ['kcal', 'protein', 'carbs', 'fat']) { it[k] = (it[k] as num) * f; } it['grams'] = g; it['assumed'] = false; }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: c, minLines: 2, maxLines: 4, decoration: InputDecoration(hintText: s.t('describe_meal'))),
      const SizedBox(height: 8),
      FilledButton(onPressed: busy ? null : _go, child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(s.t('analyze'))),
      if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
      if (items.isNotEmpty) ...[
        const SizedBox(height: 12),
        Text(s.t('ai_estimate'), style: const TextStyle(color: accent, fontWeight: FontWeight.w700)),
        if (note.isNotEmpty) Text(note, style: const TextStyle(color: muted, fontSize: 12)),
        for (final q in qs) Text('• $q', style: const TextStyle(fontSize: 13)),
        for (var i = 0; i < items.length; i++) Card(child: ListTile(
          title: Text(s.lang == 'ar' ? '${items[i]['name_ar']}' : '${items[i]['name_en']}'),
          subtitle: Text('${(items[i]['kcal'] as num).round()} kcal • P${(items[i]['protein'] as num).round()} C${(items[i]['carbs'] as num).round()} F${(items[i]['fat'] as num).round()}${items[i]['assumed'] == true ? ' • ~' : ''}'),
          trailing: SizedBox(width: 90, child: TextFormField(
            key: ValueKey('${items[i]['name_en']}$i${items[i]['grams']}'), initialValue: '${(items[i]['grams'] as num).round()}', keyboardType: TextInputType.number,
            decoration: const InputDecoration(suffixText: 'g', isDense: true),
            onFieldSubmitted: (v) { final g = double.tryParse(v); if (g != null && g > 0 && g <= 5000) setState(() => _setGrams(i, g)); })),
          leading: IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => items.removeAt(i))))),
        Wrap(spacing: 8, children: [for (final t in ['breakfast', 'lunch', 'dinner', 'snack']) ChoiceChip(label: Text(s.t(t)), selected: type == t, selectedColor: accent.withOpacity(.3), onSelected: (_) => setState(() => type = t))]),
        const SizedBox(height: 8),
        FilledButton(onPressed: () async {
          for (final it in items) {
            await s.addRaw(s.lang == 'ar' ? '${it['name_ar']}' : '${it['name_en']}', (it['kcal'] as num).toDouble(), (it['protein'] as num).toDouble(),
              (it['carbs'] as num).toDouble(), (it['fat'] as num).toDouble(), (it['grams'] as num).toDouble(), type, source: 'ai_estimate');
          }
          if (mounted) { setState(() { items = []; c.clear(); }); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('done')))); }
        }, child: Text(s.t('confirm_log'))),
      ],
    ]);
  }
}

class _ChatTab extends StatefulWidget {
  final Store s;
  const _ChatTab(this.s);
  @override
  State<_ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<_ChatTab> {
  final c = TextEditingController();
  String mode = 'train'; bool busy = false;
  final msgs = <Map<String, String>>[];

  /// Compact summary of the user's OWN logged data, sent only in "my data" mode.
  Map<String, dynamic> _data() {
    final s = widget.s; final from = DateTime.now().subtract(const Duration(days: 90));
    final ss = s.sessions.where((x) => DateTime.parse(x['at']).isAfter(from)).toList();
    return {
      'today': Store.dayKey(), 'window_days': 90, 'workouts_logged': ss.length,
      'sessions': [for (final x in ss.take(60)) {'at': (x['at'] as String).substring(0, 10), 'day': x['day'], 'working_sets': [for (final y in (x['sets'] as List)) if (y['warm'] != true) {'ex': s.exName(y['key']), 'kg': y['kg'], 'reps': y['reps']}]}],
      'best_e1rm': {for (final e in s.prs().entries) s.exName(e.key): (e.value['e1rm'] as double).round()},
      'daily_nutrition_last_14': {for (var i = 0; i < 14; i++) Store.dayKey(DateTime.now().subtract(Duration(days: i))): s.totals(Store.dayKey(DateTime.now().subtract(Duration(days: i))))},
      'weights': s.weights.length > 30 ? s.weights.sublist(s.weights.length - 30) : s.weights,
      'cardio_last_30': s.cardio.where((x) => DateTime.parse(x['at']).isAfter(DateTime.now().subtract(const Duration(days: 30)))).toList(),
      'active_plan': s.activePlan,
    };
  }

  Future<void> _send() async {
    final t = c.text.trim(); if (t.isEmpty || busy) return;
    final s = widget.s;
    setState(() { msgs.add({'role': 'user', 'content': t}); busy = true; c.clear(); });
    try {
      final r = await AiClient.call({'mode': mode, 'text': t, 'minor': _minor(s), 'history': msgs.sublist(0, msgs.length - 1),
        if (mode == 'data') 'data': _data()});
      setState(() => msgs.add({'role': 'assistant', 'content': '${r['reply']}'}));
    } catch (_) { setState(() => msgs.add({'role': 'assistant', 'content': s.t('failed')})); }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: SegmentedButton<String>(
        segments: [ButtonSegment(value: 'train', label: Text(s.t('mode_train'))), ButtonSegment(value: 'nutri', label: Text(s.t('mode_nutri'))), ButtonSegment(value: 'data', label: Text(s.t('mode_data')))],
        selected: {mode}, onSelectionChanged: (v) => setState(() => mode = v.first))),
      Expanded(child: ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [
        if (msgs.isEmpty) Text(s.t('ask_hint'), style: const TextStyle(color: muted)),
        for (final m in msgs) Align(alignment: m['role'] == 'user' ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: Container(margin: const EdgeInsets.symmetric(vertical: 4), padding: const EdgeInsets.all(12), constraints: const BoxConstraints(maxWidth: 320),
            decoration: BoxDecoration(color: m['role'] == 'user' ? accent.withOpacity(.2) : surface2, borderRadius: BorderRadius.circular(14)), child: SelectableText(m['content']!))),
        if (busy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator(color: accent)),
      ])),
      Padding(padding: const EdgeInsets.fromLTRB(12, 4, 12, 0), child: Text(s.t('ai_disclaimer'), style: const TextStyle(color: muted, fontSize: 10))),
      Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        Expanded(child: TextField(controller: c, onSubmitted: (_) => _send(), decoration: InputDecoration(hintText: s.t('ask_hint')))),
        IconButton(onPressed: _send, icon: const Icon(Icons.send, color: accent)),
      ])),
    ]);
  }
}
