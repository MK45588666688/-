import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'builder.dart';
import 'library.dart';
import 'tracker.dart';

String rng(dynamic a, dynamic b) => a == b ? '$a' : '$a-$b';

class TrainingPage extends StatelessWidget {
  final Store s;
  const TrainingPage(this.s, {super.key});

  Widget _tile(BuildContext c, Map<String, dynamic> p) => Card(child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        title: Text(s.progTitle(p), style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${p['days_per_week']} ${s.t('day')}${p['level'] == 'custom' ? '' : ' • ${p['level']}'}'),
        trailing: p['slug'] == s.activeSlug ? const Icon(Icons.check_circle, color: accent) : const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ProgramPage(s, p))),
      ));

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: s, builder: (_, __) => ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: FilledButton.icon(icon: const Icon(Icons.add), label: Text(s.t('new_program')),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BuilderPage(s))))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            icon: const Icon(Icons.menu_book), label: Text(s.t('library')),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LibraryPage(s))))),
        ]),
        if (s.custom.isNotEmpty) ...[
          Padding(padding: const EdgeInsets.only(top: 16, bottom: 4), child: Text(s.t('my_programs'), style: const TextStyle(color: muted))),
          for (final p in s.custom) _tile(context, p),
        ],
        if (s.programs.any((p) => p['source'] == 'official')) ...[
          Padding(padding: const EdgeInsets.only(top: 16, bottom: 4), child: Text(s.t('official'), style: const TextStyle(color: muted))),
          for (final p in s.programs.where((p) => p['source'] == 'official')) _tile(context, p),
        ],
        if (s.programs.any((p) => p['source'] != 'official')) ...[
          Padding(padding: const EdgeInsets.only(top: 16), child: Text(s.t('dev_note'), style: const TextStyle(color: muted))),
          const SizedBox(height: 4),
          for (final p in s.programs.where((p) => p['source'] != 'official')) _tile(context, p),
        ],
      ]));
}

class ProgramPage extends StatelessWidget {
  final Store s;
  final Map<String, dynamic> p;
  const ProgramPage(this.s, this.p, {super.key});
  @override
  Widget build(BuildContext context) {
    final days = (p['days'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
    final isCustom = p['level'] == 'custom';
    return Scaffold(
      appBar: AppBar(title: Text(s.progTitle(p)), actions: [
        if (isCustom) IconButton(icon: const Icon(Icons.edit), onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => BuilderPage(s, edit: p)));
          if (context.mounted) Navigator.pop(context);
        }),
        if (isCustom) IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await s.deleteCustom(p['slug']); if (context.mounted) Navigator.pop(context); }),
      ]),
      bottomNavigationBar: Padding(padding: const EdgeInsets.all(16), child: SafeArea(child: FilledButton(
        onPressed: () async { await s.activate(p['slug']); if (context.mounted) Navigator.pop(context); },
        child: Text(s.t('activate'))))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        for (final d in days) Card(child: ExpansionTile(
          shape: const Border(), title: Text(d['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${(d['exercises'] as List).length}'),
          trailing: IconButton(icon: const Icon(Icons.play_arrow, color: accent), onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => TrackerPage(s, d, p['slug'])))),
          children: [for (final x in (d['exercises'] as List)) ListTile(dense: true,
            title: Text(s.exName(x['exercise_key'])),
            trailing: Text('${rng(x['sets_min'], x['sets_max'])} × ${rng(x['reps_min'], x['reps_max'])}', style: const TextStyle(color: muted)))],
        )),
      ]),
    );
  }
}
