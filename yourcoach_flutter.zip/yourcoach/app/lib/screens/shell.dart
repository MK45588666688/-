import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import 'home.dart';
import 'training.dart';
import 'nutrition.dart';
import 'progress.dart';
import 'profile.dart';

class Shell extends StatefulWidget {
  final Store s;
  const Shell(this.s, {super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final pages = [HomePage(s, goTo: (n) => setState(() => i = n)), TrainingPage(s), NutritionPage(s), ProgressPage(s), ProfilePage(s)];
    final items = <List<Object>>[
      [Icons.home_rounded, s.t('home')],
      [Icons.fitness_center_rounded, s.t('training')],
      [Icons.restaurant_rounded, s.t('nutrition')],
      [Icons.insights_rounded, s.t('progress')],
      [Icons.person_rounded, s.t('profile')],
    ];
    return Scaffold(
      body: SafeArea(bottom: false, child: IndexedStack(index: i, children: pages)),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: surface2, borderRadius: BorderRadius.circular(32), border: Border.all(color: line),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(.55), blurRadius: 24, offset: const Offset(0, 8))],
          ),
          child: Row(children: [
            for (var n = 0; n < items.length; n++)
              Expanded(
                flex: n == i ? 3 : 1,
                child: _NavItem(items[n][0] as IconData, items[n][1] as String, n == i, () => setState(() => i = n)),
              ),
          ]),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavItem(this.icon, this.label, this.selected, this.onTap);
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
          height: 52,
          decoration: BoxDecoration(color: selected ? accent : Colors.transparent, borderRadius: BorderRadius.circular(26)),
          child: Center(
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, size: 24, color: selected ? const Color(0xFF0B0B0C) : muted),
              if (selected) ...[
                const SizedBox(width: 6),
                Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF0B0B0C), fontWeight: FontWeight.w800, fontSize: 13))),
              ],
            ]),
          ),
        ),
      );
}
