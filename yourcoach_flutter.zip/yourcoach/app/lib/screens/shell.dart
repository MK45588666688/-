import 'package:flutter/material.dart';
import '../store.dart';
import 'home.dart';
import 'training.dart';
import 'nutrition.dart';
import 'progress.dart';
import 'profile.dart';

class Shell extends StatefulWidget {
  final Store s;
  const Shell(this.s, {super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final pages = [HomePage(s, goTo: (n) => setState(() => i = n)), TrainingPage(s), NutritionPage(s), ProgressPage(s), ProfilePage(s)];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: i, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (n) => setState(() => i = n),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: s.t('home')),
          NavigationDestination(icon: const Icon(Icons.fitness_center_outlined), selectedIcon: const Icon(Icons.fitness_center), label: s.t('training')),
          NavigationDestination(icon: const Icon(Icons.restaurant_outlined), selectedIcon: const Icon(Icons.restaurant), label: s.t('nutrition')),
          NavigationDestination(icon: const Icon(Icons.show_chart), selectedIcon: const Icon(Icons.show_chart), label: s.t('progress')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: s.t('profile')),
        ],
      ),
    );
  }
}
