import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'cloud.dart';

typedef M = Map<String, dynamic>;
List<M> _lm(dynamic l) => (l as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

const _tr = <String, List<String>>{ // [ar, en]
  'home': ['الرئيسية', 'Home'], 'training': ['التمرين', 'Training'], 'nutrition': ['التغذية', 'Nutrition'],
  'progress': ['التقدم', 'Progress'], 'profile': ['حسابي', 'Profile'],
  'today_workout': ['تمرين اليوم', "Today's workout"], 'rest_day': ['يوم راحة', 'Rest day'],
  'start': ['ابدأ التمرين', 'Start workout'], 'no_program': ['اختار برنامج من تبويب التمرين', 'Pick a program in Training'],
  'programs': ['البرامج', 'Programs'], 'activate': ['تفعيل البرنامج', 'Set as active'], 'active': ['البرنامج النشط', 'Active program'],
  'sets': ['مجموعات', 'sets'], 'reps': ['عدّات', 'reps'], 'kg': ['كجم', 'kg'], 'rep': ['عدّة', 'reps'],
  'warmup': ['إحماء', 'W.U'], 'set': ['مجموعة', 'Set'], 'last': ['آخر مرة', 'Last'], 'finish': ['إنهاء التمرين', 'Finish'],
  'rest': ['راحة', 'Rest'], 'skip': ['تخطي', 'Skip'], 'calories': ['السعرات', 'Calories'],
  'protein': ['بروتين', 'Protein'], 'carbs': ['كارب', 'Carbs'], 'fat': ['دهون', 'Fat'],
  'water': ['الماء', 'Water'], 'breakfast': ['فطار', 'Breakfast'], 'lunch': ['غدا', 'Lunch'],
  'dinner': ['عشا', 'Dinner'], 'snack': ['سناكس', 'Snacks'], 'add_food': ['إضافة أكل', 'Add food'],
  'search_food': ['ابحث عن أكل...', 'Search food...'], 'grams': ['جرام', 'grams'], 'add': ['إضافة', 'Add'],
  'estimate': ['قيم تقريبية', 'Approx. values'], 'weight': ['الوزن', 'Weight'], 'save': ['حفظ', 'Save'],
  'week_workouts': ['تمارين الأسبوع', 'Workouts this week'], 'language': ['اللغة', 'Language'],
  'reset': ['مسح كل البيانات', 'Erase all data'], 'confirm': ['تأكيد', 'Confirm'], 'cancel': ['إلغاء', 'Cancel'],
  'history': ['السجل', 'History'], 'no_data': ['لا توجد بيانات بعد', 'No data yet'], 'day': ['يوم', 'Day'],
  'meal': ['الوجبة', 'Meal'], 'dev_note': ['برامج تجريبية للتطوير', 'Dev sample programs'],
  'new_program': ['برنامج جديد', 'New program'], 'library': ['مكتبة التمارين', 'Exercise library'],
  'prog_name': ['اسم البرنامج', 'Program name'], 'add_day': ['إضافة يوم', 'Add day'], 'add_rest': ['يوم راحة', 'Rest day'],
  'add_ex': ['إضافة تمرين', 'Add exercise'], 'dup': ['نسخ', 'Duplicate'], 'delete': ['حذف', 'Delete'],
  'edit': ['تعديل', 'Edit'], 'rest_s': ['راحة (ثانية)', 'Rest (sec)'], 'rir': ['RIR', 'RIR'],
  'all': ['الكل', 'All'], 'custom_ex': ['تمرين مخصص', 'Custom exercise'], 'ex_name': ['اسم التمرين', 'Exercise name'],
  'equipment': ['الأداة', 'Equipment'], 'alternatives': ['بدائل', 'Alternatives'], 'no_video': ['لا يوجد فيديو توضيحي بعد', 'No demo video yet'],
  'best': ['أفضل أداء (1RM تقديري)', 'Best (est. 1RM)'], 'records': ['الأرقام القياسية', 'Personal records'],
  'my_programs': ['برامجي', 'My programs'], 'official': ['برامج جاهزة', 'Ready programs'], 'name_taken': ['اسم اليوم مكرر', 'Duplicate day name'],
  'plans': ['خطط التغذية', 'Nutrition plans'], 'calc': ['حاسبة السعرات', 'Calorie calculator'], 'recipes': ['الوصفات', 'Recipes'],
  'report': ['التقرير الأسبوعي', 'Weekly report'], 'age': ['السن', 'Age'], 'height': ['الطول (سم)', 'Height (cm)'],
  'male': ['ذكر', 'Male'], 'female': ['أنثى', 'Female'], 'sedentary': ['قليل الحركة', 'Sedentary'], 'light': ['نشاط خفيف', 'Light'],
  'moderate': ['نشاط متوسط', 'Moderate'], 'high': ['نشاط عالي', 'High'], 'g_maintain': ['تثبيت الوزن', 'Maintain'],
  'g_lose': ['تنشيف', 'Fat loss'], 'g_gain': ['بناء عضل', 'Muscle gain'], 'g_general': ['تغذية عامة', 'General'],
  'compute': ['احسب', 'Calculate'], 'plan_name': ['اسم الخطة', 'Plan name'], 'save_plan': ['حفظ الخطة', 'Save plan'],
  'minor_note': ['تحت 18 سنة: لا نحدد عجز أو زيادة في السعرات. الهدف تغذية متوازنة وكافية، ويفضّل متابعة مختص.',
    'Under 18: no calorie deficit/surplus is set. Aim for balanced, adequate nutrition; consult a professional.'],
  'assump': ['تقدير تقريبي بمعادلة Mifflin-St Jeor × معامل النشاط. عدّله حسب استجابة جسمك. ليس نصيحة طبية.',
    'Estimate: Mifflin-St Jeor × activity factor. Adjust to your response. Not medical advice.'],
  'bmr': ['معدل الأيض الأساسي', 'BMR'], 'tdee': ['إجمالي الحرق اليومي', 'TDEE'], 'adj': ['العجز/الزيادة (سعرة)', 'Deficit/surplus (kcal)'],
  'prot_kg': ['بروتين جم/كجم', 'Protein g/kg'], 'fat_pct': ['دهون % من السعرات', 'Fat % of kcal'],
  'servings': ['عدد الحصص', 'Servings'], 'ingredient': ['إضافة مكوّن', 'Add ingredient'], 'per_serving': ['للحصة', 'Per serving'],
  'total': ['الإجمالي', 'Total'], 'log': ['سجّل', 'Log'], 'custom_food': ['أكل مخصص', 'Custom food'], 'per100': ['لكل 100 جم', 'per 100 g'],
  'copy_yday': ['نسخ وجبات أمس', "Copy yesterday's meals"], 'avg_logged': ['متوسط الأيام المسجلة', 'Average (logged days)'],
  'logged_days': ['أيام التسجيل', 'Days logged'], 'target': ['الهدف', 'Target'], 'name': ['الاسم', 'Name'],
  'welcome': ['أهلاً بيك في YOUR COACH', 'Welcome to YOUR COACH'], 'next': ['التالي', 'Next'], 'back': ['رجوع', 'Back'],
  'ob_basic': ['بياناتك الأساسية', 'Basics'], 'ob_train': ['تدريبك', 'Training'], 'ob_final': ['اللمسات الأخيرة', 'Final touches'],
  'experience': ['مستواك', 'Experience'], 'beginner': ['مبتدئ', 'Beginner'], 'intermediate': ['متوسط', 'Intermediate'], 'advanced': ['متقدم', 'Advanced'],
  'interests': ['اهتماماتك', 'Interests'], 'i_bb': ['بناء أجسام', 'Bodybuilding'], 'i_pl': ['باوربيلدنج/قوة', 'Powerlifting'],
  'i_st': ['قوة', 'Strength'], 'i_gf': ['لياقة عامة', 'General fitness'], 'i_ca': ['كارديو', 'Cardio'], 'i_hl': ['أسلوب حياة صحي', 'Healthy lifestyle'],
  'days_week': ['أيام التمرين في الأسبوع', 'Training days / week'], 'equipment_q': ['الأدوات المتاحة', 'Available equipment'],
  'e_machine': ['ماكينات', 'Machines'], 'e_dumbbell': ['دمبل', 'Dumbbells'], 'e_barbell': ['بار', 'Barbell'], 'e_cable': ['كابلات', 'Cables'],
  'e_bodyweight': ['وزن الجسم', 'Bodyweight'], 'activity_q': ['نشاطك اليومي', 'Daily activity'], 'units': ['وحدات القياس', 'Units'],
  'metric': ['متري (كجم/سم)', 'Metric'], 'imperial': ['إمبراطوري', 'Imperial'], 'consent': ['أوافق على حفظ بياناتي على جهازي، وعلى النسخ الاحتياطي لو فعّلته.',
    'I agree to store my data on my device and in backup if I enable it.'], 'start_app': ['ابدأ', 'Start'],
  'account': ['الحساب والنسخ الاحتياطي', 'Account & backup'], 'email': ['الإيميل', 'Email'], 'password': ['كلمة السر', 'Password'],
  'signin': ['تسجيل دخول', 'Sign in'], 'signup': ['إنشاء حساب', 'Sign up'], 'signout': ['تسجيل خروج', 'Sign out'],
  'backup_now': ['نسخ احتياطي الآن', 'Back up now'], 'restore': ['استرجاع من السحابة', 'Restore from cloud'], 'autosync': ['نسخ احتياطي تلقائي', 'Auto backup'],
  'cloud_off': ['الربط السحابي غير مفعّل. شغّل التطبيق مع SUPABASE_URL و SUPABASE_ANON_KEY.', 'Cloud not configured. Run with SUPABASE_URL and SUPABASE_ANON_KEY.'],
  'export': ['نسخ بياناتي (JSON)', 'Copy my data (JSON)'], 'copied': ['تم النسخ', 'Copied'], 'done': ['تم', 'Done'], 'failed': ['فشلت العملية', 'Failed'],
  'customize_home': ['تخصيص الرئيسية', 'Customize home'], 'w_workout': ['تمرين اليوم', "Today's workout"], 'w_nutrition': ['التغذية', 'Nutrition'],
  'w_activity': ['الماء والأسبوع', 'Water & week'], 'edit_profile': ['تعديل بياناتي', 'Edit profile'], 'name_q': ['اسمك', 'Your name'],
  'weekly_vol': ['مجموعات هذا الأسبوع', 'Sets this week'],
  'planner': ['مخطط الوجبات', 'Meal planner'], 'shopping': ['قائمة التسوق', 'Shopping list'], 'log_day_plan': ['سجّل خطة اليوم في اليومية', "Log this day's plan"],
  'plan_empty': ['مفيش وجبات متخططة في اليوم ده', 'Nothing planned for this day'], 'goals': ['الأهداف والإنجازات', 'Goals & achievements'],
  'new_goal': ['هدف جديد', 'New goal'], 'goal_title': ['الهدف', 'Goal'], 'goal_target': ['القيمة المستهدفة', 'Target value'], 'goal_unit': ['الوحدة', 'Unit'],
  'goal_current': ['القيمة الحالية', 'Current value'], 'achievements': ['الإنجازات', 'Achievements'], 'a_first': ['أول تمرين', 'First workout'],
  'a_10': ['10 تمارين', '10 workouts'], 'a_20': ['20 تمرين', '20 workouts'], 'a_pr': ['أول رقم قياسي', 'First personal record'],
  'a_streak': ['3 أسابيع متتالية فيها تمرين مرتين على الأقل', '3 straight weeks with 2+ workouts'], 'a_week': ['حققت عدد تمارين الأسبوع المستهدف', 'Hit this week\'s workout target'],
  'ai': ['المساعد الذكي', 'AI assistant'], 'ai_meal': ['تحليل وجبة', 'Meal analyzer'], 'ai_chat': ['اسأل', 'Ask'], 'ai_off': ['ضيف مفتاح الـ API بتاعك من أيقونة المفتاح فوق عشان المساعد يشتغل.', 'Add your API key (key icon above) to enable the assistant.'],
  'saved': ['محفوظ', 'saved'], 'api_key': ['مفتاح API (Anthropic)', 'API key (Anthropic)'], 'api_model': ['اسم النموذج', 'Model name'], 'clear_key': ['مسح المفتاح', 'Remove key'],
  'key_note': ['المفتاح بيتخزن في مخزن الجهاز الآمن بس، ومش بيدخل في النسخ الاحتياطي أو التصدير. الطلبات بتتحسب على حسابك.', 'The key is kept in the device secure storage only; never in backups/exports. Requests are billed to your account.'],
  'ai_estimate': ['تقدير بالذكاء الاصطناعي — مش قيم دقيقة', 'AI estimate — not exact values'], 'describe_meal': ['اوصف وجبتك (مثال: 200 جم رز و150 جم فراخ)', 'Describe your meal (e.g. 200 g rice, 150 g chicken)'],
  'analyze': ['حلّل', 'Analyze'], 'confirm_log': ['تأكيد وإضافة لليومية', 'Confirm & add to diary'], 'ask_hint': ['اسأل عن تمرينك أو أكلك أو بياناتك المسجلة', 'Ask about training, food, or your logged data'],
  'mode_train': ['تمرين', 'Training'], 'mode_nutri': ['تغذية', 'Nutrition'], 'mode_data': ['بياناتي', 'My data'], 'send': ['إرسال', 'Send'],
  'ai_disclaimer': ['معلومات عامة وليست نصيحة طبية. لو عندك إصابة أو حالة صحية اسأل مختص.', 'General info, not medical advice. For injuries or health conditions ask a professional.'],
  'barcode': ['باركود', 'Barcode'], 'barcode_hint': ['اكتب أو امسح الباركود', 'Type or scan barcode'], 'lookup': ['بحث', 'Look up'], 'not_found': ['مش موجود', 'Not found'],
  'sync_content': ['تحديث المحتوى الرسمي', 'Refresh official content'], 'articles': ['المركز التعليمي', 'Education center'],
  'steps': ['الخطوات', 'Steps'], 'health_sync': ['مزامنة الصحة', 'Health sync'], 'connect': ['ربط', 'Connect'], 'health_note': ['قيم الساعة تقريبية. بنقرأ الخطوات بس حاليًا، ومفيش سعرات بتتضاف تلقائيًا للتغذية.', 'Wearable values are approximate. Only steps are read for now; nothing is auto-added to nutrition.'],
  'cardio': ['الكارديو', 'Cardio'], 'habits': ['العادات', 'Habits'], 'calendar': ['التقويم', 'Calendar'],
  'c_walking': ['مشي', 'Walking'], 'c_running': ['جري', 'Running'], 'c_treadmill': ['سير', 'Treadmill'], 'c_cycling': ['عجلة', 'Cycling'],
  'c_bike': ['عجلة ثابتة', 'Stationary bike'], 'c_elliptical': ['إليبتيكال', 'Elliptical'], 'c_stairs': ['ستيرماستر', 'StairMaster'],
  'minutes': ['دقائق', 'Minutes'], 'distance': ['المسافة (كم)', 'Distance (km)'], 'speed': ['السرعة', 'Speed'], 'avg_hr': ['متوسط النبض', 'Avg HR'],
  'notes': ['ملاحظات', 'Notes'], 'optional': ['اختياري', 'optional'], 'week_total': ['إجمالي الأسبوع', 'Week total'], 'min': ['د', 'min'],
  'add_cardio': ['تسجيل كارديو', 'Log cardio'], 'cardio_note': ['القيم مدخلة يدويًا. مزامنة الساعة وHealth Connect/HealthKit لسه مش متوصلة.',
    'Manual entries. Watch / Health Connect / HealthKit sync is not connected yet.'],
  'new_habit': ['عادة جديدة', 'New habit'], 'habit_name': ['اسم العادة', 'Habit name'], 'streak': ['أيام متتالية', 'day streak'],
  'week_rate': ['إنجاز آخر 7 أيام', 'Last 7 days'], 'sleep': ['النوم', 'Sleep'], 'bedtime': ['وقت النوم', 'Bedtime'], 'waketime': ['وقت الاستيقاظ', 'Wake-up'],
  'log_sleep': ['سجّل نوم الليلة اللي فاتت', "Log last night's sleep"], 'suggest': ['اقتراحات', 'Suggestions'], 'no_habits': ['مفيش عادات. ضيف اللي يناسبك.', 'No habits yet. Add what suits you.'],
  'h_water': ['شرب 2 لتر مياه', 'Drink 2 L water'], 'h_steps': ['مشي 8000 خطوة', 'Walk 8000 steps'], 'h_sleep': ['نوم 7 ساعات', 'Sleep 7 hours'], 'h_stretch': ['إطالة 10 دقايق', 'Stretch 10 min'],
  'month': ['شهر', 'Month'], 'week': ['أسبوع', 'Week'], 'add_event': ['إضافة حدث', 'Add event'], 'event_title': ['عنوان الحدث', 'Event title'],
  'workout_done': ['تمرين', 'Workout'], 'food_logged': ['تسجيل أكل', 'Food logged'], 'habits_done': ['عادات منجزة', 'Habits done'], 'events': ['أحداث', 'Events'],
  'cal_note': ['التقويم بيعرض اللي اتسجل فعلاً. جدولة التمارين المستقبلية على تواريخ لسه مش متاحة.', 'Shows what you actually logged. Date-based workout scheduling is not available yet.'],
};

class Store extends ChangeNotifier {
  String lang = 'ar';
  List<M> programs = [], foods = [], sessions = [], meals = [], weights = [], custom = [], customEx = [], plans = [], recipes = [], customFoods = [], cardio = [], habits = [], sleeps = [], events = [], planItems = [], goals = [];
  Set<String> shopChecked = {};
  Map<String, List<String>> habitLog = {};
  M profile = {}; String? activePlanId;
  Map<String, M> ex = {};
  String? activeSlug; int cycleIdx = 0; Map<String, int> water = {};
  File? _f, _rf;
  List<M> _seedP = [], _seedF = []; Map<String, M> _seedE = {}; M remote = {}; Map<String, int> steps = {};

  String t(String k) => (_tr[k] ?? [k, k])[lang == 'ar' ? 0 : 1];
  bool get rtl => lang == 'ar';
  String exName(String key) => (ex[key]?[lang == 'ar' ? 'name_ar' : 'name_en'] ?? key) as String;
  String progTitle(M p) => (p[lang == 'ar' ? 'title_ar' : 'title_en'] ?? p['title_en']) as String;
  String foodName(M f) => (f[lang == 'ar' ? 'ar' : 'en']) as String;
  static String dayKey([DateTime? d]) { d ??= DateTime.now(); return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}'; }

  Future<void> load() async {
    final seed = jsonDecode(await rootBundle.loadString('assets/dev_programs.seed.json'));
    programs = _lm(seed['programs']);
    ex = {for (final e in _lm(seed['exercises'])) e['key'] as String: e};
    foods = _lm(jsonDecode(await rootBundle.loadString('assets/foods.seed.json')));
    _seedP = programs; _seedE = Map.of(ex); _seedF = foods;
    final dir = await getApplicationDocumentsDirectory();
    _f = File('${dir.path}/yourcoach.json');
    _rf = File('${dir.path}/yourcoach_content.json');
    if (await _rf!.exists()) { try { remote = Map<String, dynamic>.from(jsonDecode(await _rf!.readAsString()) as Map); _applyRemote(); } catch (_) {} }
    if (await _f!.exists()) {
      try { applyJson(jsonDecode(await _f!.readAsString()) as Map); } catch (_) {/* corrupted file: start clean */}
    }
  }
  /// Everything the user owns (no seed content). Used for local file, cloud backup and export.
  M toJson() => {'v': 1, 'lang': lang, 'active': activeSlug, 'cycle': cycleIdx, 'plans': plans, 'recipes': recipes,
    'customFoods': customFoods, 'profile': profile, 'activePlan': activePlanId, 'custom': custom, 'customEx': customEx,
    'sessions': sessions, 'meals': meals, 'weights': weights, 'water': water,
    'cardio': cardio, 'habits': habits, 'sleeps': sleeps, 'events': events, 'habitLog': habitLog, 'planItems': planItems, 'goals': goals, 'shopChecked': shopChecked.toList(), 'steps': steps};
  void applyJson(Map d) {
    lang = d['lang'] ?? 'ar'; activeSlug = d['active']; cycleIdx = d['cycle'] ?? 0;
    sessions = _lm(d['sessions'] ?? []); custom = _lm(d['custom'] ?? []); customEx = _lm(d['customEx'] ?? []);
    for (final e in customEx) { ex[e['key']] = e; }
    plans = _lm(d['plans'] ?? []); recipes = _lm(d['recipes'] ?? []); customFoods = _lm(d['customFoods'] ?? []);
    profile = Map<String, dynamic>.from(d['profile'] ?? {}); activePlanId = d['activePlan']; meals = _lm(d['meals'] ?? []);
    weights = _lm(d['weights'] ?? []); water = Map<String, int>.from(d['water'] ?? {});
    cardio = _lm(d['cardio'] ?? []); habits = _lm(d['habits'] ?? []); sleeps = _lm(d['sleeps'] ?? []); events = _lm(d['events'] ?? []);
    steps = Map<String, int>.from(d['steps'] ?? {});
    planItems = _lm(d['planItems'] ?? []); goals = _lm(d['goals'] ?? []); shopChecked = Set<String>.from(d['shopChecked'] ?? []);
    habitLog = {for (final e in ((d['habitLog'] ?? {}) as Map).entries) e.key as String: List<String>.from(e.value as List)};
  }
  /// Set by main.dart: called after every local save (cloud auto-backup hook).
  Future<void> Function(M)? onSaved;
  Future<void> restoreFrom(Map d) { applyJson(d); return _save(); }
  Future<void> _save() async {
    notifyListeners();
    final j = toJson();
    await _f?.writeAsString(jsonEncode(j));
    onSaved?.call(j);
  }

  List<M> get articles => _lm(remote['articles'] ?? []);
  void _applyRemote() {
    programs = [..._seedP, ..._lm(remote['programs'] ?? [])];
    ex = {..._seedE, for (final e in _lm(remote['exercises'] ?? [])) e['key'] as String: e};
    foods = [..._seedF, ..._lm(remote['foods'] ?? [])];
    for (final e in customEx) { ex[e['key']] = e; }
  }
  /// Pulls published official content (programs, exercises, foods, articles) from the backend. Offline/failed => keeps cache.
  Future<bool> syncContent() async {
    if (!Cloud.enabled) return false;
    try { remote = await Cloud.fetchContent(); await _rf?.writeAsString(jsonEncode(remote)); _applyRemote(); notifyListeners(); return true; } catch (_) { return false; }
  }
  Future<void> setSteps(String day, int n) { steps[day] = n; return _save(); }
  List<M> get allPrograms => [...programs, ...custom];
  M? get activeProgram => allPrograms.where((p) => p['slug'] == activeSlug).firstOrNull;
  List<String> cycleOf(M p) => (p['cycle'] as List).cast<String>();
  /// Today's planned day, or null on rest day / no program.
  M? get todayDay {
    final p = activeProgram; if (p == null) return null;
    final c = cycleOf(p); final name = c[cycleIdx % c.length];
    return _lm(p['days']).where((d) => d['name'] == name).firstOrNull;
  }
  bool get isRestToday => activeProgram != null && todayDay == null;

  Future<void> saveCustom(M p) { final i = custom.indexWhere((x) => x['slug'] == p['slug']);
    i >= 0 ? custom[i] = p : custom.add(p); return _save(); }
  Future<void> deleteCustom(String slug) { custom.removeWhere((x) => x['slug'] == slug);
    if (activeSlug == slug) { activeSlug = null; cycleIdx = 0; } return _save(); }
  Future<String> addCustomExercise(String name, String muscle) async {
    final key = 'custom_${DateTime.now().millisecondsSinceEpoch}';
    final e = {'key': key, 'name_ar': name, 'name_en': name, 'muscle': muscle, 'equipment': 'custom', 'video_url': null, 'status': 'user'};
    customEx.add(e); ex[key] = e; await _save(); return key; }
  static const muscleAr = {'chest': 'صدر', 'back': 'ظهر', 'shoulders': 'أكتاف', 'biceps': 'باي', 'triceps': 'تراي',
    'forearms': 'ساعد', 'quadriceps': 'فخذ أمامي', 'hamstrings': 'فخذ خلفي', 'glutes': 'مؤخرة', 'calves': 'سمانة',
    'abs': 'بطن', 'adductors': 'مقربات'};
  String muscleName(String m) => lang == 'ar' ? (muscleAr[m] ?? m) : (m[0].toUpperCase() + m.substring(1));
  /// Best estimated 1RM (Epley) per exercise from logged working sets.
  Map<String, M> prs() { final r = <String, M>{};
    for (final s in sessions) { for (final x in _lm(s['sets'])) {
      if (x['warm'] == true) continue; final kg = (x['kg'] as num).toDouble(), reps = (x['reps'] as num).toInt();
      if (kg <= 0 || reps <= 0) continue; final e1 = kg * (1 + reps / 30);
      final cur = r[x['key']]; if (cur == null || e1 > (cur['e1rm'] as double)) r[x['key']] = {'kg': kg, 'reps': reps, 'e1rm': e1, 'at': s['at']};
    } } return r; }
  Map<String, int> weekMuscleSets() { final from = DateTime.now().subtract(const Duration(days: 7)); final r = <String, int>{};
    for (final s in sessions.where((s) => DateTime.parse(s['at']).isAfter(from))) { for (final x in _lm(s['sets'])) {
      if (x['warm'] == true) continue; final m = ex[x['key']]?['muscle'] as String? ?? 'other'; r[m] = (r[m] ?? 0) + 1; } }
    return r; }
  List<M> get allFoods => [...customFoods, ...foods];
  M? get activePlan => plans.where((p) => p['id'] == activePlanId).firstOrNull;
  Future<void> saveProfile(M p) { profile = p; return _save(); }
  Future<void> savePlan(M p) { final i = plans.indexWhere((x) => x['id'] == p['id']); i >= 0 ? plans[i] = p : plans.add(p);
    activePlanId ??= p['id']; return _save(); }
  Future<void> deletePlan(String id) { plans.removeWhere((p) => p['id'] == id); if (activePlanId == id) activePlanId = plans.firstOrNull?['id']; return _save(); }
  Future<void> activatePlan(String id) { activePlanId = id; return _save(); }
  Future<void> saveRecipe(M r) { final i = recipes.indexWhere((x) => x['id'] == r['id']); i >= 0 ? recipes[i] = r : recipes.add(r); return _save(); }
  Future<void> deleteRecipe(String id) { recipes.removeWhere((r) => r['id'] == id); return _save(); }
  Future<void> addCustomFood(M f) { customFoods.add(f); return _save(); }
  static Map<String, double> recipeTotals(M r) { final t = {'k': 0.0, 'p': 0.0, 'c': 0.0, 'f': 0.0, 'g': 0.0};
    for (final i in (r['items'] as List)) { final f = i['food'] as Map; final x = (i['g'] as num) / 100;
      t['k'] = t['k']! + f['k'] * x; t['p'] = t['p']! + f['p'] * x; t['c'] = t['c']! + f['c'] * x; t['f'] = t['f']! + f['f'] * x; t['g'] = t['g']! + (i['g'] as num); }
    return t; }
  Future<void> addRaw(String label, double k, double p, double c, double f, double g, String type, {String source = 'estimate'}) {
    meals.add({'id': DateTime.now().microsecondsSinceEpoch.toString(), 'day': dayKey(), 'type': type, 'label': label, 'label_en': label,
      'g': g, 'k': k, 'p': p, 'c': c, 'f': f, 'source': source}); return _save(); }
  Future<void> copyYesterday() { final y = dayKey(DateTime.now().subtract(const Duration(days: 1)));
    var n = 0; for (final m in mealsOn(y)) { meals.add({...m, 'id': '${DateTime.now().microsecondsSinceEpoch}${n++}', 'day': dayKey()}); }
    return _save(); }
  Future<void> setLang(String l) { lang = l; return _save(); }
  Future<void> activate(String slug) { activeSlug = slug; cycleIdx = 0; return _save(); }
  Future<void> advanceCycle() { cycleIdx++; return _save(); }

  Future<void> addSession(M s) async { sessions.add(s); final p = activeProgram;
    if (p != null && s['slug'] == activeSlug) cycleIdx++; await _save(); }
  /// Previous working sets of an exercise, formatted "60×10, 60×9".
  String? lastFor(String key) {
    for (final s in sessions.reversed) {
      final sets = _lm(s['sets']).where((x) => x['key'] == key && x['warm'] != true).toList();
      if (sets.isNotEmpty) return sets.map((x) => '${_n(x['kg'])}×${x['reps']}').join('  ');
    }
    return null;
  }
  static String _n(dynamic v) => v is num && v == v.roundToDouble() ? '${v.toInt()}' : '$v';
  int get weekSessions { final from = DateTime.now().subtract(const Duration(days: 7));
    return sessions.where((s) => DateTime.parse(s['at']).isAfter(from)).length; }
  int get weekSets { final from = DateTime.now().subtract(const Duration(days: 7));
    return sessions.where((s) => DateTime.parse(s['at']).isAfter(from))
      .fold(0, (a, s) => a + _lm(s['sets']).where((x) => x['warm'] != true).length); }

  // Nutrition
  List<M> mealsOn(String day) => meals.where((m) => m['day'] == day).toList();
  Map<String, double> totals(String day) { final r = {'k': 0.0, 'p': 0.0, 'c': 0.0, 'f': 0.0};
    for (final m in mealsOn(day)) { for (final k in r.keys) { r[k] = r[k]! + (m[k] as num); } } return r; }
  Future<void> addMeal(M food, double grams, String type) { final x = grams / 100;
    meals.add({'id': DateTime.now().microsecondsSinceEpoch.toString(), 'day': dayKey(), 'type': type,
      'food': food['id'], 'label': food['ar'], 'label_en': food['en'], 'g': grams,
      'k': food['k'] * x, 'p': food['p'] * x, 'c': food['c'] * x, 'f': food['f'] * x, 'source': 'estimate'});
    return _save(); }
  Future<void> removeMeal(String id) { meals.removeWhere((m) => m['id'] == id); return _save(); }
  int waterToday() => water[dayKey()] ?? 0;
  Future<void> addWater(int ml) { water[dayKey()] = (waterToday() + ml).clamp(0, 20000); return _save(); }
  Future<void> addWeight(double kg) { weights.add({'day': dayKey(), 'kg': kg}); return _save(); }
  Future<void> wipe() { sessions = []; meals = []; weights = []; water = {}; custom = []; customEx = []; plans = []; recipes = []; customFoods = []; cardio = []; habits = []; sleeps = []; events = []; habitLog = {}; planItems = []; steps = {}; goals = []; shopChecked = {}; profile = {}; activePlanId = null; activeSlug = null; cycleIdx = 0; return _save(); }

  // ---- Cardio (manual entries; no wearable sync yet) ----
  static const cardioTypes = ['walking', 'running', 'treadmill', 'cycling', 'bike', 'elliptical', 'stairs'];
  Future<void> addCardio(String type, double mins, {double? km, int? hr, String? note}) {
    final now = DateTime.now();
    cardio.add({'id': now.microsecondsSinceEpoch.toString(), 'day': dayKey(now), 'at': now.toIso8601String(), 'type': type,
      'mins': mins, 'km': km, 'hr': hr, 'note': note});
    return _save(); }
  Future<void> removeCardio(String id) { cardio.removeWhere((c) => c['id'] == id); return _save(); }
  double cardioMinsOn(String day) => cardio.where((c) => c['day'] == day).fold(0.0, (a, c) => a + (c['mins'] as num));

  // ---- Habits (user-defined; nothing is forced) ----
  Future<void> addHabit(String name) { habits.add({'id': DateTime.now().microsecondsSinceEpoch.toString(), 'name': name}); return _save(); }
  Future<void> removeHabit(String id) { habits.removeWhere((h) => h['id'] == id); for (final l in habitLog.values) { l.remove(id); } return _save(); }
  bool habitDone(String id, String day) => habitLog[day]?.contains(id) ?? false;
  Future<void> toggleHabit(String id, [String? day]) { day ??= dayKey(); final l = habitLog.putIfAbsent(day, () => []);
    l.contains(id) ? l.remove(id) : l.add(id); if (l.isEmpty) habitLog.remove(day); return _save(); }
  /// Consecutive done days ending today (or yesterday, so an unfinished today doesn't zero the streak).
  int streak(String id) { var d = DateTime.now(); if (!habitDone(id, dayKey(d))) d = d.subtract(const Duration(days: 1));
    var n = 0; while (habitDone(id, dayKey(d))) { n++; d = d.subtract(const Duration(days: 1)); } return n; }
  /// Done / possible over the last 7 days (0..1).
  double habitWeekRate() { if (habits.isEmpty) return 0; var done = 0;
    for (var i = 0; i < 7; i++) { final d = dayKey(DateTime.now().subtract(Duration(days: i))); done += habits.where((h) => habitDone(h['id'], d)).length; }
    return done / (habits.length * 7); }
  Future<void> addSleep(String bed, String wake) { final day = dayKey(); sleeps.removeWhere((x) => x['day'] == day);
    sleeps.add({'day': day, 'bed': bed, 'wake': wake, 'mins': sleepMins(bed, wake)}); return _save(); }
  static int sleepMins(String bed, String wake) { int m(String t) { final p = t.split(':'); return int.parse(p[0]) * 60 + int.parse(p[1]); }
    final d = m(wake) - m(bed); return d <= 0 ? d + 1440 : d; }

  // ---- Calendar ----
  Future<void> addEvent(String day, String title) { events.add({'id': DateTime.now().microsecondsSinceEpoch.toString(), 'day': day, 'title': title}); return _save(); }
  Future<void> removeEvent(String id) { events.removeWhere((e) => e['id'] == id); return _save(); }
  /// What was actually logged on a day (used for calendar dots and the day detail).
  Map<String, int> activityOn(String day) => {
    'workout': sessions.where((x) => (x['at'] as String).startsWith(day)).length,
    'cardio': cardio.where((c) => c['day'] == day).length,
    'food': mealsOn(day).length,
    'habits': habitLog[day]?.length ?? 0,
    'events': events.where((e) => e['day'] == day).length,
  };

  // ---- Meal planner / shopping list ----
  /// dow = DateTime.weekday (1=Mon..7=Sun).
  Future<void> addPlanItem(int dow, String type, M food, double g) {
    planItems.add({'id': DateTime.now().microsecondsSinceEpoch.toString(), 'dow': dow, 'type': type, 'food': food['id'], 'ar': food['ar'], 'en': food['en'], 'g': g});
    return _save(); }
  Future<void> removePlanItem(String id) { planItems.removeWhere((x) => x['id'] == id); return _save(); }
  List<M> planOn(int dow) => planItems.where((x) => x['dow'] == dow).toList();
  /// Adds the planned items of a weekday to today's diary (values come from the food database, still estimates).
  Future<void> logPlanDay(int dow) async {
    for (final it in planOn(dow)) {
      final f = allFoods.where((x) => x['id'] == it['food']).firstOrNull; if (f == null) continue;
      final x = (it['g'] as num) / 100;
      meals.add({'id': '${DateTime.now().microsecondsSinceEpoch}${it['id']}', 'day': dayKey(), 'type': it['type'], 'food': f['id'], 'label': f['ar'], 'label_en': f['en'],
        'g': it['g'], 'k': f['k'] * x, 'p': f['p'] * x, 'c': f['c'] * x, 'f': f['f'] * x, 'source': 'estimate'}); }
    await _save(); }
  /// Total grams per food across the whole weekly plan.
  Map<String, double> shoppingTotals() { final r = <String, double>{};
    for (final it in planItems) { r['${it['food']}'] = (r['${it['food']}'] ?? 0) + (it['g'] as num); } return r; }
  Future<void> toggleShop(String id) { shopChecked.contains(id) ? shopChecked.remove(id) : shopChecked.add(id); return _save(); }

  // ---- Goals & achievements (achievements are computed from real logs, never stored) ----
  Future<void> saveGoal(M g) { final i = goals.indexWhere((x) => x['id'] == g['id']); i >= 0 ? goals[i] = g : goals.add(g); return _save(); }
  Future<void> removeGoal(String id) { goals.removeWhere((g) => g['id'] == id); return _save(); }
  Map<String, bool> achievements() {
    int inWeek(int back) { final end = DateTime.now().subtract(Duration(days: 7 * back)); final start = end.subtract(const Duration(days: 7));
      return sessions.where((x) { final d = DateTime.parse(x['at']); return d.isAfter(start) && !d.isAfter(end); }).length; }
    final target = (profile['days'] as num?)?.toInt();
    return {'a_first': sessions.isNotEmpty, 'a_10': sessions.length >= 10, 'a_20': sessions.length >= 20, 'a_pr': prs().isNotEmpty,
      'a_streak': [0, 1, 2].every((b) => inWeek(b) >= 2), 'a_week': target != null && target > 0 && weekSessions >= target}; }
}
