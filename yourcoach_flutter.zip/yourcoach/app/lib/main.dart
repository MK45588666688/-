import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'store.dart';
import 'cloud.dart';
import 'ai_client.dart';
import 'screens/onboarding.dart';
import 'theme.dart';
import 'screens/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final s = Store();
  await s.load();
  await Cloud.init();
  await AiClient.init();
  // Auto-backup (only if signed in AND the user enabled it). Offline failures are ignored; next save retries.
  s.onSaved = (j) async {
    if (Cloud.user != null && s.profile['autosync'] == true) {
      try { await Cloud.push(j); } catch (_) {}
    }
  };
  runApp(App(s));
  s.syncContent(); // fire-and-forget; keeps cached content when offline
}

class App extends StatelessWidget {
  final Store s;
  const App(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (_, __) => MaterialApp(
          title: 'YOUR COACH',
          debugShowCheckedModeBanner: false,
          theme: darkTheme(),
          locale: Locale(s.lang),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: s.profile['onboarded'] == true ? Shell(s) : OnboardingPage(s),
        ),
      );
}
