# YOUR COACH — Phase 1 (local mode)

Not yet compiled by the author (no Flutter SDK in the build sandbox) — expect to fix small compile errors on first run.

```bash
cd app
flutter create . --platforms=android,ios --project-name your_coach   # generates android/ios folders, keeps lib/
flutter pub get
flutter analyze
flutter run
```
Data is stored locally in a JSON file (no backend yet). Next step: swap `Store` persistence for Supabase using `backend/schema.sql`.

Included: 5-tab shell, RTL/Arabic-first + EN switch, dark theme, 6 dev programs, active program + cycle (incl. REST days),
gym-mode tracker (warm-up/working sets, last performance, auto rest timer), food search (25 approx. Egyptian foods, flagged as estimates),
meal log + daily totals, water, weight chart, session history.
Stage 2 adds: custom builder, exercise library+detail+alternatives, PRs (Epley est. 1RM), weekly sets per muscle.
Stage 3 adds: calorie calculator (Mifflin-St Jeor), multiple plans, minors never get deficit/surplus, recipes, custom foods, weekly report, copy yesterday.

## Stage 4 (onboarding + cloud)
Onboarding (3 steps, consent, minors notice), account (Supabase email auth), cloud snapshot backup/restore + optional auto-backup,
data export (copy JSON), customizable home widgets. Cloud is OFF unless you pass keys:
```
flutter run --dart-define=SUPABASE_URL=https://xxx.supabase.co --dart-define=SUPABASE_ANON_KEY=xxxx
```
Run `backend/schema.sql` in Supabase first (creates user_snapshots + RLS). Snapshot model = whole data as one JSON row (last write wins);
row-level sync of relational tables is planned later. Imperial units are stored but not yet applied in the UI.
Account deletion on the server needs an Edge Function (stage 8); "erase all data" currently wipes the device only.

## Stage 5 (cardio + habits + calendar, local)
Progress tab now has 3 shortcuts: **Cardio** (7 types, duration/distance/HR/notes, speed computed, 7-day chart, history),
**Habits** (user-defined only, optional suggestions, streaks, 7-day rate, simple sleep log), **Calendar** (month/week grid + day detail of what was
actually logged + custom events). All stored in the same local JSON → included in backup/export/wipe.
Still NOT done (honest list): Health Connect / HealthKit sync (needs `health` package + store permissions), date-based future workout scheduling,
weekly meal planner + shopping list, barcode, label scanner, exercise videos, AI features, admin dashboard, notifications/reminders, units conversion (imperial), real tests.
Not compiled here (no Flutter SDK) — run `flutter analyze` first.

## Stages 6-9 (planner, goals, AI, content sync, barcode, steps, admin)
- **Meal planner** (by weekday) + auto **shopping list** + "log this day's plan" (Nutrition tab). Values come from the food DB = estimates.
- **Goals & achievements** (Profile): user goals; achievements are computed from real logs (never stored/faked).
- **AI** (Home): meal analyzer (editable, flagged "AI estimate", saved with source=ai_estimate only after confirm) + chat (training / nutrition / my data).
  Needs `backend/functions/ai` deployed + `ANTHROPIC_API_KEY` & `AI_MODEL` secrets + signed-in user. It can't change plans.
- **Official content sync**: published programs/exercises/foods/articles from Supabase are cached locally and merged; offline keeps the cache.
  Education center (Profile) shows only owner-published articles.
- **Barcode** (Nutrition tab): Open Food Facts lookup, user reviews then saves as own food (not "verified").
- **Steps** (Home): Health Connect / HealthKit via `health` package (total steps only; OS de-duplicates sources).
- **Admin** (`admin/index.html`, static page): login, role check, CRUD for exercises (video/image upload), foods, articles, import/publish/feature/delete programs, audit log.

### Platform setup you must do (not done by code)
Android: minSdk 26+, add Health Connect permission `android.permission.health.READ_STEPS` + the Health Connect intent filter/queries in AndroidManifest, camera permission for the scanner.
iOS: HealthKit capability + `NSHealthShareUsageDescription`, `NSCameraUsageDescription` in Info.plist.

### Deploy order
1. Supabase: run `backend/schema.sql`, then `backend/schema_admin.sql` (insert your user into `user_roles` as super_admin).
2. `supabase functions deploy ai` + set secrets.
3. Host `admin/index.html`; open it, paste URL + anon key, sign in.
4. Add exercises -> import programs -> publish.
5. `flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...`

### Honest status - NOT done / NOT verified
Nothing here was compiled or run (no Flutter/Deno/Supabase in the build sandbox). Expect compile fixes, esp. `health` and `mobile_scanner` API versions.
Not built: nutrition-label photo scanner, push/local notifications & reminders, progress photos UI (bucket+RLS ready), body-measurement beyond weight,
row-level sync (still whole-snapshot), imperial unit display, server-side account deletion, admin: user support/notification/analytics/language screens,
Drift offline DB (JSON file used), tests, accessibility audit, RTL/device QA. Not production-ready.

## Personal-key AI (no backend)
AI screen -> key icon -> paste your Anthropic API key (+ model name, default `claude-haiku-5-5`). Stored in the Android keystore (flutter_secure_storage),
not in data file/backup/export, not in the APK. The app calls api.anthropic.com directly. Don't ship an APK with your key baked in to other people.
Supabase/admin are optional; the app is fully local without them.
